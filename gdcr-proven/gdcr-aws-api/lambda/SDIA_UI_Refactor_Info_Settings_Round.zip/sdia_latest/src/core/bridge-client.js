/* SDIA Governance v1.0.0 — isolated content-script client for MAIN-world SAP bridge.
 *
 * Security model (hardening):
 * - A random per-session nonce is generated here, in the ISOLATED world, and delivered
 *   to the MAIN-world page bridge exactly once per session via the handshake below
 *   (eager SDIA_SESSION post + reply to SDIA_SESSION_HELLO). Every request and every
 *   accepted response must carry this nonce.
 * - IMPORTANT: the MAIN world is inherently observable by the host SAP page — any page
 *   script can read window.postMessage traffic, including this handshake. The nonce
 *   therefore raises the bar against casual/opportunistic scripts that inject bridge
 *   commands WITHOUT listening to the message bus; it does NOT protect against the
 *   host page itself deliberately observing and replaying the nonce. The strict
 *   per-type payload validation enforced by page-bridge.js is the second barrier.
 * - event.origin is pinned to the window's own origin and event.source to the window,
 *   so cross-frame/cross-origin forged messages are always rejected.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};

  function generateSessionNonce() {
    try {
      const bytes = new Uint8Array(16);
      crypto.getRandomValues(bytes);
      return [...bytes].map((byte) => byte.toString(16).padStart(2, '0')).join('');
    } catch (_) {
      return `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}${Math.random().toString(36).slice(2)}`;
    }
  }

  const { BRIDGE_IN, BRIDGE_OUT } = SDIA.Core.constants;
  const SESSION_NONCE = generateSessionNonce();
  const targetOrigin = location.origin;

  function postSessionNonce() {
    window.postMessage({ source: BRIDGE_IN, type: 'SDIA_SESSION', nonce: SESSION_NONCE }, targetOrigin);
  }

  // Handshake: deliver the nonce eagerly (the page bridge loads earlier, at
  // document_start) and re-deliver whenever the page bridge announces itself.
  window.addEventListener('message', (event) => {
    if (event.source !== window || event.origin !== targetOrigin) return;
    const message = event.data;
    if (message && message.source === BRIDGE_OUT && message.type === 'SDIA_SESSION_HELLO') postSessionNonce();
  });
  postSessionNonce();

  function isValidResponse(event, requestId, type) {
    if (event.source !== window) return null;
    if (event.origin !== targetOrigin) return null;
    const message = event.data;
    if (!message || typeof message !== 'object') return null;
    if (message.source !== BRIDGE_OUT || message.requestId !== requestId) return null;
    if (message.nonce !== SESSION_NONCE) return null;
    if (message.type !== `${type}_PROGRESS` && message.type !== `${type}_RESULT`) return null;
    return message;
  }

  function request(type, payload, timeout = 30000, onProgress = null) {
    const requestId = `sdia-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        window.removeEventListener('message', handler);
        reject(new Error(`SAP page bridge did not respond within ${Math.round(timeout / 1000)} seconds.`));
      }, timeout);
      const handler = (event) => {
        const message = isValidResponse(event, requestId, type);
        if (!message) return;
        if (message.type === `${type}_PROGRESS`) { onProgress?.(message); return; }
        clearTimeout(timer);
        window.removeEventListener('message', handler);
        if (message.ok) resolve(message.result);
        else reject(new Error(message.error || 'Unknown SAP page error.'));
      };
      window.addEventListener('message', handler);
      window.postMessage({ source: BRIDGE_IN, type, requestId, nonce: SESSION_NONCE, payload }, targetOrigin);
    });
  }
  SDIA.BridgeClient = Object.freeze({ request });
})();
