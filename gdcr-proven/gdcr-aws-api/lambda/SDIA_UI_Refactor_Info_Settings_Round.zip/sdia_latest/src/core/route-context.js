/* SDIA Governance v1.0.0 — route/context detection only.
 * SAP Integration Suite may expose its SPA route in pathname, search or hash.
 * Detection intentionally uses the complete browser route, preserving the
 * behaviour of the validated pre-refactor implementation while keeping route
 * parsing isolated from UI/business modules.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};

  const PRODUCT_PROFILES = Object.freeze({
    home: Object.freeze({ id:'home', badgeIcon:'home', product:'integration-suite-home', capability:'SAP BTP Integration Suite', modelCode:'SDIA', modelName:'Semantic Domain Integration Architecture', primaryModule:'home-hub', status:'HOME · SDIA', area:'Integration Suite Home', scope:'Semantic Domain governance entry point', metricLabels:['Domains','Subdomains','Capabilities'] }),
    ci: Object.freeze({ id:'ci', badgeIcon:'cpi', product:'cloud-integration', capability:'SAP Cloud Integration', modelCode:'ODCP', modelName:'Orchestration Domain-Centric Pattern', primaryModule:'packages', status:'CLOUD INTEGRATION · ODCP', area:'Integrations and APIs', scope:'Integration packages and orchestration artefacts', metricLabels:['Packages','Compliant','Review'] }),
    apim: Object.freeze({ id:'apim', badgeIcon:'shield', product:'api-management', capability:'SAP API Management', modelCode:'GDCR', modelName:'Gateway Domain-Centric Routing', primaryModule:'apim', status:'API MANAGEMENT · GDCR / DDCR', area:'API Management', scope:'API proxies, key value maps and gateway governance', metricLabels:['Proxies','Governed','Review'] }),
    eventmesh: Object.freeze({ id:'eventmesh', badgeIcon:'emfly', product:'event-mesh', capability:'SAP Event Mesh', modelCode:'EDCP', modelName:'Event Domain-Centric Pattern', primaryModule:'eventmesh', status:'EVENT MESH · EDCP', area:'Event Mesh', scope:'Queues, topics, subscriptions and event namespaces', metricLabels:['Channels','Governed','Review'] }),
    security: Object.freeze({ id:'security', badgeIcon:'shield-check', product:'integration-security', capability:'SAP Integration Security', modelCode:'SDIA', modelName:'Semantic Domain Integration Architecture', primaryModule:'security', status:'SECURITY · SDIA', area:'Monitor · Security', scope:'Security Material and Keystore naming governance', metricLabels:['Materials','Governed','Review'] }),
    unknown: Object.freeze({ id:'unknown', badgeIcon:'shield', product:'unknown', capability:'SAP BTP Integration Suite', modelCode:'SDIA', modelName:'Semantic Domain Integration Architecture', primaryModule:'overview', status:'OPEN A SUPPORTED CAPABILITY', area:'Integration Suite', scope:'No supported product route detected', metricLabels:['Artefacts','Governed','Review'] })
  });

  function routeText() {
    return `${window.location.pathname || ''}${window.location.search || ''}${window.location.hash || ''}`;
  }

  function currentUrl() {
    try { return new URL(window.location.href); }
    catch (_) { return { pathname: location.pathname || '', searchParams: new URLSearchParams(location.search || ''), search: location.search || '', hash: location.hash || '' }; }
  }

  function effectivePath(route = routeText()) {
    const match = String(route || '').match(/\/shell\/(?:home(?:\/[^?#]*)?|design(?:\/[^?#]*)?|configureeventmesh(?:\/[^?#]*)?|configure(?:\/[^?#]*)?|monitoring(?:\/[^?#]*)?)/i);
    return match ? match[0].replace(/\/+$/, '') : '';
  }

  function designContext() {
    const route = routeText();
    const path = effectivePath(route);
    const packageMatch = route.match(/\/shell\/design\/contentpackage\/([^/?#]+)/i);
    if (packageMatch) {
      let packageId = packageMatch[1];
      try { packageId = decodeURIComponent(packageId); } catch (_) {}
      return { type:'contentpackage', level:'iflow', routeType:'content-package', packageId, pathname:path, route };
    }
    if (/\/shell\/design\/package\b/i.test(route) && /(?:[?&#]|\b)create=true\b/i.test(route)) {
      return { type:'package-create', level:'package', routeType:'package-create', packageId:'', pathname:path, route };
    }
    if (/\/shell\/design\/?(?:[?#]|$)/i.test(route)) {
      return { type:'design', level:'package', routeType:'design', packageId:'', pathname:path, route };
    }
    return { type:'other', level:'unsupported', routeType:'other', packageId:'', pathname:path, route };
  }

  function integrationSuiteContext() {
    const route = routeText();
    const path = effectivePath(route);
    const design = designContext();

    // Most-specific routes first. Do not allow /configureeventmesh to fall into /configure.
    if (/\/shell\/home\/?(?:[?#]|$)/i.test(route)) {
      return { product:'home', level:'home', routeType:'home', packageId:'', pathname:path, route, profile:PRODUCT_PROFILES.home };
    }
    if (design.type === 'contentpackage') return { product:'ci', routeType:'content-package', profile:PRODUCT_PROFILES.ci, ...design };
    if (design.type === 'package-create') return { product:'ci', routeType:'package-create', profile:PRODUCT_PROFILES.ci, ...design };
    if (/\/shell\/monitoring\/SecurityMaterials\/?(?:[?#]|$)/i.test(route)) {
      return { product:'security', level:'security', routeType:'security-materials', packageId:'', pathname:path, route, profile:PRODUCT_PROFILES.security };
    }
    if (/\/shell\/monitoring\/Keystore\/?(?:[?#]|$)/i.test(route)) {
      return { product:'security', level:'security', routeType:'keystore', packageId:'', pathname:path, route, profile:PRODUCT_PROFILES.security };
    }
    if (/\/shell\/monitoring(?:\/?(?:[?#]|$)|\/)/i.test(route)) {
      return { product:'security', level:'security', routeType:'monitoring', packageId:'', pathname:path, route, profile:PRODUCT_PROFILES.security };
    }
    if (/\/shell\/configureeventmesh\b/i.test(route)) {
      return { product:'eventmesh', level:'capability', routeType:'event-mesh', packageId:'', pathname:path, route, profile:PRODUCT_PROFILES.eventmesh };
    }
    if (/\/shell\/configure\b/i.test(route) && !/\/shell\/configureeventmesh\b/i.test(route)) {
      return { product:'apim', level:'capability', routeType:'api-management', packageId:'', pathname:path, route, profile:PRODUCT_PROFILES.apim };
    }
    if (design.type === 'design') return { product:'ci', routeType:'design', profile:PRODUCT_PROFILES.ci, ...design };

    return { product:'unknown', level:'unsupported', routeType:'unsupported', packageId:'', pathname:path, route, profile:PRODUCT_PROFILES.unknown };
  }

  function activeProductProfile() { return integrationSuiteContext().profile || PRODUCT_PROFILES.unknown; }
  function isSupportedGovernanceRoute() { return integrationSuiteContext().product !== 'unknown'; }
  function isLikelySapCi() { return isSupportedGovernanceRoute(); }
  function environmentName() {
    const host = location.hostname.toLowerCase();
    if (/trial/.test(host)) return 'Trial';
    if (/dev|development/.test(host)) return 'Development';
    if (/test|qa|quality/.test(host)) return 'Test';
    if (/prod|production/.test(host)) return 'Production';
    return 'Integration Suite Tenant';
  }

  SDIA.RouteContext = Object.freeze({ PRODUCT_PROFILES, routeText, currentUrl, effectivePath, designContext, integrationSuiteContext, activeProductProfile, isSupportedGovernanceRoute, isLikelySapCi, environmentName });
})();
