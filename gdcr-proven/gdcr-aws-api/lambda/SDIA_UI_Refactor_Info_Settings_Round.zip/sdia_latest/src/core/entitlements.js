/* SDIA Governance v0.2.0 — centralized product entitlement foundation.
 * No feature is restricted in the pilot. This module only establishes the
 * single decision point that a future Trial/Licensed service can feed.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};

  const FEATURES = Object.freeze({
    HOME: 'home',
    CATALOG: 'catalog',
    DOMAIN_HELP: 'domainHelp',
    PACKAGE_ASSESSMENT: 'packageAssessment',
    PACKAGE_CREATE: 'packageCreate',
    PACKAGE_EDIT: 'packageEdit',
    GOVERNANCE_MAP: 'governanceMap',
    EXPORT_PDF: 'exportPdf',
    APIM_GOVERNANCE: 'apimGovernance',
    EVENT_GOVERNANCE: 'eventGovernance',
    SECURITY_GOVERNANCE: 'securityGovernance'
  });

  const ALL_FEATURES = Object.freeze(Object.values(FEATURES));
  const PLAN = Object.freeze({
    DEVELOPMENT: 'development',
    TRIAL: 'trial',
    LICENSED: 'licensed',
    EXPIRED: 'expired'
  });

  // Pilot default: unrestricted. A future backend may replace this object with
  // signed entitlement DATA. Executable logic remains packaged with the extension.
  let entitlement = Object.freeze({
    plan: PLAN.DEVELOPMENT,
    status: 'active',
    source: 'local-pilot',
    trialEndsAt: null,
    features: Object.freeze([...ALL_FEATURES])
  });

  function normalizeFeatureSet(features) {
    const source = Array.isArray(features) ? features : [];
    return Object.freeze([...new Set(source.filter((feature) => ALL_FEATURES.includes(feature)))]);
  }

  function setEntitlementData(payload = {}) {
    const plan = Object.values(PLAN).includes(payload.plan) ? payload.plan : PLAN.DEVELOPMENT;
    const status = String(payload.status || 'active').toLowerCase();
    const features = plan === PLAN.DEVELOPMENT
      ? [...ALL_FEATURES]
      : normalizeFeatureSet(payload.features);
    entitlement = Object.freeze({
      plan,
      status,
      source: String(payload.source || 'runtime-data'),
      trialEndsAt: payload.trialEndsAt || null,
      features: Object.freeze([...features])
    });
    globalThis.dispatchEvent(new CustomEvent('sdia:entitlements-changed', { detail: entitlement }));
    return entitlement;
  }

  function snapshot() { return { ...entitlement, features: [...entitlement.features] }; }
  function canUse(feature) {
    if (!ALL_FEATURES.includes(feature)) return false;
    if (entitlement.plan === PLAN.DEVELOPMENT) return true;
    if (entitlement.status !== 'active') return false;
    return entitlement.features.includes(feature);
  }

  SDIA.Entitlements = Object.freeze({ FEATURES, PLAN, canUse, snapshot, setEntitlementData });
})();
