/* SDIA Governance v0.2.0 — shared runtime state and utilities. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};

  const constants = Object.freeze({
    ROOT_ID: 'sdia-governance-root',
    OVERLAY_ID: 'sdia-control-center',
    TOAST_ID: 'sdia-global-toast',
    SPLASH_KEY: 'sdia:brand-splash:v0.2.0',
    UI_STATE_KEY: 'sdia:control-center-ui:v0.2.0',
    STORAGE: Object.freeze({ settings: 'sdiaGovernanceSettingsV020', catalog: 'sdiaGovernanceCatalogV020' }),
    BRIDGE_IN: 'SDIA_GOVERNANCE_EXTENSION',
    BRIDGE_OUT: 'SDIA_GOVERNANCE_PAGE',
    DESCRIPTION_PREFIX: 'SDIA - Scope & Governance:',
    SHORT_DESCRIPTION_MAX: 255
  });

  const DEFAULT_SETTINGS = Object.freeze({
    autoDetectSap: true,
    enabledHosts: {},
    launcherVisible: true,
    defaultCompanyPrefixEnabled: false,
    defaultCompanyCode: '',
    defaultDivisionEnabled: false,
    defaultDivisionCode: '',
    packageSuffix: 'integrations',
    vendor: '',
    useDefaultVendor: true,
    preserveDraftSession: true,
    startNewContextInOverview: true,
    restoreLastWorkspaceInSession: true,
    showGuidanceHints: true,
    transitionSplashEnabled: true,
    appearance: 'white',
    controlPlaneColorMode: 'auto',
    controlPlaneColor: 'emerald-green',
    controlPlaneOpenCount: 0,
    controlPlaneRotationEvery: 20,
    launcherLeft: null,
    launcherTop: null
  });

  const APPEARANCE_THEMES = Object.freeze(['white', 'blue', 'cream']);
  function normalizeAppearance(value) {
    return APPEARANCE_THEMES.includes(String(value || '').toLowerCase()) ? String(value).toLowerCase() : 'white';
  }

  const state = {
    settings: { ...DEFAULT_SETTINGS },
    catalog: {},
    enabled: false,
    mounted: false,
    root: null,
    launcher: null,
    overlay: null,
    toast: null,
    toastTimer: null,
    activeModule: 'overview',
    capabilityReturnModule: 'overview',
    packageCreateBusy: false,
    packageEditBusy: false,
    selectedPackage: null,
    packageEditRows: [],
    packageMapRows: [],
    packageMapSelectedIndex: null,
    packageMapArtifacts: [],
    packageMapArtifactsLoading: false,
    packageMapExpanded: false,
    descriptionDirty: false,
    generatedPackage: null,
    lastAssessment: null,
    pendingPackageName: '',
    activeArtefactType: 'integration-flow',
    artefactCreateBusy: false,
    pendingArtefactName: '',
    internalHistory: []
  };

  function clone(value) { return JSON.parse(JSON.stringify(value || {})); }
  function normalizeToken(value) {
    return String(value || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9-]/g, '').replace(/-{2,}/g, '-').replace(/^-+|-+$/g, '');
  }
  function normalizeText(value) {
    return String(value || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[\r\n\t]+/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function clampText(value, maxLength = constants.SHORT_DESCRIPTION_MAX) {
    const text = String(value || '').replace(/\s+/g, ' ').trim();
    if (text.length <= maxLength) return text;
    const clipped = text.slice(0, maxLength);
    const lastBoundary = Math.max(clipped.lastIndexOf('. '), clipped.lastIndexOf('; '), clipped.lastIndexOf(', '), clipped.lastIndexOf(' '));
    const safe = lastBoundary >= Math.floor(maxLength * 0.78) ? clipped.slice(0, lastBoundary) : clipped;
    return safe.replace(/[\s,;:.]+$/g, '').trim();
  }
  function escapeHtml(value) {
    return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
  }
  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  function runtimeUrl(path) { try { return chrome.runtime.getURL(path); } catch (_) { return path; } }

  function icon(name) {
    const safeName = String(name || 'overview').replace(/[^a-z0-9-]/gi, '') || 'overview';
    // `arrow` remains an inline SVG chevron: several surfaces rotate it via CSS
    // and it must keep reacting to currentColor without an asset swap.
    if (safeName === 'arrow') {
      return '<svg class="sdia-icon sdia-icon-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5.5 6.5 6.5L9 18.5"/></svg>';
    }
    if (safeName === 'domain-help') {
      return '<svg class="sdia-icon sdia-icon-domain-help" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4.2c-4.3 0-7.8 3.5-7.8 7.8s3.5 7.8 7.8 7.8 7.8-3.5 7.8-7.8-3.5-7.8-7.8-7.8Z"/><path d="M12 8.1v7.8"/><path d="M8.1 12h7.8"/></svg>';
    }
    return `<img class="sdia-icon" src="${runtimeUrl(`src/shared/icons/assets/${safeName}.png`)}" alt="" aria-hidden="true">`;
  }

  async function loadState() {
    try {
      const data = await chrome.storage.local.get([constants.STORAGE.settings, constants.STORAGE.catalog]);
      const stored = data[constants.STORAGE.settings] || {};
      const legacyTop = Number(stored?.floatingPosition?.top);
      state.settings = {
        ...DEFAULT_SETTINGS,
        ...stored,
        enabledHosts: { ...DEFAULT_SETTINGS.enabledHosts, ...(stored.enabledHosts || {}) },
        packageSuffix: 'integrations',
        launcherLeft: Number.isFinite(Number(stored.launcherLeft)) ? Number(stored.launcherLeft) : null,
        launcherTop: Number.isFinite(Number(stored.launcherTop)) ? Number(stored.launcherTop) : (Number.isFinite(legacyTop) ? legacyTop : null)
      };
      state.settings.appearance = normalizeAppearance(state.settings.appearance);
      state.settings.controlPlaneColorMode = state.settings.controlPlaneColorMode === 'manual' ? 'manual' : 'auto';
      state.settings.controlPlaneColor = String(state.settings.controlPlaneColor || 'emerald-green').toLowerCase();
      state.settings.controlPlaneOpenCount = Math.max(0, Number(state.settings.controlPlaneOpenCount) || 0);
      state.settings.controlPlaneRotationEvery = 20;
      state.settings.transitionSplashEnabled = state.settings.transitionSplashEnabled !== false;
      // Boot: expose the saved appearance theme as early as possible so any
      // SDIA surface resolves the themed tokens before the Control Center opens.
      try { document.documentElement.dataset.sdiaTheme = state.settings.appearance; } catch (_) {}
      delete state.settings.floatingPosition;
      const defaultCatalog = clone(globalThis.SDIA_DEFAULT_CATALOG || {});
      const storedCatalog = data[constants.STORAGE.catalog] || null;
      if (storedCatalog && String(storedCatalog.schemaVersion || '') === String(defaultCatalog.schemaVersion || '')) {
        state.catalog = clone(storedCatalog);
      } else {
        // Catalog schema 0.5 refreshes canonical codes and semantic guidance aliases. Preserve user divisions,
        // but migrate the semantic taxonomy to the new SAP-aligned starter model so old
        // finance/procurement/logistics/o2c identifiers do not keep generating legacy names.
        state.catalog = defaultCatalog;
        if (Array.isArray(storedCatalog?.divisions) && storedCatalog.divisions.length) {
          const legacySampleIds = ['var','consumer','industrial','corporate','shared-services'];
          const storedIds = storedCatalog.divisions.map((item) => normalizeToken(item?.id)).filter(Boolean).sort();
          const sampleIds = [...legacySampleIds].sort();
          const isUntouchedLegacySample = storedIds.length === sampleIds.length && storedIds.every((id, index) => id === sampleIds[index]);
          if (!isUntouchedLegacySample) state.catalog.divisions = clone(storedCatalog.divisions);
        }
      }
      await chrome.storage.local.set({
        [constants.STORAGE.settings]: state.settings,
        [constants.STORAGE.catalog]: state.catalog
      });
    } catch (error) {
      console.warn('[SDIA] State load failed', error);
      state.catalog = clone(globalThis.SDIA_DEFAULT_CATALOG || {});
    }
  }
  async function saveSettings() { await chrome.storage.local.set({ [constants.STORAGE.settings]: state.settings }); }

  SDIA.Core = Object.freeze({
    constants, DEFAULT_SETTINGS, state,
    clone, normalizeToken, normalizeText, clampText, escapeHtml, delay, runtimeUrl, icon,
    loadState, saveSettings
  });
})();
