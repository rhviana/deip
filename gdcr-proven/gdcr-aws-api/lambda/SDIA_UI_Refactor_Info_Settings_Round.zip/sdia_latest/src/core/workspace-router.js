/* SDIA Governance v1.0.0 — normalized context to workspace mapping. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};

  // Only explicit workflows that must survive SAP native navigation are route-sticky.
  function isFormModule(module = SDIA.Core.state.activeModule) {
    return ['package-create','package-edit-form','capability-action'].includes(module);
  }

  const moduleFeature = Object.freeze({
    catalog:'catalog', 'domain-help':'domainHelp', assessment:'packageAssessment',
    'package-create':'packageCreate', 'package-edit-list':'packageEdit', 'package-edit-form':'packageEdit',
    'package-map':'governanceMap', apim:'apimGovernance', eventmesh:'eventGovernance', security:'securityGovernance'
  });

  function entitlementFilter(modules) {
    const access = SDIA.Entitlements;
    if (!access?.canUse) return modules;
    return modules.filter((module) => {
      const feature = moduleFeature[module];
      return !feature || access.canUse(feature);
    });
  }

  function allowedModulesForProduct(profile = SDIA.RouteContext.activeProductProfile()) {
    let modules;
    if (profile.id === 'home') {
      modules = ['home-hub','dashboard','what-is-sdia','how-to','catalog','domain-help','information','contact','settings'];
    } else if (profile.id === 'ci') {
      const context = SDIA.RouteContext.designContext();
      modules = context.type === 'contentpackage'
        ? ['overview','how-to','package-workspace','capability-action']
        : ['overview','how-to','packages','package-map','assessment','package-create','package-edit-list','package-edit-form','capability-action'];
    } else if (profile.id === 'apim') {
      modules = ['overview','how-to','apim','capability-action'];
    } else if (profile.id === 'eventmesh') {
      modules = ['overview','how-to','eventmesh','capability-action'];
    } else if (profile.id === 'security') {
      modules = ['overview','security','capability-action'];
    } else {
      modules = ['overview'];
    }
    return entitlementFilter(modules);
  }

  function defaultModuleForRoute() {
    return SDIA.RouteContext.activeProductProfile().id === 'home' ? 'home-hub' : 'overview';
  }

  SDIA.WorkspaceRouter = Object.freeze({ isFormModule, allowedModulesForProduct, defaultModuleForRoute });
})();
