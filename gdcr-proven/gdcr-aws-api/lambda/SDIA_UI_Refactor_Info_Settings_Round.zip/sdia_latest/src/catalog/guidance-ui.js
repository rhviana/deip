/* SDIA Governance v0.2.0 — product-to-domain guidance for Package governance.
 * Product/module names provide technical-binding context only. Domain/Subdomain
 * semantics always resolve from the canonical SDIA Catalog.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { state, escapeHtml, normalizeText, normalizeToken, runtimeUrl, icon } = SDIA.Core;
  let activeProductId = 'successfactors';

  const m = (name, detail, domainCode, subdomainCode) => ({ name, detail, domainCode, subdomainCode });
  const product = (id, vendor, name, short, items, note, options = {}) => ({ id, vendor, name, short, items, note, ...options });

  const guidance = Object.freeze([
    product('successfactors','SAP','SAP SuccessFactors','SuccessFactors',[
      m('Employee Central','Employee master, employment and organization interfaces.','HR','CORE'),
      m('Recruiting','Recruiting and talent-acquisition interfaces.','HR','REC'),
      m('Onboarding','New-hire and employee onboarding interfaces.','HR','ONB'),
      m('Learning','Learning, course and certification interfaces.','HR','LRN'),
      m('Time Tracking','Working-time and time-sheet interfaces.','HR','TIME'),
      m('Time Off / Absence','Leave, absence and entitlement interfaces.','HR','ABS'),
      m('Employee Central Payroll','Payroll calculation and payroll-result interfaces.','HR','PAY'),
      m('HR Service Delivery','Employee service and HR case interfaces.','HR','SVC'),
      m('Talent Management','Talent profile and talent-review interfaces.','HR','TAL'),
      m('Performance & Goals','Performance objective and appraisal interfaces.','HR','PERF'),
      m('Compensation','Compensation planning and award interfaces.','HR','COMP'),
      m('Benefits','Benefit enrollment and provider interfaces.','HR','BEN'),
      m('Workforce Planning','Headcount and workforce-plan interfaces.','HR','WFP'),
      m('Workforce Management','Operational workforce scheduling interfaces.','HR','WFM'),
      m('Succession & Development','Succession pipeline and development interfaces.','HR','SUCC')
    ],'Classify by the HR business capability being integrated; SuccessFactors itself is not the Domain.',{mark:'SF'}),

    product('s4hana','SAP','SAP S/4HANA','S/4HANA',[
      m('Record to Report','General ledger and financial close interfaces.','FIN','RTR'),
      m('Accounts Payable','Supplier accounting and payable interfaces.','FIN','AP'),
      m('Accounts Receivable','Customer accounting and receivable interfaces.','FIN','AR'),
      m('Treasury & Cash','Treasury, liquidity and cash-position interfaces.','FIN','TRE'),
      m('Controlling','Cost, profit-center and management-accounting interfaces.','FIN','CO'),
      m('Fixed Assets','Asset capitalization and depreciation interfaces.','FIN','FA'),
      m('Order to Cash','Sales-order through billing interfaces.','SALES','OTC'),
      m('Pricing','Sales pricing and condition interfaces.','SALES','PRICE'),
      m('Billing','Billing-document and invoice interfaces.','SALES','BILL'),
      m('Procure to Pay','Requisition, PO and procurement execution interfaces.','PROC','PTP'),
      m('Supplier Management','Supplier lifecycle and supplier-data interfaces.','PROC','SUP'),
      m('Inventory Management','Stock and inventory interfaces.','LOG','INV'),
      m('Logistics Execution','Delivery and logistics-execution interfaces.','LOG','LE'),
      m('Production Planning','Production planning and manufacturing-demand interfaces.','MFG','PP'),
      m('Enterprise Asset Management','Asset lifecycle and maintenance interfaces.','ASSET','EAM')
    ],'S/4HANA spans multiple business Domains. Classify from the process boundary, never from the system name.',{mark:'S4'}),

    product('ariba','SAP','SAP Ariba','Ariba',[
      m('Source to Pay','End-to-end sourcing through payment-oriented procurement interfaces.','PROC','STP'),
      m('Procure to Pay','Buying, ordering and invoicing interfaces.','PROC','PTP'),
      m('Strategic Sourcing','Sourcing event and award interfaces.','PROC','SRC'),
      m('Purchasing','Requisition and purchase-order interfaces.','PROC','PUR'),
      m('Supplier Management','Supplier lifecycle and profile interfaces.','PROC','SUP'),
      m('Supplier Onboarding','Supplier registration and onboarding interfaces.','PROC','ONB'),
      m('Contracts','Procurement contract and agreement interfaces.','PROC','CTR'),
      m('Supplier Risk','Supplier risk and qualification interfaces.','PROC','RISK'),
      m('Buying Catalog','Procurement catalog interfaces.','PROC','CATALOG'),
      m('Business Network','Buyer-supplier transaction interfaces.','PROC','BN'),
      m('Spend Analysis','Spend visibility and classification interfaces.','PROC','SPEND'),
      m('Category Management','Category plan and procurement-strategy interfaces.','PROC','CAT')
    ],'Ariba capabilities map to procurement semantics rather than to an “Ariba” Domain.',{mark:'AR'}),

    product('concur','SAP','SAP Concur','Concur',[
      m('Expense Management','Employee expense-report and reimbursement interfaces.','FIN','EXP'),
      m('Travel & Expense','Travel-spend and expense lifecycle interfaces.','FIN','EXP'),
      m('Concur Invoice','Supplier invoice capture and invoice workflow interfaces.','FIN','INV'),
      m('Accounts Payable Integration','Approved supplier-invoice posting interfaces.','FIN','AP'),
      m('Corporate Card Feed','Card transaction and spend interfaces.','FIN','EXP'),
      m('Cash Advance','Employee cash-advance and settlement interfaces.','FIN','CASH'),
      m('Travel Allowance','Per-diem and travel allowance interfaces.','FIN','EXP'),
      m('Expense Audit','Expense validation and compliance interfaces.','FIN','EXP'),
      m('Supplier Payment Status','Invoice and supplier-payment status interfaces.','FIN','AP'),
      m('Expense Analytics','Travel and expense analytical interfaces.','FIN','EXP')
    ],'Concur is a spend platform; select the Finance or Procurement boundary represented by the actual process.',{mark:'CN'}),

    product('fieldglass','SAP','SAP Fieldglass','Fieldglass',[
      m('Contingent Workforce','External-worker lifecycle interfaces.','HR','WFM'),
      m('External Worker Onboarding','External workforce onboarding interfaces.','HR','ONB'),
      m('Worker Master','External workforce profile and assignment interfaces.','HR','CORE'),
      m('Time Sheets','External worker time interfaces.','HR','TIME'),
      m('Worker Offboarding','External worker separation interfaces.','HR','OFF'),
      m('Services Procurement','Statement-of-work and service-procurement interfaces.','PROC','INDIRECT'),
      m('Supplier Management','Staffing supplier and service-provider interfaces.','PROC','SUP'),
      m('Service Requisition','External service request and approval interfaces.','PROC','REQ'),
      m('Service Invoicing','Service invoice and payment interfaces.','PROC','INV'),
      m('External Workforce Analytics','External workforce analytical interfaces.','HR','ANA')
    ],'Fieldglass spans external workforce and services procurement. Classify from business ownership, not the VMS product name.',{mark:'FG'}),

    product('ibp','SAP','SAP Integrated Business Planning','SAP IBP',[
      m('Sales & Operations Planning','Integrated S&OP interfaces.','LOG','SOP'),
      m('Demand Planning','Demand forecast and planning interfaces.','LOG','DEM'),
      m('Response & Supply Planning','Supply response and capacity interfaces.','LOG','SUP'),
      m('Inventory Optimization','Inventory target and optimization interfaces.','LOG','INV'),
      m('Supply Chain Visibility','Control-tower and exception interfaces.','LOG','VIS'),
      m('Demand Sensing','Short-term demand signal interfaces.','LOG','DEM'),
      m('Replenishment','Replenishment and deployment interfaces.','LOG','REPL'),
      m('Order Promising','Promise and fulfillment planning interfaces.','LOG','ATP'),
      m('Scenario Planning','Planning-scenario and what-if interfaces.','LOG','PLAN'),
      m('Planning Analytics','Supply-chain plan KPI interfaces.','LOG','PLAN')
    ],'SAP IBP belongs to Supply Chain semantics, but each integration should still be classified by its planning capability.',{mark:'IBP'}),

    product('ewm','SAP','SAP Extended Warehouse Management','SAP EWM',[
      m('Inbound Processing','Inbound delivery and goods-receipt interfaces.','LOG','INB'),
      m('Outbound Processing','Picking, packing and goods-issue interfaces.','LOG','OUT'),
      m('Warehouse Inventory','Warehouse stock and bin inventory interfaces.','LOG','WH'),
      m('Physical Inventory','Physical inventory interfaces.','LOG','INV'),
      m('Replenishment','Warehouse replenishment interfaces.','LOG','REPL'),
      m('Goods Movement','Internal stock-movement interfaces.','LOG','WH'),
      m('Yard Management','Yard, gate and dock interfaces.','LOG','YARD'),
      m('Warehouse Task / Order','Warehouse task and warehouse-order interfaces.','LOG','WH'),
      m('Handling Units','Handling-unit and packaging interfaces.','LOG','WH'),
      m('Warehouse Quality','Inbound quality and inspection interfaces.','MFG','QM')
    ],'EWM is a technical warehouse platform. Keep the Domain tied to the supply-chain process being executed.',{mark:'EWM'}),

    product('tm','SAP','SAP Transportation Management','SAP TM',[
      m('Transportation Requirements','Transportation-demand and requirement interfaces.','LOG','TM'),
      m('Freight Order Management','Freight order interfaces.','LOG','TM'),
      m('Transportation Planning','Freight planning and optimization interfaces.','LOG','TM'),
      m('Carrier Selection','Carrier and tendering interfaces.','LOG','TM'),
      m('Transportation Execution','Execution-status and shipment interfaces.','LOG','TM'),
      m('Freight Costing','Freight rate and cost interfaces.','LOG','TM'),
      m('Freight Settlement','Freight settlement interfaces.','LOG','TM'),
      m('Transportation Collaboration','Carrier collaboration interfaces.','LOG','TM'),
      m('Logistics Visibility','ETA and transportation visibility interfaces.','LOG','VIS'),
      m('Global Trade Handoff','Cross-border and customs handoff interfaces.','LOG','GTM')
    ],'Transportation Management remains under Supply Chain; use the specific transportation capability as the Subdomain context.',{mark:'TM'}),

    product('sapcx','SAP','SAP Customer Experience','SAP CX',[
      m('Sales Cloud','Accounts, contacts and sales CRM interfaces.','SALES','CRM'),
      m('Opportunity Management','Sales pipeline and opportunity interfaces.','SALES','OPP'),
      m('Sales CPQ','Configure-price-quote interfaces.','SALES','CPQ'),
      m('Service Cloud','Customer-service case interfaces.','SVC','CSM'),
      m('Field Service','Field-service planning and execution interfaces.','SVC','FSM'),
      m('Commerce Cloud','Digital commerce catalog and transaction interfaces.','COM','CATALOG'),
      m('Commerce Orders','Digital order-management interfaces.','COM','ORD'),
      m('Commerce Fulfillment','Commerce fulfillment interfaces.','COM','FULF'),
      m('Marketing Campaigns','Campaign execution interfaces.','MKT','CAMP'),
      m('Customer Journeys','Journey orchestration interfaces.','MKT','JOURNEY'),
      m('Customer Data','Unified customer-data interfaces.','CUST','C360'),
      m('Customer Identity','Customer identity interfaces.','CUST','ID'),
      m('Consent & Preferences','Customer consent interfaces.','CUST','CONSENT'),
      m('Customer Loyalty','Loyalty account and reward interfaces.','CUST','LOY'),
      m('Sales Performance','Sales performance and incentive interfaces.','SALES','SPM')
    ],'SAP CX spans Sales, Service, Commerce, Marketing and Customer data. The business capability remains the semantic key.',{mark:'CX'}),

    product('salesforce','Salesforce','Salesforce','Salesforce',[
      m('Sales Cloud','Accounts, contacts and sales CRM interfaces.','SALES','CRM'),
      m('Lead Management','Lead qualification and conversion interfaces.','SALES','LEAD'),
      m('Opportunity Management','Opportunity and pipeline interfaces.','SALES','OPP'),
      m('Revenue Cloud / CPQ','Configure-price-quote interfaces.','SALES','CPQ'),
      m('Subscription Revenue','Recurring-revenue and subscription interfaces.','SALES','REV'),
      m('Service Cloud','Customer-service case interfaces.','SVC','CSM'),
      m('Field Service','Field-service work interfaces.','SVC','FSM'),
      m('Marketing Cloud','Campaign execution interfaces.','MKT','CAMP'),
      m('Customer Journeys','Journey orchestration interfaces.','MKT','JOURNEY'),
      m('Commerce Cloud','Digital commerce interfaces.','COM','ECOM'),
      m('Order Management','Commerce and sales order interfaces.','SALES','OTC'),
      m('Customer Data Platform','Unified customer-profile interfaces.','CUST','C360'),
      m('Loyalty Management','Loyalty account and reward interfaces.','CUST','LOY'),
      m('Partner Management','Partner and channel interfaces.','SALES','PRM'),
      m('Case Management','Customer case and resolution interfaces.','SVC','CASE')
    ],'Salesforce is a technical platform. Route the integration according to the business capability being served.',{logo:'salesforce'}),

    product('servicenow','ServiceNow','ServiceNow','ServiceNow',[
      m('IT Service Management','IT service-management interfaces.','IT','ITSM'),
      m('Incident Management','Incident interfaces.','IT','INC'),
      m('Problem Management','Problem and root-cause interfaces.','IT','PRB'),
      m('Change Management','Change-control interfaces.','IT','CHG'),
      m('Service Request','Request and service-catalog interfaces.','IT','REQ'),
      m('IT Asset Management','IT asset interfaces.','IT','ASSET'),
      m('CMDB','Configuration-item interfaces.','IT','CMDB'),
      m('IT Operations Management','Operational event and infrastructure interfaces.','IT','OBS'),
      m('HR Service Delivery','Employee-service interfaces.','HR','SVC'),
      m('Customer Service Management','Customer-service interfaces.','SVC','CSM'),
      m('Field Service Management','Field-service interfaces.','SVC','FSM'),
      m('Procurement Service Management','Procurement request and workflow interfaces.','PROC','WF'),
      m('Accounts Payable Operations','Invoice and AP workflow interfaces.','FIN','AP'),
      m('Workplace Service Delivery','Workplace request interfaces.','IT','REQ'),
      m('Security Operations','Security operational workflow interfaces.','IT','OBS')
    ],'ServiceNow spans multiple enterprise functions. Classify by business ownership and process intent.',{logo:'servicenow'}),

    product('workday','Workday','Workday','Workday',[
      m('Core HCM','Core HR and worker master interfaces.','HR','CORE'),
      m('Recruiting','Recruiting interfaces.','HR','REC'),
      m('Onboarding','Employee onboarding interfaces.','HR','ONB'),
      m('Talent Management','Talent interfaces.','HR','TAL'),
      m('Learning','Learning interfaces.','HR','LRN'),
      m('Performance','Performance-review interfaces.','HR','PERF'),
      m('Compensation','Compensation interfaces.','HR','COMP'),
      m('Benefits','Benefit interfaces.','HR','BEN'),
      m('Payroll','Payroll interfaces.','HR','PAY'),
      m('Time Tracking','Time interfaces.','HR','TIME'),
      m('Absence','Absence interfaces.','HR','ABS'),
      m('Workforce Planning','Workforce-plan interfaces.','HR','WFP'),
      m('Financial Management','Financial accounting interfaces.','FIN','RTR'),
      m('Procure to Pay','Procurement interfaces.','PROC','PTP'),
      m('Expense Management','Employee expense interfaces.','FIN','EXP')
    ],'Workday spans HR and Finance. Use the actual business capability to select the semantic boundary.',{logo:'workday'}),

    product('dynamics365','Microsoft','Microsoft Dynamics 365','Dynamics 365',[
      m('Dynamics 365 Sales','CRM and sales pipeline interfaces.','SALES','CRM'),
      m('Customer Service','Customer-service case interfaces.','SVC','CSM'),
      m('Field Service','Field-service work interfaces.','SVC','FSM'),
      m('Finance','Financial accounting interfaces.','FIN','RTR'),
      m('Accounts Payable','Payables interfaces.','FIN','AP'),
      m('Accounts Receivable','Receivables interfaces.','FIN','AR'),
      m('Supply Chain Management','Supply-chain execution interfaces.','LOG','LE'),
      m('Inventory','Inventory interfaces.','LOG','INV'),
      m('Warehouse','Warehouse interfaces.','LOG','WH'),
      m('Commerce','Commerce interfaces.','COM','ECOM'),
      m('Project Operations','Project-centric operational interfaces.','FIN','RTR'),
      m('Human Resources','Core workforce interfaces.','HR','CORE'),
      m('Marketing / Customer Insights','Campaign and journey interfaces.','MKT','JOURNEY'),
      m('Order Management','Order-to-cash interfaces.','SALES','OTC'),
      m('Asset Management','Asset and maintenance interfaces.','ASSET','EAM')
    ],'Dynamics 365 is a suite. Classify each integration by its Finance, Sales, Service, Supply Chain or HR purpose.',{logo:'dynamics'}),

    product('oracle','Oracle','Oracle Fusion Cloud Applications','Oracle Fusion',[
      m('Financials','Financial accounting interfaces.','FIN','RTR'),
      m('Accounts Payable','Supplier accounting interfaces.','FIN','AP'),
      m('Accounts Receivable','Customer accounting interfaces.','FIN','AR'),
      m('Procurement','Source-to-pay interfaces.','PROC','STP'),
      m('Project Management','Project-finance interfaces.','FIN','RTR'),
      m('Human Resources','Core workforce interfaces.','HR','CORE'),
      m('Recruiting','Recruiting interfaces.','HR','REC'),
      m('Payroll','Payroll interfaces.','HR','PAY'),
      m('Talent Management','Talent interfaces.','HR','TAL'),
      m('Supply Chain Planning','Supply planning interfaces.','LOG','PLAN'),
      m('Inventory Management','Inventory interfaces.','LOG','INV'),
      m('Order Management','Order-to-cash interfaces.','SALES','OTC'),
      m('Logistics','Logistics interfaces.','LOG','LE'),
      m('Sales / CX','Sales CRM interfaces.','SALES','CRM'),
      m('Service / CX','Customer service interfaces.','SVC','CSM')
    ],'Oracle Fusion spans ERP, HCM, SCM and CX. Keep the semantic boundary aligned to the business process.',{logo:'oracle'}),

    product('coupa','Coupa','Coupa','Coupa',[
      m('Source to Pay','End-to-end spend interfaces.','PROC','STP'),
      m('Sourcing','Sourcing interfaces.','PROC','SRC'),
      m('Procurement','Buying and purchasing interfaces.','PROC','PUR'),
      m('Supplier Management','Supplier lifecycle interfaces.','PROC','SUP'),
      m('Supplier Risk','Supplier risk interfaces.','PROC','RISK'),
      m('Contracts','Procurement contract interfaces.','PROC','CTR'),
      m('Invoicing','Supplier invoice interfaces.','PROC','INV'),
      m('Spend Analytics','Spend analytical interfaces.','PROC','SPEND'),
      m('Expense Management','Employee expense interfaces.','FIN','EXP'),
      m('Travel & Expense','Travel-spend interfaces.','FIN','EXP'),
      m('Payments','Supplier payment interfaces.','FIN','AP'),
      m('Business Network','Supplier network transaction interfaces.','PROC','BN')
    ],'Coupa is a spend-management platform. Use Procurement or Finance according to the governed process.',{logo:'coupa'})
  ]);

  const logoUrl = (key) => key ? runtimeUrl(`src/shared/vendors/assets/vendor-${key}.png`) : '';
  let focusTimer = null;

  function findDomainByCode(code) {
    const token = normalizeToken(code);
    return (state.catalog.domains || []).find((d) => [d.canonicalCode,d.id,...(d.aliases || [])].map(normalizeToken).includes(token)) || null;
  }
  function findSubdomainByCode(domain, code) {
    const token = normalizeToken(code);
    return (domain?.subdomains || []).find((s) => [s.canonicalCode,s.id,...(s.aliases || [])].map(normalizeToken).includes(token)) || null;
  }
  function resolveItem(item) {
    const domain = findDomainByCode(item.domainCode);
    const subdomain = findSubdomainByCode(domain, item.subdomainCode);
    return { ...item, domain:domain?.name || item.domainCode, subdomain:subdomain?.name || item.subdomainCode, valid:Boolean(domain && subdomain) };
  }
  function resolvedProduct(product) { return { ...product, items:product.items.map(resolveItem) }; }
  function productById(id) { return guidance.find((item) => item.id === id) || null; }

  function productMark(product) { return product.mark || String(product.short || product.name || '?').slice(0,3).toUpperCase(); }
  function brandMarkup(product) {
    if (product.logo) return `<img class="sdia-guidance-vendor-logo" src="${escapeHtml(logoUrl(product.logo))}" alt="${escapeHtml(product.vendor)}">`;
    return `<i class="sdia-guidance-product-mark">${escapeHtml(productMark(product))}</i>`;
  }

  function cardMarkup(product, isSap, extraClass = '') {
    const active = product.id === activeProductId;
    return `<button type="button" class="sdia-guidance-product-card${active ? ' active' : ''}${extraClass ? ` ${extraClass}` : ''}" data-sdia-guidance-product="${escapeHtml(product.id)}" aria-pressed="${active ? 'true' : 'false'}">
      <span>${brandMarkup(product)}${isSap ? '' : `<em>${escapeHtml(product.vendor)}</em>`}</span>
      <b>${escapeHtml(product.short)}</b>
      <small>${product.items.length} semantic mappings</small>
    </button>`;
  }

  function renderProductGroups(products = guidance) {
    if (!state.overlay) return;
    const sapGrid = state.overlay.querySelector('#sdia-guidance-product-grid-sap');
    const vendorGrid = state.overlay.querySelector('#sdia-guidance-product-grid-vendors');
    const sapProducts = products.filter((item) => normalizeText(item.vendor) === 'sap');
    const vendors = products.filter((item) => normalizeText(item.vendor) !== 'sap');
    if (sapGrid) sapGrid.innerHTML = sapProducts.length ? sapProducts.map((p) => cardMarkup(p,true)).join('') : '<div class="sdia-guidance-empty">No SAP product guidance matches this search.</div>';
    if (vendorGrid) vendorGrid.innerHTML = vendors.length ? vendors.map((p) => cardMarkup(p,false)).join('') : '<div class="sdia-guidance-empty">No external vendor guidance matches this search.</div>';
  }

  function itemMarkup(item, index) {
    return `<article class="sdia-guidance-tree-branch" style="--sdia-guidance-delay:${120 + index * 70}ms">
      <i aria-hidden="true"></i>
      <div class="sdia-guidance-tree-node">
        <span>Product capability</span><b>${escapeHtml(item.name)}</b><small>${escapeHtml(item.detail)}</small>
        <div class="sdia-guidance-route"><strong>${escapeHtml(item.domainCode)}</strong><em>/</em><strong>${escapeHtml(item.subdomainCode)}</strong><span>${escapeHtml(item.domain)} → ${escapeHtml(item.subdomain)}</span></div>
      </div>
    </article>`;
  }

  function treeRows(items, size = 5) {
    const rows = [];
    for (let i=0;i<items.length;i+=size) rows.push(items.slice(i,i+size));
    let cursor = 0;
    return rows.map((row,rowIndex) => {
      const start = cursor; cursor += row.length;
      return `<section class="sdia-guidance-tree-level" style="--sdia-level-count:${row.length};--sdia-level-delay:${200 + rowIndex * 120}ms">
        <i class="sdia-guidance-level-stem" aria-hidden="true"></i><i class="sdia-guidance-level-rail" aria-hidden="true"></i>
        <div class="sdia-guidance-level-grid">${row.map((item,index) => itemMarkup(item,start+index)).join('')}</div>
      </section>`;
    }).join('');
  }

  function guidanceDetailMarkup(product) {
    const isSap = normalizeText(product.vendor) === 'sap';
    return `<div class="sdia-guidance-focus-layout">
      <aside class="sdia-guidance-focus-aside">
        <button type="button" class="sdia-focus-back" data-sdia-guidance-back>← All Products</button>
        ${cardMarkup(product, isSap, 'sdia-guidance-focus-product')}
      </aside>
      <div class="sdia-guidance-focus-content">
        <section class="sdia-guidance-hero"><div><span>TECHNICAL BINDING</span><h2>${escapeHtml(product.name)}</h2><p>${escapeHtml(product.note)}</p></div><strong>SDIA<br><small>GUIDANCE</small></strong></section>
        <div class="sdia-guidance-tree" aria-label="${escapeHtml(product.name)} semantic guidance"><div class="sdia-guidance-tree-root"><span>Product / Platform</span><b>${escapeHtml(product.short)}</b><small>Technical binding — not the business Domain</small></div>${treeRows(product.items)}</div>
        <div class="sdia-guidance-principle"><b>SDIA principle</b><span>Technology is subordinate to the semantic boundary. Use the business capability and integration purpose to select the Domain and Subdomain.</span></div>
      </div>
    </div>`;
  }

  function animateFocusedCard(fromRect) {
    const card = state.overlay?.querySelector('.sdia-guidance-focus-product');
    if (!card || !fromRect) return;
    const toRect = card.getBoundingClientRect();
    const dx = fromRect.left - toRect.left;
    const dy = fromRect.top - toRect.top;
    const sx = fromRect.width / Math.max(1, toRect.width);
    const sy = fromRect.height / Math.max(1, toRect.height);
    card.style.transition = 'none';
    card.style.transformOrigin = 'top left';
    card.style.transform = `translate(${dx}px,${dy}px) scale(${sx},${sy})`;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      card.style.transition = 'transform .38s cubic-bezier(.2,.72,.22,1), box-shadow .38s ease';
      card.style.transform = 'translate(0,0) scale(1)';
    }));
  }

  function focusProduct(productId, fromRect = null) {
    if (!state.overlay) return;
    const productSource = productById(productId);
    if (!productSource) return;
    const product = resolvedProduct(productSource);
    const module = state.overlay.querySelector('[data-sdia-view="domain-help"]');
    const detail = state.overlay.querySelector('#sdia-guidance-detail');
    if (!module || !detail) return;
    if (focusTimer) clearTimeout(focusTimer);
    activeProductId = product.id;
    module.classList.add('is-focusing');
    module.querySelectorAll('.sdia-guidance-product-card').forEach((card) => {
      card.classList.toggle('is-focus-target', card.dataset.sdiaGuidanceProduct === product.id);
      card.classList.toggle('is-focus-exit', card.dataset.sdiaGuidanceProduct !== product.id);
    });
    focusTimer = setTimeout(() => {
      module.classList.remove('is-focusing');
      module.classList.add('is-focus-mode');
      detail.innerHTML = guidanceDetailMarkup(product);
      detail.classList.add('is-visible');
      animateFocusedCard(fromRect);
    }, 190);
  }

  function resetFocus({ animate = true } = {}) {
    if (!state.overlay) return;
    const module = state.overlay.querySelector('[data-sdia-view="domain-help"]');
    const detail = state.overlay.querySelector('#sdia-guidance-detail');
    if (!module || !detail) return;
    if (focusTimer) clearTimeout(focusTimer);
    const finish = () => {
      activeProductId = '';
      module.classList.remove('is-focus-mode','is-unfocusing','is-focusing');
      detail.classList.remove('is-visible');
      detail.innerHTML = '';
      renderProductGroups(filterProducts(state.overlay?.querySelector('#sdia-guidance-search')?.value || ''));
    };
    if (!animate || !module.classList.contains('is-focus-mode')) { finish(); return; }
    module.classList.add('is-unfocusing');
    focusTimer = setTimeout(finish, 180);
  }

  function render(productId = '') {
    if (!state.overlay) return;
    if (productId) { focusProduct(productId); return; }
    resetFocus({ animate:false });
  }

  function filterProducts(query = '') {
    const needle = normalizeText(query); if (!needle) return guidance;
    return guidance.filter((p) => normalizeText(`${p.name} ${p.short} ${p.vendor} ${p.items.map((i) => `${i.name} ${i.domainCode} ${i.subdomainCode}`).join(' ')}`).includes(needle));
  }

  function bind() {
    if (!state.overlay) return;
    const module = state.overlay.querySelector('[data-sdia-view="domain-help"]');
    const search = state.overlay.querySelector('#sdia-guidance-search');
    const clear = state.overlay.querySelector('#sdia-guidance-search-clear');
    if (module && !module.dataset.sdiaGuidanceBound) {
      module.dataset.sdiaGuidanceBound = '1';
      module.addEventListener('click',(event)=>{
        const target = event.target instanceof Element ? event.target : null;
        if (target?.closest('[data-sdia-guidance-back]')) { resetFocus(); return; }
        const button = target?.closest('[data-sdia-guidance-product]');
        if (!button || module.classList.contains('is-focus-mode')) return;
        focusProduct(button.dataset.sdiaGuidanceProduct || '', button.getBoundingClientRect());
      });
    }
    if (search && !search.dataset.sdiaBound) {
      search.dataset.sdiaBound='1';
      search.addEventListener('input',()=>{
        if (module?.classList.contains('is-focus-mode')) return;
        renderProductGroups(filterProducts(search.value));
        clear?.classList.toggle('is-visible',Boolean(search.value.trim()));
      });
    }
    if (clear && !clear.dataset.sdiaBound) {
      clear.dataset.sdiaBound='1';
      clear.addEventListener('click',()=>{
        if(!search)return;
        search.value=''; search.focus(); clear.classList.remove('is-visible');
        if (!module?.classList.contains('is-focus-mode')) renderProductGroups(guidance);
      });
    }
  }

  function markup() {
    return `<section class="sdia-module sdia-hidden" data-sdia-view="domain-help">
      <div class="sdia-module-heading"><span>ODCP · DOMAIN GUIDANCE</span><h1>Domain Help</h1><p>Use product and process context to identify the semantic Domain and Subdomain. These mappings are SDIA guidance; vendor products remain technical bindings.</p></div>
      <div class="sdia-guidance-search-row"><div class="sdia-package-search-box"><i>${icon('scan')}</i><input id="sdia-guidance-search" type="search" autocomplete="off" spellcheck="false" placeholder="Search SuccessFactors, Concur, Workday, Salesforce, RTR, CRM..." aria-label="Search domain guidance"><button id="sdia-guidance-search-clear" class="sdia-package-search-clear" type="button" aria-label="Clear guidance search">×</button></div></div>
      <div id="sdia-guidance-product-groups" class="sdia-guidance-product-groups">
        <section class="sdia-guidance-product-group"><div class="sdia-guidance-group-heading sdia-guidance-sap-heading"><span><img src="${escapeHtml(runtimeUrl('src/shared/vendors/assets/vendor-sap.png'))}" alt="SAP"> SAP PRODUCTS</span><b>Business capabilities delivered through SAP platforms</b></div><div id="sdia-guidance-product-grid-sap" class="sdia-guidance-product-grid"></div></section>
        <section class="sdia-guidance-product-group"><div class="sdia-guidance-group-heading"><span>OTHER VENDORS</span><b>Technical bindings classified by the same semantic Domain model</b></div><div id="sdia-guidance-product-grid-vendors" class="sdia-guidance-product-grid"></div></section>
      </div>
      <section id="sdia-guidance-detail" class="sdia-guidance-detail" aria-live="polite"></section>
      <div class="sdia-scope-banner"><b>Guidance boundary</b><span>Vendor product names help identify context, but they do not become business Domains automatically. Confirm the business process before provisioning artefacts.</span></div>
    </section>`;
  }

  function validateCatalogMappings() {
    const invalid=[]; guidance.forEach((p)=>p.items.forEach((item)=>{ const resolved=resolveItem(item); if(!resolved.valid) invalid.push(`${p.id}:${item.domainCode}/${item.subdomainCode}`); })); return invalid;
  }

  SDIA.GuidanceUI = Object.freeze({ markup, bind, render, validateCatalogMappings });
})();
