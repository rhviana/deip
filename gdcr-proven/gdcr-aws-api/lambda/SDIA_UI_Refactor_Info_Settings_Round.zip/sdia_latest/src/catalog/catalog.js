/* SDIA Governance v0.2.0 — SAP-aligned semantic starter catalog.
 * SAP Line of Business values are the source baseline. Subdomains and canonical
 * technical codes are SDIA governance conventions, not an exhaustive SAP taxonomy.
 */
(() => {
  'use strict';

  const sd = (id, name, canonicalCode, scopeDescription, aliases = []) => ({
    id, name, canonicalCode,
    aliases: [...new Set([canonicalCode, ...aliases])],
    scopeDescription
  });

  const domain = (id, name, canonicalCode, subdomains, aliases = [], description = '') => ({
    id, name, canonicalCode,
    sapLineOfBusiness: name,
    source: 'SAP Business Accelerator Hub — Line of Business',
    aliases: [...new Set([canonicalCode, ...aliases])],
    description,
    subdomains
  });

  const catalog = {
    schemaVersion: '0.5',
    profileName: 'SDIA SAP Semantic Catalog',
    description: 'SAP Line-of-Business-aligned starter taxonomy for SDIA governance. Canonical codes drive new package names; aliases classify legacy names.',
    taxonomyNote: 'SAP Line of Business values are the source baseline. Subdomains and canonical technical codes are SDIA governance conventions and are intentionally extensible.',
    divisions: [],
    domains: [
      domain('asset-management', 'Asset Management', 'asset', [
        sd('enterprise-asset-management','Enterprise Asset Management','eam','enterprise asset lifecycle and maintenance integration processes',['asset management']),
        sd('asset-performance','Asset Performance Management','apm','asset performance, condition and reliability integration processes'),
        sd('maintenance-management','Maintenance Management','maint','maintenance planning and execution integration processes',['maintenance']),
        sd('work-order-management','Work Order Management','wo','maintenance work-order integration processes',['work orders']),
        sd('preventive-maintenance','Preventive Maintenance','pm','preventive maintenance plans and schedules'),
        sd('predictive-maintenance','Predictive Maintenance','pred','predictive maintenance and condition-based intervention processes'),
        sd('asset-master','Asset Master Data','master','equipment, functional location and asset master integration processes'),
        sd('reliability','Reliability Management','rel','reliability engineering and failure-management integration processes'),
        sd('inspection-calibration','Inspection & Calibration','insp','inspection, calibration and measurement integration processes'),
        sd('spare-parts','Spare Parts','spares','maintenance spare-part planning and consumption integration processes'),
        sd('shutdown-turnaround','Shutdown & Turnaround','sto','shutdown and turnaround planning integration processes'),
        sd('asset-accounting','Asset Accounting','aa','asset capitalization, valuation and accounting integration processes')
      ], ['assets','eam'], 'Asset lifecycle, maintenance, performance and reliability governance.'),

      domain('customer', 'Customer', 'cust', [
        sd('customer-master','Customer Master','master','customer master, account and business-partner integration processes',['customer data']),
        sd('customer-identity','Customer Identity','id','customer identity and authentication-related business data integration processes'),
        sd('customer-profile','Customer Profile','profile','customer profile and preference integration processes'),
        sd('customer-insights','Customer Insights','insight','customer analytics, insight and profile enrichment integration processes'),
        sd('customer-segmentation','Customer Segmentation','seg','customer audience and segmentation integration processes'),
        sd('customer-loyalty','Customer Loyalty','loy','loyalty account, points, tier and reward integration processes'),
        sd('consent-preferences','Consent & Preferences','consent','customer consent, preference and communication-permission integration processes'),
        sd('customer-onboarding','Customer Onboarding','onb','customer onboarding and activation integration processes'),
        sd('customer-hierarchy','Customer Hierarchy','hier','customer, account and organizational hierarchy integration processes'),
        sd('customer-360','Customer 360','c360','unified customer-view and customer-data consolidation integration processes'),
        sd('customer-interactions','Customer Interactions','int','customer interaction and touchpoint history integration processes'),
        sd('customer-data-quality','Customer Data Quality','dq','customer deduplication, validation and data-quality integration processes')
      ], ['customer management'], 'Customer identity, profile, relationship and engagement boundaries.'),

      domain('commerce', 'Commerce', 'com', [
        sd('catalog-product','Catalog & Product','catalog','commerce catalog, assortment and product integration processes',['product catalog']),
        sd('ecommerce','E-Commerce','ecom','B2B, B2C and digital storefront integration processes',['e-commerce']),
        sd('commerce-pricing','Commerce Pricing','price','commerce price, promotion and discount integration processes'),
        sd('commerce-order','Commerce Order Management','ord','digital commerce order integration processes',['order management']),
        sd('checkout-payment','Checkout & Payment','pay','checkout, payment and commerce transaction integration processes',['payment']),
        sd('shopping-cart','Shopping Cart','cart','cart, basket and pre-order integration processes'),
        sd('commerce-fulfillment','Commerce Fulfillment','fulf','commerce fulfillment, shipment and delivery integration processes'),
        sd('returns-refunds','Returns & Refunds','ret','commerce return, refund and cancellation integration processes'),
        sd('subscriptions','Subscriptions','sub','commerce subscription and recurring-order integration processes'),
        sd('marketplace','Marketplace','mktp','marketplace seller, offer and transaction integration processes'),
        sd('store-pos','Store & POS','pos','store, point-of-sale and omnichannel transaction integration processes'),
        sd('availability','Availability','avail','inventory availability and promise integration processes'),
        sd('commerce-customer','Commerce Customer','cust','commerce account and shopper-profile integration processes')
      ], ['ecommerce','e-commerce'], 'Digital commerce, catalog, transaction and fulfillment boundaries.'),

      domain('finance', 'Finance', 'fin', [
        sd('record-to-report','Record to Report','rtr','Record-to-Report and general-ledger integration processes',['r2r','record to report']),
        sd('accounts-payable','Accounts Payable','ap','accounts payable and supplier invoice integration processes'),
        sd('accounts-receivable','Accounts Receivable','ar','accounts receivable and customer accounting integration processes'),
        sd('treasury','Treasury','tre','treasury, liquidity and financial-risk integration processes'),
        sd('controlling','Controlling','co','management accounting, cost and controlling integration processes'),
        sd('fixed-assets','Fixed Asset Accounting','fa','fixed asset capitalization, depreciation and valuation integration processes'),
        sd('tax','Tax','tax','tax calculation, determination and reporting integration processes'),
        sd('cash-management','Cash Management','cash','bank balance, cash position and liquidity integration processes'),
        sd('financial-close','Financial Close','close','financial close, reconciliation and period-end integration processes'),
        sd('consolidation','Financial Consolidation','cons','group reporting and financial-consolidation integration processes'),
        sd('expense-management','Expense Management','exp','employee expense, reimbursement and corporate-card integration processes'),
        sd('invoice-management','Invoice Management','inv','invoice capture, validation and invoice workflow integration processes'),
        sd('credit-management','Credit Management','cred','customer credit, exposure and credit-limit integration processes'),
        sd('collections','Collections','coll','collection, dispute and receivable follow-up integration processes'),
        sd('intercompany','Intercompany','ic','intercompany transaction, reconciliation and settlement integration processes')
      ], ['finance','financial','fi','accounting','controlling'], 'Financial accounting, management accounting, treasury and financial-operation governance.'),

      domain('human-resources', 'Human Resources', 'hr', [
        sd('core-employee-central','CORE / Employee Central','core','employee master, employment, organization and core workforce integration processes',['employee central','ec']),
        sd('recruiting','Recruiting','rec','recruiting and talent-acquisition integration processes'),
        sd('onboarding','Onboarding','onb','employee onboarding and new-hire integration processes'),
        sd('learning','Learning','lrn','learning, training and certification integration processes',['lms']),
        sd('time','Time Management','time','time tracking, attendance and working-time integration processes',['time management']),
        sd('absence','Absence Management','abs','absence, leave and time-off integration processes',['time off']),
        sd('payroll','Payroll','pay','payroll, payroll result and pay-statement integration processes'),
        sd('employee-services','Employee Services','svc','employee service, HR case and employee-journey integration processes',['hr service delivery','employee service']),
        sd('talent','Talent Management','tal','talent profile, talent review and development integration processes'),
        sd('performance','Performance Management','perf','performance objective, review and appraisal integration processes'),
        sd('compensation','Compensation','comp','compensation planning, award and salary integration processes'),
        sd('benefits','Benefits','ben','employee benefit enrollment and provider integration processes'),
        sd('workforce-planning','Workforce Planning','wfp','headcount, workforce demand and workforce-plan integration processes'),
        sd('workforce-management','Workforce Management','wfm','workforce scheduling and operational workforce integration processes'),
        sd('succession','Succession','succ','succession planning and talent-pipeline integration processes'),
        sd('offboarding','Offboarding','off','employee termination and offboarding integration processes'),
        sd('people-analytics','People Analytics','ana','workforce analytics and HR reporting integration processes')
      ], ['hr','rh','hcm','people','workforce'], 'Workforce, employee lifecycle, payroll and talent governance.'),

      domain('it', 'IT', 'it', [
        sd('identity-access','Identity & Access Management','iam','identity lifecycle, role and access integration processes',['identity','access management']),
        sd('service-management','IT Service Management','itsm','IT service-management integration processes',['service management']),
        sd('incident-management','Incident Management','inc','incident and operational interruption integration processes'),
        sd('problem-management','Problem Management','prb','problem and root-cause integration processes'),
        sd('change-management','Change Management','chg','change request and change-control integration processes'),
        sd('service-request','Service Request','req','IT request and service-catalog integration processes'),
        sd('it-asset-management','IT Asset Management','asset','hardware and software asset integration processes'),
        sd('cmdb','Configuration Management','cmdb','configuration item and CMDB integration processes'),
        sd('platform-operations','Platform Operations','plat','platform runtime and administrative integration processes',['platform']),
        sd('observability','Observability','obs','monitoring, alerting and operational telemetry integration processes',['monitoring']),
        sd('cloud-operations','Cloud Operations','cloud','cloud resource and cloud-operation integration processes'),
        sd('endpoint-management','Endpoint Management','endp','device and endpoint management integration processes'),
        sd('integration-platform','Integration Platform','ipaas','integration platform governance and operational integration processes'),
        sd('service-catalog','Service Catalog','cat','service catalog and offering integration processes'),
        sd('automation','IT Automation','auto','IT workflow automation and orchestration integration processes')
      ], ['information technology'], 'Technology platform, identity, IT operations and service-management boundaries.'),

      domain('manufacturing', 'Manufacturing', 'mfg', [
        sd('production-planning','Production Planning','pp','production planning and manufacturing demand integration processes'),
        sd('shop-floor-execution','Shop Floor Execution','sfc','shop-floor and production execution integration processes',['shop floor']),
        sd('manufacturing-operations','Manufacturing Operations','ops','manufacturing operations and production orchestration integration processes'),
        sd('quality-management','Quality Management','qm','quality inspection and manufacturing quality integration processes'),
        sd('manufacturing-execution','Manufacturing Execution','mes','manufacturing execution system and production-control integration processes'),
        sd('production-scheduling','Production Scheduling','sched','production sequencing and detailed scheduling integration processes'),
        sd('production-orders','Production Orders','po','production order and execution-status integration processes'),
        sd('material-staging','Material Staging','stage','production material staging and line-supply integration processes'),
        sd('traceability','Traceability','trace','batch, serial and genealogy integration processes'),
        sd('oee-performance','OEE & Performance','oee','overall equipment effectiveness and production-performance integration processes'),
        sd('batch-management','Batch Management','batch','manufacturing batch and lot integration processes'),
        sd('production-confirmation','Production Confirmation','conf','production confirmation, yield and scrap integration processes')
      ], ['production'], 'Production, quality, shop-floor and manufacturing-operation governance.'),

      domain('marketing', 'Marketing', 'mkt', [
        sd('campaign-management','Campaign Management','camp','campaign orchestration and marketing execution integration processes'),
        sd('lead-management','Lead Management','lead','marketing lead and sales-handover integration processes'),
        sd('segmentation','Audience Segmentation','seg','audience, segment and marketing profile integration processes'),
        sd('customer-journeys','Customer Journeys','journey','customer journey and multistep engagement integration processes'),
        sd('marketing-consent','Marketing Consent','consent','marketing consent and communication-preference integration processes'),
        sd('content-management','Marketing Content','content','marketing asset and content integration processes'),
        sd('email-mobile','Email & Mobile','msg','email, SMS, push and mobile messaging integration processes'),
        sd('marketing-analytics','Marketing Analytics','ana','marketing measurement and performance integration processes'),
        sd('attribution','Attribution','attr','marketing attribution and conversion integration processes'),
        sd('event-marketing','Event Marketing','event','marketing event, webinar and attendee integration processes'),
        sd('demand-generation','Demand Generation','dgen','demand-generation and nurture integration processes'),
        sd('marketing-automation','Marketing Automation','auto','marketing automation and campaign-trigger integration processes')
      ], ['marketing'], 'Marketing execution, audience, journey and campaign boundaries.'),

      domain('rd-engineering', 'R&D Engineering', 'rnd', [
        sd('product-lifecycle','Product Lifecycle Management','plm','product lifecycle and engineering master integration processes'),
        sd('engineering-change','Engineering Change Management','ecm','engineering change and release integration processes'),
        sd('product-development','Product Development','dev','product development and design collaboration integration processes'),
        sd('bill-of-material','Bill of Material','bom','engineering BOM and product-structure integration processes'),
        sd('engineering-document','Engineering Document Management','doc','engineering document and drawing integration processes'),
        sd('specification-management','Specification Management','spec','product specification and technical requirement integration processes'),
        sd('recipe-formula','Recipe & Formula','recipe','recipe, formula and process-definition integration processes'),
        sd('variant-configuration','Variant Configuration','vc','product configuration and variant integration processes'),
        sd('cad-integration','CAD Integration','cad','CAD metadata and engineering-content integration processes'),
        sd('product-compliance','Product Compliance','comp','product compliance and regulatory integration processes'),
        sd('innovation-management','Innovation Management','innov','innovation pipeline and idea integration processes'),
        sd('engineering-project','Engineering Project','proj','engineering project and milestone integration processes')
      ], ['r&d engineering','research development'], 'Product engineering, lifecycle, specification and engineering-change governance.'),

      domain('sales', 'Sales', 'sales', [
        sd('order-to-cash','Order to Cash','otc','Order-to-Cash integration processes',['o2c','order to cash']),
        sd('lead-to-cash','Lead to Cash','ltc','Lead-to-Cash integration processes',['lead to cash']),
        sd('customer-relationship-management','Customer Relationship Management','crm','customer relationship, account and contact integration processes',['crm']),
        sd('configure-price-quote','Configure, Price & Quote','cpq','configure-price-quote and commercial quotation integration processes',['configure price quote','revenue cloud']),
        sd('pricing','Pricing','price','sales pricing and condition integration processes'),
        sd('billing','Billing','bill','sales billing and billing-document integration processes'),
        sd('lead-management','Lead Management','lead','sales lead qualification and conversion integration processes'),
        sd('opportunity-management','Opportunity Management','opp','sales opportunity and pipeline integration processes'),
        sd('quotation','Quotation','quote','sales quotation and proposal integration processes'),
        sd('sales-order','Sales Order Management','ord','sales order creation and management integration processes'),
        sd('partner-management','Partner Relationship Management','prm','channel partner and partner-sales integration processes'),
        sd('subscription-revenue','Subscription & Revenue','rev','subscription, recurring revenue and revenue-lifecycle integration processes'),
        sd('sales-contracts','Sales Contracts','ctr','sales contract and commercial-agreement integration processes'),
        sd('sales-performance','Sales Performance','spm','sales target, territory, commission and performance integration processes'),
        sd('sales-forecast','Sales Forecast','fcst','sales forecast and pipeline prediction integration processes')
      ], ['sales','commercial'], 'Commercial sales lifecycle, customer relationship and revenue governance.'),

      domain('service', 'Service', 'svc', [
        sd('customer-service-management','Customer Service Management','csm','customer-service case, resolution and service-management integration processes',['customer service','service cloud']),
        sd('service-order','Service Order Management','som','service order and service execution integration processes'),
        sd('field-service','Field Service','fsm','field-service planning and execution integration processes'),
        sd('service-contracts','Service Contracts','ctr','service contract and entitlement integration processes'),
        sd('returns-repair','Returns & Repair','repair','service return, repair and depot integration processes'),
        sd('case-management','Case Management','case','customer case and issue-resolution integration processes'),
        sd('warranty','Warranty','war','warranty claim and warranty-entitlement integration processes'),
        sd('entitlement','Service Entitlement','ent','service entitlement and coverage integration processes'),
        sd('knowledge','Knowledge Management','know','service knowledge and article integration processes'),
        sd('service-scheduling','Service Scheduling','sched','service appointment and capacity scheduling integration processes'),
        sd('dispatch','Dispatch','disp','technician dispatch and assignment integration processes'),
        sd('installed-base','Installed Base','ibase','installed product, equipment and customer-asset integration processes'),
        sd('service-parts','Service Parts','parts','service spare-parts and parts-availability integration processes'),
        sd('depot-repair','Depot Repair','depot','depot repair and repair-center integration processes'),
        sd('omnichannel-service','Omnichannel Service','omni','customer service channel and interaction integration processes')
      ], ['service'], 'Customer service, field service, repair and service-contract boundaries.'),

      domain('sourcing-procurement', 'Sourcing and Procurement', 'proc', [
        sd('source-to-pay','Source to Pay','stp','Source-to-Pay integration processes',['s2p','source to pay']),
        sd('procure-to-pay','Procure to Pay','ptp','Procure-to-Pay integration processes',['p2p','procure to pay']),
        sd('sourcing','Sourcing','src','strategic sourcing and sourcing-event integration processes'),
        sd('purchasing','Purchasing','pur','requisition, purchase-order and purchasing integration processes'),
        sd('supplier-management','Supplier Management','sup','supplier lifecycle, qualification and supplier-data integration processes'),
        sd('supplier-onboarding','Supplier Onboarding','onb','supplier onboarding and registration integration processes'),
        sd('procurement-contracts','Procurement Contracts','ctr','procurement contract and agreement integration processes'),
        sd('requisition','Requisition Management','req','purchase requisition and approval integration processes'),
        sd('procurement-invoicing','Procurement Invoicing','inv','supplier invoice and procurement invoice integration processes'),
        sd('spend-analytics','Spend Analytics','spend','spend visibility, classification and analytics integration processes'),
        sd('category-management','Category Management','cat','procurement category strategy and category-plan integration processes'),
        sd('supplier-risk','Supplier Risk','risk','supplier risk, compliance and monitoring integration processes'),
        sd('business-network','Business Network','bn','buyer-supplier network transaction integration processes'),
        sd('catalog-management','Procurement Catalog','catalog','supplier and procurement catalog integration processes'),
        sd('procurement-workflow','Procurement Workflow','wf','procurement intake, case and approval workflow integration processes'),
        sd('direct-procurement','Direct Procurement','direct','direct-material procurement integration processes'),
        sd('indirect-procurement','Indirect Procurement','indirect','indirect-goods and services procurement integration processes')
      ], ['procurement','purchasing','sourcing'], 'Sourcing, procurement, supplier and spend governance.'),

      domain('supply-chain', 'Supply Chain', 'log', [
        sd('logistics-execution','Logistics Execution','le','delivery, shipment and logistics-execution integration processes',['logistics']),
        sd('warehouse-management','Warehouse Management','wh','warehouse, storage and material-movement integration processes',['warehouse']),
        sd('transportation','Transportation Management','tm','transportation planning, execution and freight integration processes'),
        sd('inventory','Inventory Management','inv','inventory, stock and material-balance integration processes'),
        sd('planning','Supply Chain Planning','plan','supply-chain planning integration processes'),
        sd('fulfillment','Fulfillment','fulf','order fulfillment and distribution integration processes'),
        sd('demand-planning','Demand Planning','dem','demand forecast and demand-planning integration processes'),
        sd('supply-planning','Supply Planning','sup','supply plan, capacity and supply-response integration processes'),
        sd('sales-operations-planning','Sales & Operations Planning','sop','S&OP and integrated planning integration processes'),
        sd('replenishment','Replenishment','repl','inventory replenishment and deployment integration processes'),
        sd('order-promising','Order Promising','atp','available-to-promise and order-promise integration processes'),
        sd('inbound-logistics','Inbound Logistics','inb','inbound delivery, receiving and inbound logistics integration processes'),
        sd('outbound-logistics','Outbound Logistics','out','outbound delivery, picking and shipping integration processes'),
        sd('yard-management','Yard Management','yard','yard, dock and gate integration processes'),
        sd('global-trade','Global Trade','gtm','customs, trade compliance and cross-border logistics integration processes'),
        sd('supply-visibility','Supply Chain Visibility','vis','supply visibility, control-tower and exception integration processes')
      ], ['logistics','supply-chain','scm'], 'Planning, inventory, warehouse, transportation and fulfillment governance.'),

      domain('sustainability', 'Sustainability', 'sus', [
        sd('esg-reporting','ESG Reporting','esg','ESG disclosure and reporting integration processes'),
        sd('carbon-accounting','Carbon Accounting','carbon','carbon accounting and emissions integration processes'),
        sd('product-footprint','Product Footprint','pcf','product carbon footprint integration processes'),
        sd('supplier-sustainability','Supplier Sustainability','sup','supplier sustainability and ESG assessment integration processes'),
        sd('energy-management','Energy Management','energy','energy consumption and efficiency integration processes'),
        sd('waste-management','Waste Management','waste','waste, disposal and recycling integration processes'),
        sd('water-management','Water Management','water','water consumption and stewardship integration processes'),
        sd('circular-economy','Circular Economy','circ','circularity, reuse and material-cycle integration processes'),
        sd('sustainability-compliance','Sustainability Compliance','comp','environmental compliance and regulatory integration processes'),
        sd('climate-risk','Climate Risk','risk','climate risk and resilience integration processes'),
        sd('sustainable-procurement','Sustainable Procurement','proc','sustainable sourcing and procurement integration processes'),
        sd('emissions-management','Emissions Management','emis','scope emissions and emission-factor integration processes')
      ], ['sustainability','esg'], 'Environmental, ESG, carbon and sustainability governance.'),

      domain('metering', 'Metering', 'met', [
        sd('meter-master','Meter Master','master','meter and metering-point master integration processes'),
        sd('meter-reading','Meter Reading','read','meter reading and register-value integration processes'),
        sd('interval-data','Interval Data','int','interval consumption and time-series metering integration processes'),
        sd('smart-meter','Smart Meter','smart','smart meter lifecycle and communication integration processes'),
        sd('device-management','Device Management','dev','metering device installation, replacement and lifecycle integration processes'),
        sd('meter-events','Meter Events','event','meter event, alarm and exception integration processes'),
        sd('consumption','Consumption','cons','consumption aggregation and usage integration processes'),
        sd('billing-determinants','Billing Determinants','bill','meter-derived billing determinant integration processes'),
        sd('field-collection','Field Collection','field','field reading and collection integration processes'),
        sd('ami','Advanced Metering Infrastructure','ami','AMI head-end and metering infrastructure integration processes'),
        sd('meter-settlement','Meter Settlement','settle','meter settlement and profile integration processes')
      ], ['meter'], 'Meter, consumption and utility-device governance.'),

      domain('grid-operations-maintenance', 'Grid Operations and Maintenance', 'grid', [
        sd('grid-operations','Grid Operations','ops','grid operational state and control integration processes'),
        sd('outage-management','Outage Management','out','outage, restoration and interruption integration processes'),
        sd('network-assets','Network Assets','asset','grid network asset integration processes'),
        sd('switching','Switching','switch','switching order and switching-state integration processes'),
        sd('grid-work-management','Grid Work Management','work','grid work order and field-work integration processes'),
        sd('distributed-energy','Distributed Energy Resources','der','distributed energy resource integration processes'),
        sd('grid-connectivity','Grid Connectivity','conn','network topology and connectivity integration processes'),
        sd('grid-planning','Grid Planning','plan','grid expansion and capacity planning integration processes'),
        sd('load-management','Load Management','load','grid load and demand-response integration processes'),
        sd('grid-reliability','Grid Reliability','rel','reliability and service-quality integration processes'),
        sd('grid-inspection','Grid Inspection','insp','grid asset inspection and condition integration processes')
      ], ['grid'], 'Utility grid operation, outage, network asset and maintenance governance.'),

      domain('plant-operations-maintenance', 'Plant Operations and Maintenance', 'plant', [
        sd('plant-operations','Plant Operations','ops','plant operation and operating-condition integration processes'),
        sd('maintenance-execution','Maintenance Execution','maint','plant maintenance execution integration processes'),
        sd('plant-inspection','Plant Inspection','insp','plant inspection and condition integration processes'),
        sd('shift-management','Shift Management','shift','shift handover and shift-log integration processes'),
        sd('permit-to-work','Permit to Work','ptw','permit-to-work and work-authorization integration processes'),
        sd('work-clearance','Work Clearance','wc','work clearance and isolation integration processes'),
        sd('operator-rounds','Operator Rounds','round','operator round and field-observation integration processes'),
        sd('operations-log','Operations Log','logbook','operations log and event journal integration processes'),
        sd('plant-safety','Plant Safety','safe','plant safety and operational-risk integration processes'),
        sd('turnaround','Turnaround','ta','plant turnaround and shutdown integration processes'),
        sd('plant-performance','Plant Performance','perf','plant performance and KPI integration processes')
      ], ['plant'], 'Plant operation, maintenance, inspection and work-safety governance.'),

      domain('maintenance-engineering', 'Maintenance and Engineering', 'mne', [
        sd('maintenance-planning','Maintenance Planning','plan','maintenance planning and scheduling integration processes'),
        sd('engineering-master','Engineering Master Data','master','engineering technical-object and master-data integration processes'),
        sd('maintenance-work-order','Maintenance Work Order','wo','maintenance order and execution integration processes'),
        sd('preventive-maintenance','Preventive Maintenance','pm','preventive maintenance plan integration processes'),
        sd('corrective-maintenance','Corrective Maintenance','cm','corrective maintenance and failure-response integration processes'),
        sd('predictive-maintenance','Predictive Maintenance','pred','predictive and condition-based maintenance integration processes'),
        sd('reliability-engineering','Reliability Engineering','rel','reliability analysis and failure-mode integration processes'),
        sd('technical-objects','Technical Objects','tech','equipment, functional location and technical-object integration processes'),
        sd('maintenance-spares','Maintenance Spares','spares','maintenance spare-part and reservation integration processes'),
        sd('shutdown-turnaround','Shutdown & Turnaround','sto','maintenance shutdown and turnaround integration processes'),
        sd('engineering-documents','Engineering Documents','doc','engineering document and maintenance-document integration processes'),
        sd('maintenance-scheduling','Maintenance Scheduling','sched','resource and maintenance schedule integration processes')
      ], ['maintenance engineering'], 'Maintenance planning, engineering master, reliability and execution governance.')
    ]
  };

  globalThis.SDIA_DEFAULT_CATALOG = catalog;
})();
