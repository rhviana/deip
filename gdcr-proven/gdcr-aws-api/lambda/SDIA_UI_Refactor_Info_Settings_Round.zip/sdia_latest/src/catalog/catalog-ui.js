/* SDIA Governance v0.2.0 — visual Semantic Domain Catalog workspace. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { state, escapeHtml, normalizeToken, icon } = SDIA.Core;
  let activeDomainId = '';
  let focusTimer = null;

  function canonicalCode(item) {
    return normalizeToken(item?.canonicalCode || item?.id || '');
  }

  function domainById(value) {
    const token = normalizeToken(value);
    return (state.catalog.domains || []).find((item) => {
      const candidates = [item.id, item.canonicalCode, ...(item.aliases || [])].map(normalizeToken).filter(Boolean);
      return candidates.includes(token);
    }) || null;
  }

  function domainCardMarkup(item, extraClass = '') {
    const code = canonicalCode(item).toUpperCase();
    const count = (item.subdomains || []).length;
    const active = normalizeToken(item.id) === normalizeToken(activeDomainId);
    return `<button type="button" class="sdia-catalog-domain-card${active ? ' active' : ''}${extraClass ? ` ${extraClass}` : ''}" data-sdia-catalog-domain="${escapeHtml(item.id)}" aria-pressed="${active ? 'true' : 'false'}">
      <span class="sdia-catalog-domain-card-top"><i>${icon('catalog')}</i><em>${escapeHtml(code)}</em></span>
      <b>${escapeHtml(item.name || item.id)}</b>
      <small>${count} governed ${count === 1 ? 'subdomain' : 'subdomains'}</small>
    </button>`;
  }

  function subdomainTreeMarkup(domain) {
    const subdomains = domain?.subdomains || [];
    if (!subdomains.length) return '<div class="sdia-catalog-tree-empty">No SDIA starter subdomains are registered for this Domain.</div>';
    const rows = [];
    for (let i = 0; i < subdomains.length; i += 5) rows.push(subdomains.slice(i, i + 5));
    let cursor = 0;
    const levels = rows.map((row, rowIndex) => {
      const startIndex = cursor;
      cursor += row.length;
      return `<section class="sdia-catalog-org-level" style="--sdia-org-level-count:${row.length};--sdia-org-level-delay:${180 + rowIndex * 120}ms">
        <i class="sdia-catalog-org-level-stem" aria-hidden="true"></i>
        <i class="sdia-catalog-org-level-rail" aria-hidden="true"></i>
        <div class="sdia-catalog-org-level-grid">
          ${row.map((subdomain, index) => `<article class="sdia-catalog-org-child" style="--sdia-org-delay:${220 + (startIndex + index) * 55}ms">
            <i aria-hidden="true"></i>
            <div class="sdia-catalog-org-node">
              <span>Subdomain</span>
              <b>${escapeHtml(subdomain.name || subdomain.id)}</b>
              <code>${escapeHtml(canonicalCode(subdomain).toUpperCase())}</code>
              <small>${escapeHtml(subdomain.scopeDescription || 'Governed integration scope')}</small>
            </div>
          </article>`).join('')}
        </div>
      </section>`;
    }).join('');
    return `<div class="sdia-catalog-org-chart" aria-label="${escapeHtml(domain.name)} semantic taxonomy">
      <div class="sdia-catalog-org-root">
        <span>Domain</span><b>${escapeHtml(domain.name)}</b><code>${escapeHtml(canonicalCode(domain).toUpperCase())}</code>
      </div>
      ${levels}
    </div>`;
  }

  function detailMarkup(domain) {
    const code = canonicalCode(domain).toUpperCase();
    const aliases = [...new Set([domain.id, ...(domain.aliases || [])].map((value) => String(value).trim()).filter(Boolean))]
      .filter((value) => normalizeToken(value) !== normalizeToken(domain.canonicalCode));
    const firstSubdomain = (domain.subdomains || [])[0];
    const example = firstSubdomain ? `acme.br.${canonicalCode(domain)}.${canonicalCode(firstSubdomain)}.integrations` : `acme.br.${canonicalCode(domain)}.integrations`;
    return `<div class="sdia-catalog-focus-content">
      <div class="sdia-catalog-domain-hero">
        <div><span>SEMANTIC DOMAIN</span><h2>${escapeHtml(domain.name)}</h2><p>${escapeHtml(domain.description || 'Semantic governance boundary for SAP Integration Suite artefacts.')}</p></div>
        <strong>${escapeHtml(code)}</strong>
      </div>
      <div class="sdia-catalog-domain-meta">
        <div><span>Canonical Code</span><b>${escapeHtml(code)}</b><small>Generated in new governed package names.</small></div>
        <div><span>Legacy Aliases Recognized</span><b>${escapeHtml(aliases.slice(0, 6).join(' · ') || 'None')}</b><small>Accepted for legacy classification; never generated for new packages.</small></div>
        <div><span>Package Boundary Example</span><b class="sdia-catalog-example">${escapeHtml(example)}</b><small>Company and Division remain optional scopes.</small></div>
      </div>
      <div class="sdia-catalog-tree-heading"><span>SEMANTIC TAXONOMY</span><b>${escapeHtml(domain.name)} → governed Subdomains</b></div>
      ${subdomainTreeMarkup(domain)}
    </div>`;
  }

  function renderGrid() {
    const domains = state.catalog.domains || [];
    const grid = state.overlay?.querySelector('#sdia-catalog-domain-grid');
    const summary = state.overlay?.querySelector('#sdia-catalog-summary');
    if (summary) summary.textContent = `${domains.length} SAP Line of Business domains · ${domains.reduce((sum, item) => sum + (item.subdomains || []).length, 0)} SDIA starter subdomains`;
    if (grid) grid.innerHTML = domains.map(domainCardMarkup).join('');
  }

  function animateFocusedCard(fromRect) {
    const card = state.overlay?.querySelector('.sdia-catalog-focus-domain');
    if (!card || !fromRect) return;
    const toRect = card.getBoundingClientRect();
    const dx = fromRect.left - toRect.left;
    const dy = fromRect.top - toRect.top;
    const sx = fromRect.width / Math.max(1, toRect.width);
    const sy = fromRect.height / Math.max(1, toRect.height);
    card.style.transition = 'none';
    card.style.transformOrigin = 'top left';
    card.style.transform = `translate(${dx}px,${dy}px) scale(${sx},${sy})`;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      card.style.transition = 'transform .4s cubic-bezier(.2,.72,.22,1), box-shadow .4s ease';
      card.style.transform = 'translate(0,0) scale(1)';
    }));
  }

  function focusDomain(domainId, fromRect = null) {
    if (!state.overlay) return;
    const domain = domainById(domainId);
    if (!domain) return;
    const module = state.overlay.querySelector('[data-sdia-view="catalog"]');
    const detail = state.overlay.querySelector('#sdia-catalog-domain-detail');
    if (!module || !detail) return;
    if (focusTimer) clearTimeout(focusTimer);
    activeDomainId = domain.id;
    module.classList.add('is-focusing');
    module.querySelectorAll('.sdia-catalog-domain-card').forEach((card) => {
      card.classList.toggle('is-focus-target', card.dataset.sdiaCatalogDomain === domain.id);
      card.classList.toggle('is-focus-exit', card.dataset.sdiaCatalogDomain !== domain.id);
    });
    focusTimer = setTimeout(() => {
      module.classList.remove('is-focusing');
      module.classList.add('is-focus-mode');
      const grid = state.overlay.querySelector('#sdia-catalog-domain-grid');
      if (grid) grid.innerHTML = `<button type="button" class="sdia-focus-back" data-sdia-catalog-back>← All Domains</button>${domainCardMarkup(domain, 'sdia-catalog-focus-domain')}`;
      detail.innerHTML = detailMarkup(domain);
      detail.classList.add('is-visible');
      animateFocusedCard(fromRect);
    }, 190);
  }

  function resetFocus({ animate = true } = {}) {
    if (!state.overlay) return;
    const module = state.overlay.querySelector('[data-sdia-view="catalog"]');
    const detail = state.overlay.querySelector('#sdia-catalog-domain-detail');
    if (!module || !detail) return;
    if (focusTimer) clearTimeout(focusTimer);
    const finish = () => {
      activeDomainId = '';
      module.classList.remove('is-focus-mode','is-unfocusing','is-focusing');
      detail.classList.remove('is-visible');
      detail.innerHTML = '';
      renderGrid();
    };
    if (!animate || !module.classList.contains('is-focus-mode')) { finish(); return; }
    module.classList.add('is-unfocusing');
    focusTimer = setTimeout(finish, 180);
  }

  function render(preferredDomainId = '') {
    if (!state.overlay) return;
    if (preferredDomainId) { focusDomain(preferredDomainId); return; }
    resetFocus({ animate:false });
  }

  function markup() {
    return `<section class="sdia-module sdia-hidden" data-sdia-view="catalog">
      <div class="sdia-module-heading"><span>SEMANTIC DOMAIN CATALOG</span><h1>Domain Governance Catalog</h1><p>Browse the semantic model that governs Integration Suite artefacts. SAP Line of Business terminology is the baseline; canonical codes and Subdomains are SDIA governance conventions.</p></div>
      <div class="sdia-catalog-toolbar"><div><b id="sdia-catalog-summary">Semantic catalog</b><span>${escapeHtml(state.catalog.taxonomyNote || 'Canonical codes drive technical naming; aliases preserve legacy classification.')}</span></div></div>
      <div id="sdia-catalog-focus-stage" class="sdia-catalog-focus-stage">
        <div id="sdia-catalog-domain-grid" class="sdia-catalog-domain-grid" aria-label="Semantic Domains"></div>
        <section id="sdia-catalog-domain-detail" class="sdia-catalog-domain-detail" aria-live="polite"></section>
      </div>
      <div class="sdia-scope-banner"><b>Catalog integrity</b><span>SAP Line of Business names are the source baseline. The Subdomain taxonomy is an SDIA starter model and is intentionally extensible; it is not presented as an exhaustive SAP-owned taxonomy.</span></div>
    </section>`;
  }

  function bind() {
    if (!state.overlay) return;
    const module = state.overlay.querySelector('[data-sdia-view="catalog"]');
    if (!module || module.dataset.sdiaCatalogBound) return;
    module.dataset.sdiaCatalogBound = '1';
    module.addEventListener('click', (event) => {
      const target = event.target instanceof Element ? event.target : null;
      if (target?.closest('[data-sdia-catalog-back]')) { resetFocus(); return; }
      const button = target?.closest('[data-sdia-catalog-domain]');
      if (!button || module.classList.contains('is-focus-mode')) return;
      focusDomain(button.dataset.sdiaCatalogDomain || '', button.getBoundingClientRect());
    });
  }

  SDIA.CatalogUI = Object.freeze({ markup, bind, render });
})();
