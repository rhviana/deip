/* SDIA Governance — shared navigation experience.
 * Owns only the optional transition splash lifecycle. Domain modules register
 * their own copy, scene markup and scene-specific CSS.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { state, escapeHtml } = SDIA.Core;
  const registry = new Map();

  const PHASE_COPY = Object.freeze({
    'locating-native-route': 'Locating the native SAP execution context…',
    'opening-native-route': 'Loading SAP context behind SDIA…',
    'ready': 'SAP context ready.',
    'error': 'The SAP context could not be opened.'
  });

  function register(actionId, config = {}) {
    const id = String(actionId || '').trim();
    if (!id) return;
    registry.set(id, Object.freeze({ ...config, id }));
  }

  function config(actionId) { return registry.get(String(actionId || '').trim()) || null; }
  function enabled() { return state.settings.transitionSplashEnabled !== false; }

  function currentAccent() {
    const themeId = SDIA.VisualExperience?.currentTheme?.() || 'emerald-green';
    const theme = SDIA.VisualExperience?.THEMES?.find?.((item) => item.id === themeId);
    return theme?.swatch || '#17A66D';
  }

  function closeNode(node) {
    if (!(node instanceof Element) || !node.isConnected) return;
    node.classList.add('is-closing');
    setTimeout(() => node.remove(), 220);
  }

  function open(actionId, options = {}) {
    if (!enabled()) return null;
    const spec = config(actionId);
    if (!spec) return null;
    const controlCenter = options.host || state.overlay?.querySelector('.sdia-control-center');
    if (!(controlCenter instanceof Element)) return null;

    controlCenter.querySelector('.sdia-navigation-splash')?.remove();
    const node = document.createElement('section');
    node.className = 'sdia-navigation-splash';
    node.dataset.sdiaSplash = spec.id;
    node.style.setProperty('--sdia-splash-accent', currentAccent());
    node.setAttribute('role', 'dialog');
    node.setAttribute('aria-modal', 'true');
    node.setAttribute('aria-label', spec.title || 'SDIA transition');
    const scene = typeof spec.sceneMarkup === 'function' ? spec.sceneMarkup() : (spec.sceneMarkup || '');
    node.innerHTML = `
      <div class="sdia-navigation-splash-card">
        <button type="button" class="sdia-navigation-splash-close" aria-label="Close transition splash">×</button>
        <div class="sdia-navigation-splash-copy">
          <span class="sdia-navigation-splash-eyebrow">${escapeHtml(spec.eyebrow || 'SDIA GOVERNED TRANSITION')}</span>
          <h2>${escapeHtml(spec.title || 'Preparing SAP context')}</h2>
          <p>${escapeHtml(spec.subtitle || 'SDIA keeps governance in front while SAP loads the execution context behind it.')}</p>
        </div>
        <div class="sdia-navigation-splash-stage" aria-hidden="true">${scene}</div>
        <div class="sdia-navigation-splash-progress">
          <i><u></u></i>
          <span>Preparing governed transition…</span>
        </div>
        <small>Close this splash at any time. SAP continues loading behind SDIA.</small>
      </div>`;
    controlCenter.appendChild(node);

    let dismissed = false;
    let closed = false;
    const progressText = node.querySelector('.sdia-navigation-splash-progress span');
    const closeButton = node.querySelector('.sdia-navigation-splash-close');

    const controller = {
      get dismissed() { return dismissed; },
      get closed() { return closed; },
      setProgress(phase, detail = '') {
        if (closed) return;
        node.dataset.phase = phase || '';
        if (progressText) progressText.textContent = PHASE_COPY[phase] || detail || 'Loading SAP context behind SDIA…';
      },
      complete() {
        if (closed) return;
        node.classList.add('is-complete');
        node.dataset.phase = 'ready';
        if (progressText) progressText.textContent = PHASE_COPY.ready;
      },
      fail(message = '') {
        if (closed) return;
        node.classList.add('is-error');
        node.dataset.phase = 'error';
        if (progressText) progressText.textContent = message || PHASE_COPY.error;
      },
      close({ user = false } = {}) {
        if (closed) return;
        if (user) {
          dismissed = true;
          try { options.onDismiss?.(); } catch (_) {}
        }
        closed = true;
        closeNode(node);
      }
    };

    closeButton?.addEventListener('click', () => controller.close({ user:true }));
    requestAnimationFrame(() => node.classList.add('is-visible'));
    return controller;
  }

  SDIA.NavigationExperience = Object.freeze({ register, config, enabled, open });
})();
