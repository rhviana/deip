/* SDIA Governance — Control Plane visual experience.
 * Owns only cross-domain color experience: palette, last-used color,
 * manual lock and deterministic automatic rotation every N openings.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { state, saveSettings, runtimeUrl } = SDIA.Core;

  const THEMES = Object.freeze([
    Object.freeze({ id:'emerald-green', label:'Emerald Green', swatch:'#17A66D' }),
    Object.freeze({ id:'ocean-blue', label:'Ocean Blue', swatch:'#168AC8' }),
    Object.freeze({ id:'royal-purple', label:'Royal Purple', swatch:'#7651C8' }),
    Object.freeze({ id:'sunset-orange', label:'Sunset Orange', swatch:'#E96C32' }),
    Object.freeze({ id:'ruby-red', label:'Ruby Red', swatch:'#D74444' }),
    Object.freeze({ id:'golden-amber', label:'Golden Amber', swatch:'#E4A11B' }),
    Object.freeze({ id:'teal-cyan', label:'Teal Cyan', swatch:'#16A6A3' }),
    Object.freeze({ id:'indigo-blue', label:'Indigo Blue', swatch:'#4966C8' }),
    Object.freeze({ id:'magenta-pink', label:'Magenta Pink', swatch:'#D94792' }),
    Object.freeze({ id:'slate-gray', label:'Slate Gray', swatch:'#687681' })
  ]);

  const ROTATION_THRESHOLD = 20;
  const registry = new Map();

  function normalizeTheme(value) {
    const id = String(value || '').toLowerCase();
    return THEMES.some((theme) => theme.id === id) ? id : THEMES[0].id;
  }

  function ensureSettings() {
    state.settings.controlPlaneColorMode = state.settings.controlPlaneColorMode === 'manual' ? 'manual' : 'auto';
    state.settings.controlPlaneColor = normalizeTheme(state.settings.controlPlaneColor);
    state.settings.controlPlaneOpenCount = Math.max(0, Number(state.settings.controlPlaneOpenCount) || 0);
    state.settings.controlPlaneRotationEvery = ROTATION_THRESHOLD;
  }

  function currentTheme() {
    ensureSettings();
    return state.settings.controlPlaneColor;
  }

  function isAutomatic() {
    ensureSettings();
    return state.settings.controlPlaneColorMode !== 'manual';
  }

  function register(scope, config = {}) {
    const key = String(scope || '').trim();
    if (!key) return;
    registry.set(key, Object.freeze({ ...config, scope:key }));
  }

  function config(scope) {
    return registry.get(String(scope || '').trim()) || null;
  }

  function asset(scope, theme = currentTheme()) {
    const entry = config(scope);
    if (!entry?.assetDir) return '';
    return runtimeUrl(`${entry.assetDir}/${normalizeTheme(theme)}.webp`);
  }

  function emitChange() {
    try { state.overlay?.dispatchEvent(new CustomEvent('sdia:visual-experience-changed')); } catch (_) {}
  }

  function nextTheme(current = currentTheme()) {
    const index = Math.max(0, THEMES.findIndex((theme) => theme.id === normalizeTheme(current)));
    return THEMES[(index + 1) % THEMES.length].id;
  }

  async function noteOpen() {
    ensureSettings();
    if (!isAutomatic()) return currentTheme();
    state.settings.controlPlaneOpenCount += 1;
    if (state.settings.controlPlaneOpenCount >= ROTATION_THRESHOLD) {
      state.settings.controlPlaneColor = nextTheme(state.settings.controlPlaneColor);
      state.settings.controlPlaneOpenCount = 0;
    }
    try { await saveSettings(); } catch (_) {}
    emitChange();
    return currentTheme();
  }

  async function selectManual(theme) {
    ensureSettings();
    state.settings.controlPlaneColorMode = 'manual';
    state.settings.controlPlaneColor = normalizeTheme(theme);
    state.settings.controlPlaneOpenCount = 0;
    try { await saveSettings(); } catch (_) {}
    applyToMounted();
    emitChange();
    return currentTheme();
  }

  async function enableAutomatic() {
    ensureSettings();
    state.settings.controlPlaneColorMode = 'auto';
    state.settings.controlPlaneOpenCount = 0;
    try { await saveSettings(); } catch (_) {}
    applyToMounted();
    emitChange();
    return currentTheme();
  }

  function applyToMounted(root = document) {
    const theme = currentTheme();
    try { document.documentElement.dataset.sdiaVisualTheme = theme; } catch (_) {}
    root.querySelectorAll?.('[data-sdia-control-plane-scope]').forEach((host) => {
      const scope = host.dataset.sdiaControlPlaneScope;
      const image = host.querySelector('img[data-sdia-control-plane-image]');
      const src = asset(scope, theme);
      if (image && src && image.src !== src) image.src = src;
      host.dataset.sdiaVisualTheme = theme;
    });
    root.querySelectorAll?.('[data-sdia-home-visual]').forEach((host) => {
      const image = host.querySelector('img[data-sdia-home-image]');
      const src = asset('home', theme);
      if (image && src && image.src !== src) image.src = src;
      host.dataset.sdiaVisualTheme = theme;
    });
  }

  function replayElementMotion(element) {
    if (!(element instanceof Element)) return;
    const previous = element.style.animation;
    element.style.animation = 'none';
    void element.getBoundingClientRect();
    element.style.animation = previous;
  }

  function replay(scope, root = document) {
    const key = String(scope || '').trim();
    const targets = key === 'home'
      ? [...(root.querySelectorAll?.('[data-sdia-home-visual]') || [])]
      : [...(root.querySelectorAll?.(`[data-sdia-control-plane-scope="${key}"]`) || [])];
    targets.forEach((host) => {
      const image = host.querySelector('img[data-sdia-control-plane-image],img[data-sdia-home-image]');
      const flash = host.querySelector('.sdia-control-plane-shield-flash');
      replayElementMotion(image);
      replayElementMotion(flash);
      if (key === 'home') {
        const homeFlash = host.matches('.sdia-home-hero-art') ? host : host.closest('.sdia-home-hero-art');
        if (homeFlash) replayElementMotion(homeFlash);
      }
    });
  }

  async function activate(scope, root = document) {
    const theme = await noteOpen();
    applyToMounted(root);
    requestAnimationFrame(() => replay(scope, root));
    return { scope, theme, count: state.settings.controlPlaneOpenCount, automatic:isAutomatic() };
  }

  function progress() {
    ensureSettings();
    return Object.freeze({
      automatic: isAutomatic(),
      theme: currentTheme(),
      openings: state.settings.controlPlaneOpenCount,
      threshold: ROTATION_THRESHOLD,
      remaining: Math.max(0, ROTATION_THRESHOLD - state.settings.controlPlaneOpenCount)
    });
  }

  ensureSettings();
  SDIA.VisualExperience = Object.freeze({
    THEMES, register, config, asset, currentTheme, isAutomatic, progress,
    activate, applyToMounted, replay, selectManual, enableAutomatic, normalizeTheme
  });
})();
