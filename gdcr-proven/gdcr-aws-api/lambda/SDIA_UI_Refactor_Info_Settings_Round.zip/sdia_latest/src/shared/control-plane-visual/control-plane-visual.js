/* SDIA Governance — reusable Control Plane hero visual.
 * Pure presentation. Domain modules register semantic copy and asset folders.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { escapeHtml } = SDIA.Core;

  function markup(config = {}) {
    const scope = escapeHtml(config.scope || config.type || 'governance');
    const type = escapeHtml(config.type || scope);
    const eyebrow = escapeHtml(config.eyebrow || 'SDIA CONTROL PLANE');
    const title = escapeHtml(config.title || 'Domain Governance');
    const accent = escapeHtml(config.accent || 'Domain');
    const description = escapeHtml(config.description || 'Govern semantic identity across integration artefacts.');
    const footerTitle = escapeHtml(config.footerTitle || 'SDIA Control Plane');
    const footerMeta = escapeHtml(config.footerMeta || 'Governance · Semantic identity');
    const asset = SDIA.VisualExperience?.asset(scope) || '';
    const titleMarkup = accent && title.includes(accent)
      ? title.replace(accent, `<span>${accent}</span>`)
      : title;

    return `<section class="sdia-control-plane-visual sdia-control-plane-visual--${type}" data-sdia-control-plane-scope="${scope}" aria-label="${eyebrow}">
      <div class="sdia-control-plane-visual-main">
        <div class="sdia-control-plane-visual-copy">
          <span class="sdia-control-plane-visual-eyebrow">${eyebrow}</span>
          <h1>${titleMarkup}</h1>
          <p>${description}</p>
        </div>
        <div class="sdia-control-plane-visual-art" aria-hidden="true">
          <img data-sdia-control-plane-image src="${asset}" alt="">
          <i class="sdia-control-plane-shield-flash"></i>
        </div>
      </div>
      <footer><b>${footerTitle}</b><span>${footerMeta}</span></footer>
    </section>`;
  }

  function markupForScope(scope) {
    const config = SDIA.VisualExperience?.config(scope);
    return config ? markup(config) : '';
  }

  SDIA.ControlPlaneVisual = Object.freeze({ markup, markupForScope });
})();
