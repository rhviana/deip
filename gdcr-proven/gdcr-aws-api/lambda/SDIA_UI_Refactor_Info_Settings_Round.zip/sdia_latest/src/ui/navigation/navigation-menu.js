/* SDIA Governance — context-aware sidebar menu markup only.
 * The workspace asks for the menu; route/product filtering remains centralized.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { icon } = SDIA.Core;

  const ITEMS = Object.freeze([
    Object.freeze({ module:'home-hub', label:'Home', icon:'home', products:'home' }),
    Object.freeze({ module:'dashboard', label:'Dashboard', icon:'assessment', products:'home' }),
    Object.freeze({ module:'what-is-sdia', label:'What is SDIA?', icon:'shield', products:'home' }),
    Object.freeze({ module:'how-to', label:'How to use SDIA', icon:'journey', products:'home' }),
    Object.freeze({ module:'domain-help', label:'Domain Help', icon:'domain-help', products:'home' }),
    Object.freeze({ module:'catalog', label:'Catalog', icon:'catalog', products:'home' }),
    Object.freeze({ module:'information', label:'Information', icon:'help', products:'home' }),
    Object.freeze({ module:'settings', label:'Settings', icon:'settings', products:'home' }),
    Object.freeze({ module:'contact', label:'Contact', icon:'contact', products:'home' }),

    Object.freeze({ module:'overview', label:'Overview', icon:'overview', products:'ci,apim,eventmesh,security' }),
    Object.freeze({ module:'packages', label:'Packages', icon:'packages', products:'ci' }),
    Object.freeze({ module:'package-map', label:'Governance Map', icon:'map', products:'ci' }),
    Object.freeze({ module:'package-workspace', label:'Artefacts', icon:'packages', products:'ci' }),
    Object.freeze({ module:'apim', label:'API Management', icon:'proxy', products:'apim' }),
    Object.freeze({ module:'eventmesh', label:'Event Mesh', icon:'eventmesh', products:'eventmesh' }),
    Object.freeze({ module:'security', label:'Security', icon:'shield-check', products:'security' })
  ]);

  function itemMarkup(item) {
    return `<button type="button" data-sdia-module="${item.module}" data-sdia-products="${item.products}" aria-label="${item.label}">${icon(item.icon)}<span>${item.label}</span><i class="sdia-nav-lock-indicator" aria-hidden="true">${icon('lock')}</i></button>`;
  }

  function markup() {
    return `<button type="button" class="sdia-cc-nav-toggle" data-sdia-action="toggle-nav" aria-label="Collapse navigation"><i class="sdia-nav-toggle-glyph">‹</i><span>Menu</span></button>${ITEMS.map(itemMarkup).join('')}`;
  }

  SDIA.NavigationMenu = Object.freeze({ ITEMS, markup });
})();
