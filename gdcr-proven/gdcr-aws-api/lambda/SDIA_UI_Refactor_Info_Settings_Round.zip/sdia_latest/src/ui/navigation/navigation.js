/* SDIA Governance v1.0.0 — internal navigation + per-context tab-session state. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { state, constants, escapeHtml, normalizeToken } = SDIA.Core;
  const { UI_STATE_KEY } = constants;

  const allowedModulesForProduct = (...args) => SDIA.WorkspaceRouter.allowedModulesForProduct(...args);
  const defaultModuleForRoute = (...args) => SDIA.WorkspaceRouter.defaultModuleForRoute(...args);
  const activeProductProfile = (...args) => SDIA.RouteContext.activeProductProfile(...args);
  const designContext = (...args) => SDIA.RouteContext.designContext(...args);
  const integrationSuiteContext = (...args) => SDIA.RouteContext.integrationSuiteContext(...args);
  const switchModule = (...args) => SDIA.Workspace.switchModule(...args);
  const closeControlCenter = (...args) => SDIA.Workspace.closeControlCenter(...args);
  const populateSubdomains = (...args) => SDIA.CloudIntegration.Package.populateSubdomains(...args);
  const updatePackagePreview = (...args) => SDIA.CloudIntegration.Package.updatePackagePreview(...args);
  const CONTROL_PLANE_HOME_MODULES = new Set(['home-hub','dashboard','what-is-sdia','how-to','catalog','domain-help','information','contact','settings']);
  const usesControlPlaneHomeMenu = (module = state.activeModule) => CONTROL_PLANE_HOME_MODULES.has(module);

  function currentContextKey() {
    const suite = integrationSuiteContext();
    const design = designContext();
    if (suite.product === 'home') return 'home';
    if (suite.product === 'ci') {
      if (design.type === 'contentpackage') return `ci:package:${normalizeToken(design.packageId) || String(design.packageId || '').toLowerCase()}`;
      if (design.type === 'package-create') return 'ci:package-create';
      return 'ci:package-level';
    }
    if (suite.product === 'apim') return 'apim';
    if (suite.product === 'eventmesh') return 'eventmesh';
    if (suite.product === 'security') return suite.routeType === 'keystore' ? 'security:keystore' : 'security:materials';
    return 'unsupported';
  }

  function readEnvelope() {
    try {
      const raw = sessionStorage.getItem(UI_STATE_KEY);
      if (!raw) return { version:'0.2.0', contexts:{} };
      const parsed = JSON.parse(raw);
      if (parsed?.version === '0.2.0' && parsed.contexts && typeof parsed.contexts === 'object') return parsed;
      // One-time compatibility with the previous single-snapshot format.
      if (parsed?.version === '0.2.0' && parsed.activeModule) {
        return { version:'0.2.0', contexts:{ [currentContextKey()]: parsed } };
      }
    } catch (_) {}
    return { version:'0.2.0', contexts:{} };
  }

  function writeEnvelope(envelope) {
    try { sessionStorage.setItem(UI_STATE_KEY, JSON.stringify(envelope)); } catch (_) {}
  }

  function captureControlCenterState(reason = 'manual', options = {}) {
    if (!state.overlay) return null;
    const fields = {};
    if (state.settings.preserveDraftSession !== false) {
      state.overlay.querySelectorAll('input, select, textarea').forEach((field) => {
        if (!field.id) return;
        fields[field.id] = field.type === 'checkbox' ? { checked: field.checked } : { value: field.value };
      });
    }
    const main = state.overlay.querySelector('.sdia-cc-main');
    return {
      version:'0.2.0',
      contextKey: options.contextKey || currentContextKey(),
      reason,
      createdAt:Date.now(),
      open: options.open ?? !state.overlay.classList.contains('sdia-hidden'),
      activeModule:state.activeModule,
      activeProduct:activeProductProfile().id,
      capabilityReturnModule:state.capabilityReturnModule,
      internalHistory:Array.isArray(state.internalHistory) ? state.internalHistory.slice(-14) : [],
      descriptionDirty:state.descriptionDirty,
      generatedPackage:state.generatedPackage,
      pendingPackageName:state.pendingPackageName,
      activeArtefactType:state.activeArtefactType,
      pendingArtefactName:state.pendingArtefactName,
      selectedPackage:state.settings.preserveDraftSession !== false ? state.selectedPackage : null,
      scrollTop:main?.scrollTop || 0,
      fields
    };
  }

  const DRAFT_PERSIST_DEBOUNCE_MS = 300;
  // High-frequency keystroke reasons are debounced; lifecycle reasons (open/close,
  // module/route switches, beforeunload) still persist synchronously and cancel any
  // pending debounced write because they already capture the latest field values.
  const DEBOUNCED_PERSIST_REASONS = new Set(['field-input', 'field-change']);
  let draftPersistTimer = null;

  function writeControlCenterSnapshot(reason, options) {
    const snapshot = captureControlCenterState(reason, options);
    if (!snapshot) return;
    const envelope = readEnvelope();
    envelope.contexts[snapshot.contextKey] = snapshot;
    writeEnvelope(envelope);
  }

  function persistControlCenterState(reason = 'manual', options = {}) {
    if (draftPersistTimer) {
      clearTimeout(draftPersistTimer);
      draftPersistTimer = null;
    }
    if (DEBOUNCED_PERSIST_REASONS.has(reason)) {
      draftPersistTimer = setTimeout(() => {
        draftPersistTimer = null;
        writeControlCenterSnapshot(reason, options);
      }, DRAFT_PERSIST_DEBOUNCE_MS);
      return;
    }
    writeControlCenterSnapshot(reason, options);
  }

  function clearPersistedControlCenterState() {
    try { sessionStorage.removeItem(UI_STATE_KEY); } catch (_) {}
  }

  function readPersistedControlCenterState(contextKey = currentContextKey()) {
    const envelope = readEnvelope();
    const snapshot = envelope.contexts?.[contextKey] || null;
    return snapshot?.version === '0.2.0' ? snapshot : null;
  }

  function catalogItemMatches(item, value) {
    const token = normalizeToken(value);
    return [item?.id, item?.canonicalCode, ...(item?.aliases || [])].map(normalizeToken).filter(Boolean).includes(token);
  }

  function restoreControlCenterFields(snapshot) {
    if (!state.overlay || !snapshot?.fields) return;
    Object.entries(snapshot.fields).forEach(([id, data]) => {
      if (id === 'sdia-domain' || id === 'sdia-subdomain') return;
      const field = state.overlay.querySelector(`#${CSS.escape(id)}`);
      if (!field) return;
      if ('checked' in data && field.type === 'checkbox') field.checked = Boolean(data.checked);
      if ('value' in data && 'value' in field) field.value = data.value ?? '';
    });
    state.capabilityReturnModule = snapshot.capabilityReturnModule || state.capabilityReturnModule;
    state.descriptionDirty = Boolean(snapshot.descriptionDirty);
    state.generatedPackage = snapshot.generatedPackage || state.generatedPackage;
    state.pendingPackageName = snapshot.pendingPackageName || state.pendingPackageName;
    state.activeArtefactType = snapshot.activeArtefactType || state.activeArtefactType;
    state.pendingArtefactName = snapshot.pendingArtefactName || state.pendingArtefactName;
    state.selectedPackage = snapshot.selectedPackage || state.selectedPackage;
    try {
      const domainField = state.overlay.querySelector('#sdia-domain');
      const rawDomain = snapshot.fields['sdia-domain']?.value || '';
      const domain = (state.catalog.domains || []).find((item) => catalogItemMatches(item, rawDomain));
      if (domainField && domain) domainField.value = domain.id;
      populateSubdomains();
      const subdomainField = state.overlay.querySelector('#sdia-subdomain');
      const rawSubdomain = snapshot.fields['sdia-subdomain']?.value || '';
      const subdomain = (domain?.subdomains || []).find((item) => catalogItemMatches(item, rawSubdomain));
      if (subdomainField && subdomain) subdomainField.value = subdomain.id;
      updatePackagePreview();
    } catch (_) {}
    requestAnimationFrame(() => {
      const main = state.overlay?.querySelector('.sdia-cc-main');
      if (main && Number.isFinite(Number(snapshot.scrollTop))) main.scrollTop = Math.max(0, Number(snapshot.scrollTop));
    });
  }

  function backInternal() {
    if (!state.overlay) return;
    const routeAllowed = allowedModulesForProduct();
    const homeAllowed = allowedModulesForProduct(SDIA.RouteContext.PRODUCT_PROFILES.home);
    const allowed = new Set([...routeAllowed, ...homeAllowed]);
    while (state.internalHistory.length) {
      const previous = state.internalHistory.pop();
      if (previous && allowed.has(previous) && previous !== state.activeModule) {
        switchModule(previous, { push:false });
        return;
      }
    }
    const fallback = defaultModuleForRoute();
    if (state.activeModule !== fallback && routeAllowed.includes(fallback)) {
      switchModule(fallback, { push:false });
      return;
    }
    closeControlCenter();
  }

  function moduleLabel(module) {
    const labels = {
      overview:activeProductProfile().id === 'home' ? 'Home' : 'Overview', 'home-hub':'Home', packages:'Package Governance', 'package-create':'Create Domain Boundary Package',
      'package-edit-list':'Select Package', 'package-edit-form':'Edit Package Governance',
      'package-map':'Domain Governance Package Map', dashboard:'Governance Dashboard', 'what-is-sdia':'What is SDIA?', 'domain-help':'Domain Help', 'how-to':'How to use SDIA', information:'Information',
      'package-workspace':'Package Artifacts',
      apim:'GDCR Workspace', eventmesh:'EDCP Workspace', security:'Security Governance',
      assessment:activeProductProfile().id === 'ci' ? 'Assessment' : 'Capability Assessment',
      catalog:'Domain Catalog', settings:'Settings', contact:'Contact',
      'capability-action':state.overlay?.querySelector('#sdia-capability-action-title')?.textContent || 'Governance Model'
    };
    return labels[module] || module;
  }

  function breadcrumbItems() {
    const routeProfile = activeProductProfile();
    const profile = usesControlPlaneHomeMenu(state.activeModule) ? SDIA.RouteContext.PRODUCT_PROFILES.home : routeProfile;
    const context = designContext();
    if (state.activeModule === 'home-hub') return ['SDIA','Home'];
    const items = ['SDIA'];
    if (profile.id === 'home') {
      items.push('Home');
    } else if (profile.id === 'ci') {
      items.push('Cloud Integration', profile.modelCode);
      if (context.type === 'contentpackage') items.push(`Package: ${context.packageId || 'Active package'}`);
      else if (context.type === 'design' || context.type === 'package-create') items.push('Package Level');
    } else if (profile.id === 'security') {
      items.push('Security', integrationSuiteContext().routeType === 'keystore' ? 'Keystore' : 'Security Materials');
    } else {
      items.push(profile.capability, profile.modelCode);
    }
    items.push(moduleLabel(state.activeModule));
    return items.filter(Boolean);
  }

  function updateWorkspaceChrome() {
    if (!state.overlay) return;
    const breadcrumb = state.overlay.querySelector('#sdia-workspace-breadcrumb');
    const back = state.overlay.querySelector('#sdia-workspace-back');
    const controlPlaneHome = state.overlay.querySelector('#sdia-control-plane-home');
    if (breadcrumb) breadcrumb.innerHTML = breadcrumbItems().map((item, index, all) => `<span class="${index === all.length - 1 ? 'current' : ''}">${escapeHtml(item)}</span>`).join('<i>/</i>');
    if (back) {
      const fallback = defaultModuleForRoute();
      back.textContent = state.internalHistory.length || state.activeModule !== fallback ? '← Back' : '× Close';
      back.setAttribute('aria-label', back.textContent.replace(/[←×]/g, '').trim() || 'Back');
    }
    if (controlPlaneHome) {
      const onHomeControlPlane = usesControlPlaneHomeMenu(state.activeModule);
      controlPlaneHome.classList.toggle('is-current', onHomeControlPlane);
      controlPlaneHome.setAttribute('aria-current', onHomeControlPlane ? 'page' : 'false');
      controlPlaneHome.hidden = onHomeControlPlane;
      if (onHomeControlPlane) controlPlaneHome.style.setProperty('display', 'none', 'important');
      else controlPlaneHome.style.removeProperty('display');
    }
  }

  SDIA.Navigation = Object.freeze({
    currentContextKey, captureControlCenterState, persistControlCenterState,
    clearPersistedControlCenterState, readPersistedControlCenterState, restoreControlCenterFields,
    backInternal, moduleLabel, breadcrumbItems, updateWorkspaceChrome
  });
})();
