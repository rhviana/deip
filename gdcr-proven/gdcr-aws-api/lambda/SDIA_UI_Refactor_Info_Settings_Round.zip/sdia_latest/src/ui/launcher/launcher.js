/* SDIA Governance v1.0.0 — SAP-sidebar launcher with persisted free positioning after user drag. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { state, constants, runtimeUrl, normalizeText, saveSettings } = SDIA.Core;
  let onOpen = null;
  let sidebarObserver = null;
  let observedSidebar = null;
  let resizeBound = false;
  let dragging = false;
  let ignoreNextClick = false;

  function visible(element) {
    if (!(element instanceof Element) || !element.isConnected) return false;
    const style = getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function candidateScore(element) {
    if (!visible(element)) return -Infinity;
    const rect = element.getBoundingClientRect();
    if (rect.left > 28 || rect.right < 120 || rect.width > 440 || rect.height < innerHeight * .48) return -Infinity;
    const text = normalizeText(element.innerText || element.textContent || '').slice(0, 4000);
    const markers = ['home','discover','design','test','configure','monitor','analyze','engage','inspect','monetize','settings'];
    const hits = markers.reduce((sum, marker) => sum + (text.includes(marker) ? 1 : 0), 0);
    let score = hits * 20;
    if (element.matches('nav,aside,[role="navigation"]')) score += 35;
    if (rect.left <= 8) score += 20;
    if (rect.width >= 170 && rect.width <= 300) score += 18;
    if (rect.height >= innerHeight * .75) score += 18;
    return score;
  }

  function findSapSidebar() {
    const candidates = new Set(document.querySelectorAll('nav,aside,[role="navigation"],[class*="SideNavigation"],[class*="sideNavigation"],[class*="ToolPage"]'));
    document.querySelectorAll('button,a,[role="menuitem"],[role="treeitem"]').forEach((node) => {
      const text = normalizeText(node.innerText || node.textContent || '');
      if (!['home','discover','design','configure','monitor','analyze','settings'].includes(text)) return;
      let parent = node.parentElement;
      for (let depth = 0; parent && depth < 7; depth += 1, parent = parent.parentElement) candidates.add(parent);
    });
    return [...candidates].map((element) => ({ element, score:candidateScore(element) }))
      .filter((item) => Number.isFinite(item.score) && item.score >= 40)
      .sort((a,b) => b.score - a.score)[0]?.element || null;
  }

  function inferSidebarBoundary() {
    const sidebar = findSapSidebar();
    if (sidebar) {
      const rect = sidebar.getBoundingClientRect();
      return { left:rect.left, width:rect.width, source:'sidebar', element:sidebar };
    }
    const mainCandidates = [...document.querySelectorAll('main,[role="main"],.sapMPage')]
      .filter(visible)
      .map((element) => ({ element, rect:element.getBoundingClientRect() }))
      .filter(({rect}) => rect.left >= 120 && rect.left <= 440 && rect.width >= innerWidth * .45 && rect.height >= innerHeight * .45)
      .sort((a,b) => a.rect.left - b.rect.left);
    if (mainCandidates[0]) return { left:0, width:mainCandidates[0].rect.left, source:'content-boundary', element:null };
    return null;
  }

  function observeSidebar(element) {
    if (observedSidebar === element) return;
    sidebarObserver?.disconnect();
    observedSidebar = element || null;
    if (!element || typeof ResizeObserver === 'undefined') return;
    sidebarObserver = new ResizeObserver(() => syncGeometry());
    sidebarObserver.observe(element);
  }

  function finiteSetting(value) {
    return value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value));
  }

  function hasUserPosition() {
    return finiteSetting(state.settings.launcherLeft) && finiteSetting(state.settings.launcherTop);
  }

  function clampPosition(left, top) {
    if (!state.launcher) return { left:8, top:8 };
    const width = state.launcher.offsetWidth || 58;
    const height = state.launcher.offsetHeight || 58;
    const maxLeft = Math.max(8, innerWidth - width - 8);
    const maxTop = Math.max(8, innerHeight - height - 8);
    return {
      left: Math.min(maxLeft, Math.max(8, Math.round(left))),
      top: Math.min(maxTop, Math.max(8, Math.round(top)))
    };
  }

  function applyUserPosition() {
    if (!state.launcher || !hasUserPosition()) return false;
    const position = clampPosition(Number(state.settings.launcherLeft), Number(state.settings.launcherTop));
    state.launcher.style.left = `${position.left}px`;
    state.launcher.style.top = `${position.top}px`;
    state.launcher.style.right = 'auto';
    state.launcher.style.bottom = 'auto';
    state.launcher.classList.remove('sdia-launcher-geometry-pending');
    state.launcher.dataset.geometrySource = 'user';
    return true;
  }

  function launcherContextLabel() {
    const context = SDIA.RouteContext.integrationSuiteContext();
    if (context.product === 'home') return 'Home';
    if (context.product === 'ci') {
      if (context.routeType === 'content-package') return 'Package Artifacts';
      return 'Package';
    }
    if (context.product === 'apim') return 'APIM';
    if (context.product === 'eventmesh') return 'EM / AEM';
    if (context.product === 'security') {
      if (context.routeType === 'keystore') return 'Certificate';
      if (context.routeType === 'security-materials') return 'Security Materials';
      return 'Security';
    }
    return 'Governance';
  }

  function syncContextLabel() {
    const label = state.launcher?.querySelector('#sdia-launcher-context-label');
    if (!label) return;
    const profile = SDIA.RouteContext.activeProductProfile();
    // Keep the context deliberately short: the launcher must remain compact
    // even on narrow SAP sidebars. Product icons belong to the main shield.
    label.textContent = launcherContextLabel();
  }

  function syncGeometry() {
    if (!state.launcher || dragging) return;
    syncContextLabel();

    const geometry = inferSidebarBoundary();
    if (geometry && geometry.width >= 42) {
      const margin = geometry.width >= 80 ? 4 : 2;
      const collapsed = geometry.width < 150;
      const available = Math.max(38, Math.round(geometry.width - margin * 2));
      const compactWidth = collapsed ? available : Math.min(238, Math.max(190, available));
      state.launcher.style.width = `${compactWidth}px`;
      state.launcher.classList.toggle('sdia-launcher-sidebar-collapsed', collapsed);
      observeSidebar(geometry.element);

      if (applyUserPosition()) return;

      state.launcher.style.left = `${Math.round(geometry.left + margin)}px`;
      state.launcher.style.right = 'auto';
      if (finiteSetting(state.settings.launcherTop)) {
        const maxTop = Math.max(8, innerHeight - state.launcher.offsetHeight - 8);
        state.launcher.style.top = `${Math.min(maxTop, Math.max(8, Number(state.settings.launcherTop)))}px`;
        state.launcher.style.bottom = 'auto';
      } else {
        state.launcher.style.top = 'auto';
        state.launcher.style.bottom = '24px';
      }
      state.launcher.classList.remove('sdia-launcher-geometry-pending');
      state.launcher.dataset.geometrySource = geometry.source;
      return;
    }

    observeSidebar(null);
    if (applyUserPosition()) return;
    state.launcher.classList.add('sdia-launcher-geometry-pending');
  }

  async function persistPosition(left, top) {
    const position = clampPosition(left, top);
    state.settings.launcherLeft = position.left;
    state.settings.launcherTop = position.top;
    await saveSettings();
  }

  function bindDrag(mainButton) {
    mainButton.addEventListener('pointerdown', (event) => {
      if (event.button !== undefined && event.button !== 0) return;
      if (!state.launcher || state.launcher.classList.contains('sdia-hidden')) return;

      const rect = state.launcher.getBoundingClientRect();
      const start = {
        pointerId: event.pointerId,
        x: event.clientX,
        y: event.clientY,
        left: rect.left,
        top: rect.top,
        moved: false
      };

      dragging = true;
      state.launcher.classList.add('sdia-dragging');
      state.launcher.style.left = `${Math.round(rect.left)}px`;
      state.launcher.style.top = `${Math.round(rect.top)}px`;
      state.launcher.style.right = 'auto';
      state.launcher.style.bottom = 'auto';
      mainButton.setPointerCapture?.(event.pointerId);

      const onMove = (moveEvent) => {
        if (moveEvent.pointerId !== start.pointerId) return;
        const dx = moveEvent.clientX - start.x;
        const dy = moveEvent.clientY - start.y;
        if (!start.moved && Math.hypot(dx, dy) < 5) return;
        start.moved = true;
        moveEvent.preventDefault();
        const position = clampPosition(start.left + dx, start.top + dy);
        state.launcher.style.left = `${position.left}px`;
        state.launcher.style.top = `${position.top}px`;
      };

      const finish = async (finishEvent) => {
        if (finishEvent.pointerId !== start.pointerId) return;
        mainButton.removeEventListener('pointermove', onMove);
        mainButton.removeEventListener('pointerup', finish);
        mainButton.removeEventListener('pointercancel', finish);
        mainButton.releasePointerCapture?.(start.pointerId);
        dragging = false;
        state.launcher?.classList.remove('sdia-dragging');

        if (start.moved && state.launcher) {
          ignoreNextClick = finishEvent.type === 'pointerup';
          const finalRect = state.launcher.getBoundingClientRect();
          await persistPosition(finalRect.left, finalRect.top);
          state.launcher.dataset.geometrySource = 'user';
        }
      };

      mainButton.addEventListener('pointermove', onMove);
      mainButton.addEventListener('pointerup', finish);
      mainButton.addEventListener('pointercancel', finish);
    });
  }

  async function hideByUser(event) {
    event?.preventDefault(); event?.stopPropagation();
    state.settings.launcherVisible = false;
    state.launcher?.classList.add('sdia-hidden');
    await saveSettings();
  }

  function mount(options = {}) {
    if (state.mounted || !document.body) return;
    onOpen = options.onOpen || onOpen;
    const root = document.createElement('div');
    root.id = constants.ROOT_ID;
    root.innerHTML = `
      <div class="sdia-floating-control sdia-launcher-geometry-pending" role="group" aria-label="SDIA Governance launcher">
        <button class="sdia-launcher-main" type="button" aria-label="Open or move SDIA Governance">
          <span class="sdia-launcher-shield"><img class="sdia-launcher-badge" src="${runtimeUrl('src/shared/brand/assets/icon128.png')}" alt="" aria-hidden="true"><i class="sdia-shield-scan" aria-hidden="true"></i></span>
          <span class="sdia-launcher-copy"><b>SDIA - Governance</b></span>
          <em id="sdia-launcher-context-label" class="sdia-launcher-context-badge">Package</em>
          <i class="sdia-launcher-arrow" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 5.5 15 12l-6.5 6.5"/></svg></i>
        </button>
        <button class="sdia-launcher-close" type="button" aria-label="Hide SDIA launcher">×</button>
      </div>`;
    const toast = document.createElement('div');
    toast.id = constants.TOAST_ID;
    toast.className = 'sdia-global-toast sdia-hidden';
    toast.setAttribute('aria-live', 'polite');
    document.body.appendChild(root);
    document.body.appendChild(toast);
    state.root = root;
    state.launcher = root.querySelector('.sdia-floating-control');
    state.toast = toast;

    const mainButton = state.launcher.querySelector('.sdia-launcher-main');
    bindDrag(mainButton);
    mainButton.addEventListener('click', (event) => {
      if (ignoreNextClick) {
        ignoreNextClick = false;
        event.preventDefault();
        event.stopPropagation();
        return;
      }
      onOpen?.();
    });
    state.launcher.querySelector('.sdia-launcher-close').addEventListener('click', hideByUser);
    state.launcher.classList.toggle('sdia-hidden', !state.settings.launcherVisible);
    state.mounted = true;
    syncGeometry();
    [250, 750, 1500].forEach((ms) => setTimeout(syncGeometry, ms));
    if (!resizeBound) {
      window.addEventListener('resize', syncGeometry, { passive:true });
      resizeBound = true;
    }
  }

  function setVisible(visible) { state.launcher?.classList.toggle('sdia-hidden', !visible); }
  function suppress(value = true) { state.launcher?.classList.toggle('sdia-launcher-suppressed', Boolean(value)); }
  function destroy() {
    sidebarObserver?.disconnect(); sidebarObserver = null; observedSidebar = null;
    if (resizeBound) { window.removeEventListener('resize', syncGeometry); resizeBound = false; }
    dragging = false; ignoreNextClick = false;
    state.toast?.remove();
    state.root?.remove(); state.root = state.launcher = state.toast = null; state.mounted = false;
  }

  SDIA.Launcher = Object.freeze({ mount, syncGeometry, syncContextLabel, setVisible, suppress, destroy, hideByUser });
})();
