/* SDIA Governance — Information module
 * Home-only institutional context: rationale, anti-patterns, architecture map and public records.
 * Playback begins only when the relevant section reaches the viewport.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { icon } = SDIA.Core;

  const INTRO_SESSION_KEY = 'sdia:information-intro-played:v2.0.0';
  const TREE_SESSION_KEY = 'sdia:information-tree-played:v2.0.0';
  const COPYRIGHT_SESSION_KEY = 'sdia:information-copyright-played:v2.0.0';
  let playbackToken = 0;
  let observer = null;

  const WHY_TEXT = 'SAP BTP Integration Suite is a powerful execution platform. SDIA was created after repeatedly seeing strong delivery landscapes deteriorate not because the platform was weak, but because governance was absent. Without explicit domain boundaries and semantic ownership, package sprawl, artefact sprawl, credential sprawl, certificate sprawl, duplicated routing logic and fragmented platform usage start to grow around the tenant. What began as a practical API Management problem around domain-semantic URLs, KVM metadata and deterministic JavaScript routing evolved into GDCR and DDCR, then expanded into ODCP, EDCP and DDCP, while SDIA became the governance layer protecting the execution layer. Above it, DEIP emerged as the semantic decision model to reduce platform overlap and prevent platform sprawl before it reaches runtime.';

  const ANTI_PATTERNS = Object.freeze([
    Object.freeze({ name:'Protocol Sprawl', manifestation:'Kafka + RabbitMQ + Event Mesh + JMS used for the same domain.', consequence:'Redundant infrastructure, duplicated skills and inconsistent governance.' }),
    Object.freeze({ name:'Platform Sprawl', manifestation:'Multiple iPaaS, ETL and gateway platforms with overlapping capabilities.', consequence:'Budget waste, fragmented ownership and no rationalization path.' }),
    Object.freeze({ name:'Proxy Sprawl', manifestation:'One proxy per backend — dozens of proxies serving only a few domains.', consequence:'Maintenance dominates governance effort and one backend change cascades across unrelated proxies.' }),
    Object.freeze({ name:'Runtime Sprawl', manifestation:'Multiple routing engines operating without one semantic resolution model.', consequence:'Non-deterministic behaviour, debugging complexity and weak traceability.' }),
    Object.freeze({ name:'Package Sprawl', manifestation:'Packages named by vendor or project with zero domain visibility.', consequence:'Manual discovery and an ungovernable artefact landscape.' }),
    Object.freeze({ name:'Credential Sprawl', manifestation:'One technical user per integration unit across the same domain scope.', consequence:'Operational fragility; one failed rotation can cascade into broad integration outages.' }),
    Object.freeze({ name:'Certificate Sprawl', manifestation:'Certificate lifecycle managed per integration unit without domain ownership.', consequence:'Duplicated maintenance, expiry risk, unclear ownership and avoidable outages.' })
  ]);

  const PRIOR_ART = Object.freeze({
    deip: Object.freeze({ code:'DEIP', title:'Domain Enterprise Integration Pattern', subtitle:'Semantic Control Plane Decision Model', doi:'10.5281/zenodo.19825678', ipcom:'IPCOM000277671D' }),
    sdia: Object.freeze({ code:'SDIA', title:'Semantic Domain Integration Architecture', subtitle:'Vendor-agnostic semantic governance model for enterprise integration', doi:'10.5281/zenodo.19788232', ipcom:'IPCOM000277630D' }),
    modules: Object.freeze([
      Object.freeze({ code:'GDCR', title:'Gateway Domain-Centric Routing', subtitle:'Metadata-driven architecture for enterprise API governance', doi:'10.5281/zenodo.18582492', ipcom:'IPCOM000277632D' }),
      Object.freeze({ code:'DDCR', title:'Domain-Driven Centric Router', subtitle:'Deterministic runtime semantic resolution engine', doi:'https://zenodo.org/records/19820524', ipcom:'IPCOM000277633D' }),
      Object.freeze({ code:'ODCP', title:'Orchestration Domain-Centric Pattern', subtitle:'SAP CI orchestration topology for governed domain execution', doi:'https://zenodo.org/records/19786661', ipcom:'IPCOM000277631D' }),
      Object.freeze({ code:'EDCP', title:'Event Domain Centric Pattern', subtitle:'Event and messaging domain governance for SAP EM / AEM', doi:'https://zenodo.org/records/19727832', ipcom:'' }),
      Object.freeze({ code:'DDCP', title:'Domain-Driven Composition Pattern', subtitle:'SAP CI composition model for governed data-domain orchestration', doi:'https://zenodo.org/records/19730519', ipcom:'' })
    ])
  });

  const TREE_ROWS = Object.freeze([
    Object.freeze({ depth:0, glyph:'', code:'DEIP', title:'Semantic Control Plane Decision Model', icon:'deip', badge:'Disabled' }),
    Object.freeze({ depth:1, glyph:'└──', code:'7 · Decision Pipeline', title:'Avoid platform sprawl' }),
    Object.freeze({ depth:2, glyph:'', code:'→ Intent → Interaction Type → Quality Profile → Integration Capability → Protocol Profile → Platform Binding', title:'', pipeline:true }),
    Object.freeze({ depth:1, glyph:'└──', code:'SDIA', title:'Semantic Domain Integration Architecture', icon:'sdia' }),
    Object.freeze({ depth:2, glyph:'├──', code:'GDCR', title:'Gateway Domain-Centric Routing' }),
    Object.freeze({ depth:2, glyph:'├──', code:'DDCR', title:'Domain Driven-Centric Router' }),
    Object.freeze({ depth:2, glyph:'├──', code:'ODCP', title:'Orchestration Domain Composition Pattern · SAP CI' }),
    Object.freeze({ depth:2, glyph:'├──', code:'EDCP', title:'Event Domain Centric Pattern · SAP EM / AEM' }),
    Object.freeze({ depth:2, glyph:'└──', code:'DDCP', title:'Orchestration Domain Composition Pattern · SAP CI' }),
    Object.freeze({ depth:1, glyph:'└──', code:'ODCP', title:'Cross-domain orchestration layer' }),
    Object.freeze({ depth:1, glyph:'└──', code:'Execution Platform', title:'SAP BTP' }),
    Object.freeze({ depth:2, glyph:'└──', code:'APIM · CI · EM/AEM', title:'' })
  ]);

  function deipIconMarkup() {
    return '<svg class="sdia-info-deip-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7.2 4.6h2.8c1.1 0 2 .9 2 2v2.5h2.4c1.7 0 3 1.4 3 3.1v2.4c0 1.7-1.3 3.1-3 3.1h-2.5v1.7c0 1.1-.9 2-2 2H8.6c-.9 0-1.6-.8-1.5-1.7l.4-3.4V8.1c0-1.9 1.6-3.5 3.5-3.5h.8V4.6Z"/><path d="M10.5 7.4v8.6"/><path d="M13.8 13.2H9.2"/></svg>';
  }

  function treeIconMarkup(kind) {
    if (kind === 'deip') return deipIconMarkup();
    if (kind === 'sdia') return icon('shield');
    return '<span class="sdia-info-tree-icon-placeholder" aria-hidden="true"></span>';
  }

  function antiPatternMarkup(item, index) {
    return `<article class="sdia-info-antipattern-row" style="--sdia-cascade-delay:${60 + index * 45}ms"><b>${item.name}</b><span>${item.manifestation}</span><strong>${item.consequence}</strong></article>`;
  }

  function treeRowMarkup(line, index) {
    return `<div class="sdia-info-tree-row is-pending${line.pipeline ? ' is-pipeline' : ''}" style="--sdia-tree-depth:${line.depth}; --sdia-tree-line-delay:${index * 140}ms" data-sdia-tree-step>
      <span class="sdia-info-tree-glyph">${line.glyph || ''}</span>
      <span class="sdia-info-tree-node">${treeIconMarkup(line.icon)}</span>
      <span class="sdia-info-tree-main"><b>${line.code}</b>${line.title ? `<small>${line.title}</small>` : ''}</span>
      ${line.badge ? `<em>${line.badge}</em>` : ''}
    </div>`;
  }

  function recordMeta(record) {
    const ipcom = record.ipcom ? ` | IP.com (USA): ${record.ipcom}` : '';
    return `DOI (Europe): ${record.doi}${ipcom}`;
  }

  function moduleCardMarkup(record, index) {
    return `<article class="sdia-info-prior-module" style="--sdia-cascade-delay:${110 + index * 50}ms"><b>${record.code}</b><strong>${record.title}</strong><span>${record.subtitle}</span><small>${recordMeta(record)}</small></article>`;
  }

  function shellMarkup() {
    const deip = PRIOR_ART.deip;
    const sdia = PRIOR_ART.sdia;
    return `<section class="sdia-module sdia-hidden" data-sdia-view="information"><div class="sdia-info-page">
      <section class="sdia-info-intro" data-sdia-info-trigger="intro">
        <div class="sdia-info-kicker">INFORMATION</div>
        <h1><span class="sdia-info-title-green" data-sdia-info-title-green data-fulltext="Why SDIA">Why SDIA</span><span data-sdia-info-title-rest data-fulltext=" exists?"> exists?</span></h1>
        <p>${WHY_TEXT}</p>
      </section>

      <section class="sdia-info-antipatterns"><header><b>Integration Sprawl — recurring anti-patterns</b><span>What the execution layer becomes when governance is missing</span></header><div class="sdia-info-antipattern-head"><span>Anti-Pattern</span><span>Manifestation</span><span>Consequence</span></div><div class="sdia-info-antipattern-grid">${ANTI_PATTERNS.map(antiPatternMarkup).join('')}</div></section>

      <section class="sdia-info-architecture" data-sdia-info-trigger="tree"><header><b>Main layers of the model</b><span>Governance cascade of the SDIA ecosystem</span></header><div class="sdia-info-tree" data-sdia-tree>${TREE_ROWS.map(treeRowMarkup).join('')}</div></section>

      <section class="sdia-info-records"><header><b>Prior Art · DOI (Europe) | IP.com (USA)</b><span>Released under CC BY 4.0 International</span></header><div class="sdia-info-prior-map"><article class="sdia-info-prior-node sdia-info-prior-node-deip"><b>${deip.code}</b><strong>${deip.title}</strong><span>${deip.subtitle}</span><small>${recordMeta(deip)}</small></article><div class="sdia-info-prior-link" aria-hidden="true"></div><section class="sdia-info-prior-hub"><header><b>${sdia.code}</b><strong>${sdia.title}</strong><span>${sdia.subtitle}</span><small>${recordMeta(sdia)}</small></header><div class="sdia-info-prior-modules">${PRIOR_ART.modules.map(moduleCardMarkup).join('')}</div></section></div></section>

      <footer class="sdia-info-footer" data-sdia-info-trigger="copyright"><b data-sdia-copyright-title data-fulltext="ALL RIGHTS RESERVED">ALL RIGHTS RESERVED</b><span data-sdia-copyright-text data-fulltext="Copyright © 2026 Ricardo Luz Holanda Viana.">Copyright © 2026 Ricardo Luz Holanda Viana.</span></footer>
    </div></section>`;
  }

  function prefersReducedMotion() {
    try { return globalThis.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches === true; } catch (_) { return false; }
  }

  async function typeNode(node, text, delayMs, token) {
    if (!node) return;
    node.textContent = '';
    for (let i = 0; i < text.length; i += 1) {
      if (token !== playbackToken || !node.isConnected) return;
      node.textContent += text.charAt(i);
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }

  async function playIntro(section, token) {
    let played = false;
    try { played = sessionStorage.getItem(INTRO_SESSION_KEY) === '1'; } catch (_) {}
    if (played || prefersReducedMotion()) return;
    try { sessionStorage.setItem(INTRO_SESSION_KEY, '1'); } catch (_) {}
    const green = section.querySelector('[data-sdia-info-title-green]');
    const rest = section.querySelector('[data-sdia-info-title-rest]');
    await typeNode(green, green?.getAttribute('data-fulltext') || '', 28, token);
    await typeNode(rest, rest?.getAttribute('data-fulltext') || '', 28, token);
  }

  async function playTree(section, token) {
    let played = false;
    try { played = sessionStorage.getItem(TREE_SESSION_KEY) === '1'; } catch (_) {}
    if (played || prefersReducedMotion()) return;
    try { sessionStorage.setItem(TREE_SESSION_KEY, '1'); } catch (_) {}
    const steps = [...section.querySelectorAll('[data-sdia-tree-step]')];
    for (const step of steps) {
      if (token !== playbackToken || !step.isConnected) return;
      step.classList.remove('is-pending');
      step.classList.add('is-built');
      await new Promise((resolve) => setTimeout(resolve, step.classList.contains('is-pipeline') ? 320 : 230));
    }
  }

  async function playCopyright(section, token) {
    let played = false;
    try { played = sessionStorage.getItem(COPYRIGHT_SESSION_KEY) === '1'; } catch (_) {}
    if (played || prefersReducedMotion()) return;
    try { sessionStorage.setItem(COPYRIGHT_SESSION_KEY, '1'); } catch (_) {}
    const title = section.querySelector('[data-sdia-copyright-title]');
    const text = section.querySelector('[data-sdia-copyright-text]');
    await typeNode(title, title?.getAttribute('data-fulltext') || '', 36, token);
    await typeNode(text, text?.getAttribute('data-fulltext') || '', 22, token);
  }

  function stateRoot(host) {
    return host.closest('.sdia-cc-main') || null;
  }

  function suspendPlayback() {
    playbackToken += 1;
    observer?.disconnect();
    observer = null;
  }

  function maybeTriggerImmediately(section, callback, token, root) {
    if (!section || typeof callback !== 'function') return;
    const rect = section.getBoundingClientRect();
    const rootRect = root?.getBoundingClientRect?.();
    const viewportTop = rootRect ? rootRect.top : 0;
    const viewportBottom = rootRect ? rootRect.bottom : globalThis.innerHeight;
    const visibleTop = Math.max(rect.top, viewportTop);
    const visibleBottom = Math.min(rect.bottom, viewportBottom);
    const ratio = Math.max(0, visibleBottom - visibleTop) / Math.max(1, rect.height);
    if (ratio >= 0.22) {
      observer?.unobserve(section);
      void callback(section, token);
    }
  }

  function observeSection(section, callback, token, root) {
    if (!section) return;
    observer?.observe(section);
    section.__sdiaInformationCallback = callback;
    requestAnimationFrame(() => maybeTriggerImmediately(section, callback, token, root));
  }

  function init(host) {
    if (!host) return;
    suspendPlayback();
    const token = ++playbackToken;
    let introPlayed = false;
    let treePlayed = false;
    let copyrightPlayed = false;
    try { introPlayed = sessionStorage.getItem(INTRO_SESSION_KEY) === '1'; } catch (_) {}
    try { treePlayed = sessionStorage.getItem(TREE_SESSION_KEY) === '1'; } catch (_) {}
    try { copyrightPlayed = sessionStorage.getItem(COPYRIGHT_SESSION_KEY) === '1'; } catch (_) {}

    const green = host.querySelector('[data-sdia-info-title-green]');
    const rest = host.querySelector('[data-sdia-info-title-rest]');
    if (!prefersReducedMotion() && !introPlayed) {
      if (green) green.textContent = '';
      if (rest) rest.textContent = '';
    }
    if (treePlayed || prefersReducedMotion()) {
      host.querySelectorAll('[data-sdia-tree-step]').forEach((step) => {
        step.classList.remove('is-pending');
        step.classList.add('is-built');
      });
    }
    if (!prefersReducedMotion() && !copyrightPlayed) {
      const title = host.querySelector('[data-sdia-copyright-title]');
      const text = host.querySelector('[data-sdia-copyright-text]');
      if (title) title.textContent = '';
      if (text) text.textContent = '';
    }

    const root = stateRoot(host);
    observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting || entry.intersectionRatio < 0.22) return;
        const section = entry.target;
        observer?.unobserve(section);
        const callback = section.__sdiaInformationCallback;
        delete section.__sdiaInformationCallback;
        void callback?.(section, token);
      });
    }, { root, threshold:[0.22, 0.4] });

    observeSection(host.querySelector('[data-sdia-info-trigger="intro"]'), playIntro, token, root);
    observeSection(host.querySelector('[data-sdia-info-trigger="tree"]'), playTree, token, root);
    observeSection(host.querySelector('[data-sdia-info-trigger="copyright"]'), playCopyright, token, root);
  }

  SDIA.InformationUI = Object.freeze({ shellMarkup, init, suspendPlayback });
})();
