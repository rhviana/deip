/* SDIA Governance — generic capability action presentation.
 * Pure markup only. Product/domain modules provide the semantic copy and
 * workspace.js orchestrates navigation/state.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { icon } = SDIA.Core;

  function markup() {
    return `<section class="sdia-module sdia-hidden" data-sdia-view="capability-action">
      <div id="sdia-capability-action-visual"></div>
      <div class="sdia-module-toolbar"><button type="button" data-sdia-action="back-capability">← Back</button><span id="sdia-capability-action-code">SDIA RULE PACK</span></div>
      <div class="sdia-module-heading"><span id="sdia-capability-action-eyebrow">GOVERNED ARTEFACT</span><h1 id="sdia-capability-action-title">Governance Model</h1><p id="sdia-capability-action-description">Define the semantic scope before provisioning the technical artefact.</p></div>
      <div class="sdia-capability-action-layout">
        <div class="sdia-capability-action-panel">
          <div class="sdia-rule-pack-shield" aria-hidden="true">${icon('shield')}</div>
          <dl>
            <div><dt>Active capability</dt><dd id="sdia-capability-action-product">SAP BTP Integration Suite</dd></div>
            <div><dt>Governance rule pack</dt><dd id="sdia-capability-action-model">SDIA</dd></div>
            <div><dt>Required semantic inputs</dt><dd id="sdia-capability-action-inputs">Domain and governed context</dd></div>
            <div><dt>Provisioning status</dt><dd>UI model ready · native adapter not connected</dd></div>
          </dl>
        </div>
        <div class="sdia-capability-action-placeholder">
          <i>${icon('catalog')}</i>
          <b>Rule-pack binding required</b>
          <p id="sdia-capability-action-note">The creation workflow will be activated after the corresponding governance naming grammar and native SAP product flow are mapped.</p>
          <button type="button" class="sdia-primary-action" disabled>Provisioning adapter — next phase</button>
        </div>
      </div>
    </section>`;
  }

  SDIA.CapabilityActionUI = Object.freeze({ markup });
})();
