/* SDIA Governance — Home governed execution entry points.
 * Ordering is action-oriented: creation first, then product control planes,
 * then security operations.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { icon } = SDIA.Core;

  const ENTRY_POINTS = Object.freeze([
    Object.freeze({ label:'Create Package', detail:'Prepare governed package', icon:'packages', route:'/shell/design', product:'ci', actionId:'create-package' }),
    Object.freeze({ label:'Create Package Artefacts', detail:'Prepare package execution context', icon:'create', route:'/shell/design', product:'ci', actionId:'create-artifacts' }),
    Object.freeze({ label:'APIM', detail:'Open API governance', icon:'proxy', route:'/shell/configure', product:'apim', actionId:'open-apim' }),
    Object.freeze({ label:'EM / AEM', detail:'Open event governance', icon:'eventmesh', route:'/shell/configureeventmesh', product:'eventmesh', actionId:'open-eventmesh' }),
    Object.freeze({ label:'Security Materials', detail:'Open credentials governance', icon:'credential', route:'/shell/monitoring/SecurityMaterials', product:'security', actionId:'open-security-materials' }),
    Object.freeze({ label:'Certificates / Keystore', detail:'Open certificate governance', icon:'certificate', route:'/shell/monitoring/Keystore', product:'security', actionId:'open-keystore' })
  ]);

  function markup() {
    return `<section class="sdia-home-entry-points" aria-label="Entry points">
      <header><b>ENTRY POINTS</b><span>Open governed workspace</span></header>
      <div class="sdia-home-entry-grid">${ENTRY_POINTS.map((entry) => `<button type="button" data-sdia-home-route="${entry.route}" data-sdia-home-product="${entry.product}" data-sdia-navigation-action="${entry.actionId}" aria-label="${entry.label}"><i>${icon(entry.icon)}</i><span><b>${entry.label}</b><small>${entry.detail}</small></span><em aria-hidden="true">›</em></button>`).join('')}</div>
    </section>`;
  }

  SDIA.HomeEntryPoints = Object.freeze({ ENTRY_POINTS, markup });
})();
