/* SDIA Governance — Home workspace
 * Owns the product story, domain-layer statement and governed entry points.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { icon } = SDIA.Core;
  const TYPEWRITER_SESSION_KEY = 'sdia:home-intro-typewriter-played:v1.1.0';
  SDIA.VisualExperience.register('home', { assetDir:'src/ui/home/assets/control-plane' });

  const GOVERNANCE_PILLARS = Object.freeze([
    Object.freeze({
      code:'ODCP', title:'Cloud Integration', icon:'packages',
      items:Object.freeze([
        'Govern Domain Package naming',
        'Govern Package overview image & description',
        'Govern iFlow and reusable-resource naming',
        'Check URL facade · Adapters · JMS naming',
        'Govern Script Collection naming'
      ])
    }),
    Object.freeze({
      code:'GDCR + DDCR', title:'API Management', icon:'proxy',
      items:Object.freeze([
        'Govern API Proxy naming & URL facade',
        'Prepare DDCR JavaScript Policy · manual import',
        'Prepare KVM endpoint-destination keys',
        'Review deterministic route continuity'
      ])
    }),
    Object.freeze({
      code:'EDCP', title:'Event Mesh / AEM', icon:'eventmesh',
      items:Object.freeze([
        'Govern Queue naming',
        'Govern Topic & event namespace naming',
        'Govern subscription naming continuity',
        'Preserve Domain identity across event channels'
      ])
    })
  ]);

  function shellMarkup() {
    return '<section class="sdia-module sdia-hidden" data-sdia-view="home-hub"><div id="sdia-home-hub-content"></div></section>';
  }

  function eyeMarkup() {
    return `<span class="sdia-home-eye" aria-hidden="true">
      <svg viewBox="0 0 64 64" role="presentation">
        <defs>
          <linearGradient id="sdia-eye-g" x1="0" x2="1">
            <stop offset="0%" stop-color="#8FE38A"/>
            <stop offset="100%" stop-color="#2EA34F"/>
          </linearGradient>
        </defs>
        <path class="sdia-home-eye-outline" d="M6 32c6-10 15-16 26-16s20 6 26 16c-6 10-15 16-26 16S12 42 6 32Z"/>
        <circle class="sdia-home-eye-iris" cx="32" cy="32" r="9"/>
        <circle class="sdia-home-eye-pupil" cx="32" cy="32" r="4.2"/>
        <path class="sdia-home-eye-highlight" d="M28.5 28.3c1.4-1.2 3.8-1.4 5.3-.3"/>
        <rect class="sdia-home-eye-lid" x="5" y="10" width="54" height="24" rx="12"/>
      </svg>
    </span>`;
  }

  function heroMarkup() {
    return `<section class="sdia-home-hero">
      <div class="sdia-home-hero-copy">
        <div class="sdia-home-welcome" data-sdia-home-intro="welcome" data-fulltext="Welcome to the SDIA Control Plane">Welcome to the SDIA Control Plane</div>
        <h1><span class="sdia-home-keyword-domain">Domain</span> as the primary governance key; technology becomes the <span class="sdia-home-keyword-execution">execution layer</span>.</h1>
        <p class="sdia-home-hero-lead">SDIA governs the semantic identity across your integration artefacts, ensuring consistency, discoverability, and trust — so your technology can execute with confidence.</p>
      </div>
      <aside class="sdia-home-hero-visual" aria-label="SDIA governance overview visual">
        <div class="sdia-home-hero-art" data-sdia-home-visual aria-hidden="true">
          <img data-sdia-home-image src="${SDIA.VisualExperience.asset('home')}" alt="">
        </div>
      </aside>
    </section>`;
  }

  function pillarMarkup(pillar, index) {
    return `<article class="sdia-home-pillar-card" style="--sdia-home-card-delay:${140 + index * 110}ms">
      <header><i>${icon(pillar.icon)}</i><div><span>${pillar.code}</span><b>${pillar.title}</b></div></header>
      <ul data-sdia-home-pillar-items>${pillar.items.map((item) => `<li data-fulltext="${String(item).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')}">${item}</li>`).join('')}</ul>
    </article>`;
  }

  function domainLayerMarkup() {
    return `<section class="sdia-home-domain-board" aria-label="SDIA Domain Layer governance">
      <aside class="sdia-home-domain-label">${eyeMarkup()}<b>THE DOMAIN<br>NEVER LIES</b></aside>
      <div class="sdia-home-domain-content">
        <header><b>THE DOMAIN LAYER</b></header>
        <div class="sdia-home-pillar-grid">${GOVERNANCE_PILLARS.map(pillarMarkup).join('')}</div>
      </div>
    </section>`;
  }

  function markup() {
    return `<div class="sdia-home-hub">${heroMarkup()}${domainLayerMarkup()}${SDIA.HomeEntryPoints.markup()}</div>`;
  }

  function prefersReducedMotion() {
    try { return globalThis.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches === true; } catch (_) { return false; }
  }

  async function typeNode(node, text, delayMs = 18) {
    node.textContent = '';
    for (let i = 0; i < text.length; i += 1) {
      node.textContent += text.charAt(i);
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }

  async function runTypewriter(host) {
    if (!host || prefersReducedMotion()) return;
    let alreadyPlayed = false;
    try { alreadyPlayed = sessionStorage.getItem(TYPEWRITER_SESSION_KEY) === '1'; } catch (_) {}
    if (alreadyPlayed) return;
    try { sessionStorage.setItem(TYPEWRITER_SESSION_KEY, '1'); } catch (_) {}

    const welcome = host.querySelector('[data-sdia-home-intro="welcome"]');
    if (welcome) {
      await typeNode(welcome, welcome.getAttribute('data-fulltext') || welcome.textContent || '', 22);
      await new Promise((resolve) => setTimeout(resolve, 120));
    }

    const nodes = [...host.querySelectorAll('[data-sdia-home-pillar-items] li')];
    for (const node of nodes) {
      const text = node.getAttribute('data-fulltext') || node.textContent || '';
      await typeNode(node, text, 16);
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
  }

  function init(host) {
    if (!host) return;
    void runTypewriter(host);
  }

  SDIA.HomeUI = Object.freeze({ shellMarkup, markup, init });
})();
