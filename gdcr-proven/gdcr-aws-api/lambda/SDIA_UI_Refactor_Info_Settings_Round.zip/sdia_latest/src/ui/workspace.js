/* SDIA Governance v1.0.0 — shared Control Center shell. Product business logic stays in product modules. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { state, constants, escapeHtml, normalizeToken, runtimeUrl, delay, icon, saveSettings } = SDIA.Core;
  const { OVERLAY_ID, SPLASH_KEY } = constants;
  const FIRST_HOME_KEY = 'sdia:first-home-open:v1.0.0';
  const NAV_COLLAPSE_KEY = 'sdia:nav-collapsed:v1.0.0';
  const designContext = (...args) => SDIA.RouteContext.designContext(...args);
  const integrationSuiteContext = (...args) => SDIA.RouteContext.integrationSuiteContext(...args);
  const activeProductProfile = (...args) => SDIA.RouteContext.activeProductProfile(...args);
  const environmentName = (...args) => SDIA.RouteContext.environmentName(...args);
  const allowedModulesForProduct = (...args) => SDIA.WorkspaceRouter.allowedModulesForProduct(...args);
  const defaultModuleForRoute = (...args) => SDIA.WorkspaceRouter.defaultModuleForRoute(...args);
  const persistControlCenterState = (...args) => SDIA.Navigation.persistControlCenterState(...args);
  const readPersistedControlCenterState = (...args) => SDIA.Navigation.readPersistedControlCenterState(...args);
  const restoreControlCenterFields = (...args) => SDIA.Navigation.restoreControlCenterFields(...args);
  const clearPersistedControlCenterState = (...args) => SDIA.Navigation.clearPersistedControlCenterState(...args);
  const updateWorkspaceChrome = (...args) => SDIA.Navigation.updateWorkspaceChrome(...args);
  const backInternal = (...args) => SDIA.Navigation.backInternal(...args);
  const resetBuilderFromSettings = (...args) => SDIA.CloudIntegration.Package.resetBuilderFromSettings(...args);
  const populateCatalogControls = (...args) => SDIA.CloudIntegration.Package.populateCatalogControls(...args);
  const updateAssessmentContext = (...args) => SDIA.CloudIntegration.Package.updateAssessmentContext(...args);
  const bridgeRequest = (...args) => SDIA.BridgeClient.request(...args);
  let dashboardSnapshot = null;
  let dashboardIflowCache = null;
  const CONTROL_PLANE_HOME_MODULES = new Set(['home-hub','dashboard','what-is-sdia','how-to','catalog','domain-help','contact','settings']);
  function usesControlPlaneHomeMenu(module = state.activeModule) { return CONTROL_PLANE_HOME_MODULES.has(module); }
  // Playback token for the What-is-SDIA typewriter: bumping it cancels any
  // in-flight typing loop (module switch, overlay close, re-render), so timers
  // never keep writing into detached or hidden nodes.
  let whatIsSdiaPlaybackToken = 0;

  function hasShownSplash() { try { return sessionStorage.getItem(SPLASH_KEY) === '1'; } catch (_) { return false; } }
  async function showSplash() {
    if (state.settings.transitionSplashEnabled === false || hasShownSplash()) return;
    try { sessionStorage.setItem(SPLASH_KEY, '1'); } catch (_) {}
    const splash = document.createElement('div'); splash.className = 'sdia-brand-splash-overlay';
    const profile = activeProductProfile();
    splash.innerHTML = `<div class="sdia-brand-splash-card"><img src="${runtimeUrl('src/shared/brand/assets/icon128.png')}" alt="SDIA"><strong>SDIA</strong><span>Independent governance for SAP Integration Suite</span><em>${escapeHtml(profile.modelCode)} · ${escapeHtml(profile.capability)}</em><small>THE DOMAIN NEVER LIES.</small></div>`;
    document.body.appendChild(splash); await delay(1300); splash.classList.add('closing'); await delay(220); splash.remove();
  }

  async function openControlCenter(module = null, options = {}) {
    if (!SDIA.RouteContext.isSupportedGovernanceRoute()) { showToast('SDIA Governance is available only on supported SAP Integration Suite governance routes.', 5200); return; }
    if (!state.mounted) SDIA.Launcher.mount({ onOpen: () => openControlCenter() });
    await showSplash();
    await SDIA.Orientation?.init?.();
    if (!state.overlay) createControlCenter();
    applyAppearanceTheme();

    const snapshot = options.restoreSnapshot || readPersistedControlCenterState();
    const allowed = allowedModulesForProduct();
    const restoreWorkspace = state.settings.restoreLastWorkspaceInSession !== false;
    let firstHomeOpen = false;
    if (!module && !options.restoreSnapshot) {
      try {
        firstHomeOpen = sessionStorage.getItem(FIRST_HOME_KEY) !== '1';
        if (firstHomeOpen) sessionStorage.setItem(FIRST_HOME_KEY, '1');
      } catch (_) {}
    }
    let targetModule = module;
    if (!targetModule) {
      if (firstHomeOpen && allowed.includes('home-hub')) targetModule = 'home-hub';
      else if (activeProductProfile().id === 'home' && allowed.includes('home-hub')) targetModule = 'home-hub';
      else if (restoreWorkspace && snapshot?.activeModule && snapshot.activeModule !== 'home-hub' && allowed.includes(snapshot.activeModule)) targetModule = snapshot.activeModule;
      else if (state.settings.startNewContextInOverview === false && state.activeModule !== 'home-hub' && allowed.includes(state.activeModule)) targetModule = state.activeModule;
      else targetModule = 'overview';
    }
    if (!allowed.includes(targetModule)) targetModule = activeProductProfile().id === 'home' && allowed.includes('home-hub') ? 'home-hub' : 'overview';

    state.overlay.classList.remove('sdia-hidden');
    document.documentElement.classList.add('sdia-control-center-open');
    SDIA.Launcher.suppress(true);
    applyProductContext();
    state.internalHistory = restoreWorkspace && Array.isArray(snapshot?.internalHistory) ? snapshot.internalHistory.slice(-14) : [];
    switchModule(targetModule, { push:false, silentPersist:true });
    if (snapshot && state.settings.preserveDraftSession !== false) restoreControlCenterFields(snapshot);
    refreshContextPanel(); updateWorkspaceChrome();
    persistControlCenterState('workspace-open', { open:true });
  }

  function closeControlCenter() {
    if (!state.overlay) return;
    whatIsSdiaPlaybackToken += 1;
    SDIA.Orientation?.suspendPlayback?.();
    state.overlay.classList.add('sdia-hidden');
    document.documentElement.classList.remove('sdia-control-center-open');
    SDIA.Launcher.suppress(false);
    persistControlCenterState('workspace-close', { open:false });
  }


  function isEditableTarget(target) {
    if (!(target instanceof Element)) return false;
    return Boolean(target.closest('input, textarea, select, [contenteditable="true"]'));
  }

  function bindContentProtection(overlay) {
    if (!overlay || overlay.dataset.sdiaProtectionBound) return;
    overlay.dataset.sdiaProtectionBound = '1';
    const blockStaticContentAction = (event) => {
      if (isEditableTarget(event.target)) return;
      if (event.type === 'dragstart' && event.target instanceof Element && event.target.closest('[data-sdia-classification-card]')) return;
      event.preventDefault();
      if (event.type !== 'dragstart') showToast('Copy is disabled for SDIA reference content.', 2200);
    };
    overlay.addEventListener('copy', blockStaticContentAction, true);
    overlay.addEventListener('cut', blockStaticContentAction, true);
    overlay.addEventListener('contextmenu', blockStaticContentAction, true);
    overlay.addEventListener('dragstart', blockStaticContentAction, true);
  }

  function createControlCenter() {
    const overlay = document.createElement('div'); overlay.id = OVERLAY_ID; overlay.className = 'sdia-control-center-overlay sdia-hidden';
    overlay.innerHTML = `
      <section class="sdia-control-center" role="dialog" aria-modal="true" aria-label="SDIA Governance control center">
        <header class="sdia-cc-header"><div class="sdia-cc-brand"><img src="${runtimeUrl('src/shared/brand/assets/icon64.png')}" alt=""><div><b>SDIA — Semantic Domain Integration Architecture</b><p>Independent Domain Governance for SAP Integration Suite.</p></div></div><div class="sdia-cc-header-actions"><span id="sdia-cc-status-pill" class="sdia-status-pill">PACKAGE GOVERNANCE READY</span><button type="button" id="sdia-cc-close" aria-label="Close">×</button></div></header>
        <div class="sdia-cc-layout">
          <nav class="sdia-cc-nav" aria-label="Governance modules">
            ${SDIA.NavigationMenu.markup()}
          </nav>
          <main class="sdia-cc-main"><div class="sdia-workspace-chrome"><button type="button" id="sdia-workspace-back" data-sdia-action="back-internal">← Back</button><nav id="sdia-workspace-breadcrumb" class="sdia-workspace-breadcrumb" aria-label="Workspace breadcrumb"></nav>${SDIA.ControlPlaneHome.markup()}</div>
            ${SDIA.HomeUI.shellMarkup()}${whatIsSdiaMarkup()}${dashboardMarkup()}${overviewMarkup()}${SDIA.Orientation.markup()}${SDIA.InformationUI.shellMarkup()}${SDIA.CloudIntegration.Package.packagesMarkup()}${SDIA.CloudIntegration.Package.packageMapMarkup()}${SDIA.CloudIntegration.Package.packageEditListMarkup()}${SDIA.CloudIntegration.Package.packageEditFormMarkup()}${SDIA.CloudIntegration.Package.packageCreateMarkup()}${SDIA.CloudIntegration.Iflow.packageWorkspaceMarkup()}${SDIA.ApiManagement.markup()}${SDIA.EventMesh.markup()}${SDIA.Security.markup()}${SDIA.CapabilityActionUI.markup()}${assessmentMarkup()}${SDIA.GuidanceUI.markup()}${SDIA.CatalogUI.markup()}${settingsMarkup()}${SDIA.ContactUI.markup()}
          </main>
        </div>
      </section>`;
    document.body.appendChild(overlay); state.overlay = overlay;
    applyAppearanceTheme();
    try { overlay.querySelector('.sdia-control-center')?.classList.toggle('sdia-nav-collapsed', sessionStorage.getItem(NAV_COLLAPSE_KEY) === '1'); } catch (_) {}
    overlay.querySelector('#sdia-cc-close').addEventListener('click', closeControlCenter);
    overlay.querySelector('#sdia-dashboard-refresh')?.addEventListener('click', () => { void loadDashboard(); });
    overlay.addEventListener('click', (event) => { if (event.target === overlay) closeControlCenter(); });
    overlay.querySelectorAll('[data-sdia-module]').forEach((button) => button.addEventListener('click', () => { persistControlCenterState('nav-before-switch'); switchModule(button.dataset.sdiaModule, { fromNav:true }); }));
    overlay.querySelectorAll('[data-sdia-action]').forEach((button) => button.addEventListener('click', (event) => handleWorkspaceAction(button.dataset.sdiaAction, event)));
    overlay.addEventListener('input', () => persistControlCenterState('field-input'), true);
    overlay.addEventListener('change', () => persistControlCenterState('field-change'), true);
    bindContentProtection(overlay);
    SDIA.CloudIntegration.Package.bindPackageBuilder(); SDIA.CloudIntegration.Package.bindPackageEditForm(); SDIA.CloudIntegration.Package.bindPackageMap(); SDIA.GuidanceUI.bind(); SDIA.CatalogUI.bind(); SDIA.Security.bind(); bindSettings(); SDIA.CloudIntegration.Package.populateCatalogControls(); resetBuilderFromSettings(); applyProductContext();
  }
  const OVERVIEW_REFERENCES = Object.freeze({
    ci: Object.freeze([
      { code:'SDIA', title:'Semantic Domain Integration Architecture', doi:'10.5281/zenodo.19788232', href:'https://zenodo.org/records/19788232' },
      { code:'ODCP', title:'Orchestration Domain-Centric Pattern', doi:'10.5281/zenodo.19786661', href:'https://zenodo.org/records/19786661' }
    ]),
    apim: Object.freeze([
      { code:'SDIA', title:'Semantic Domain Integration Architecture', doi:'10.5281/zenodo.19788232', href:'https://zenodo.org/records/19788232' },
      { code:'GDCR', title:'Gateway Domain-Centric Routing', doi:'10.5281/zenodo.19711693', href:'https://zenodo.org/records/19711693' },
      { code:'DDCR', title:'Domain Driven-Centric Router', doi:'10.5281/zenodo.19820524', href:'https://zenodo.org/records/19820524' }
    ]),
    eventmesh: Object.freeze([
      { code:'SDIA', title:'Semantic Domain Integration Architecture', doi:'10.5281/zenodo.19788232', href:'https://zenodo.org/records/19788232' },
      { code:'EDCP', title:'Event Domain-Centric Pattern', doi:'10.5281/zenodo.19727832', href:'https://zenodo.org/records/19727832' }
    ]),
    unknown: Object.freeze([
      { code:'SDIA', title:'Semantic Domain Integration Architecture', doi:'10.5281/zenodo.19788232', href:'https://zenodo.org/records/19788232' }
    ])
  });

  function overviewProductConfig(profile = activeProductProfile()) {
    const ciContext = designContext();
    if (profile.id === 'ci' && ciContext.type === 'contentpackage') return {
      eyebrow:'CLOUD INTEGRATION · ODCP · PACKAGE ARTIFACTS',
      title:'Package Artifacts Governance',
      description:`Executive view of the active package boundary · ${ciContext.packageId || 'Current package'}`,
      ruleCode:'ODCP', ruleName:'Orchestration Domain-Centric Pattern', ruleIcon:'map',
      scopeTitle:'Package Artifacts', scopeText:'Domain Boundary → Artefacts',
      architectureMode:'artifacts',
      architecture:[
        { code:'DOMAIN', label:'Semantic boundary', icon:'shield' },
        { code:'ARTEFACTS', label:'Package execution objects', icon:'packages' }
      ],
      artefacts:[
        { code:'iFlow', icon:'packages' }, { code:'Value Mapping', icon:'keyvalue' },
        { code:'Message Mapping', icon:'catalog' }, { code:'Script', icon:'policy' },
        { code:'KVM', icon:'keyvalue' }, { code:'Resources', icon:'catalog' }
      ]
    };
    if (profile.id === 'ci') return {
      eyebrow:'CLOUD INTEGRATION · PACKAGE GOVERNANCE',
      title:'Cloud Integration Governance',
      description:'Domain-Centric governance for SAP Integration Suite.',
      ruleCode:'ODCP', ruleName:'Orchestration Domain-Centric Pattern', ruleIcon:'map',
      scopeTitle:'Package Domain Boundary', scopeText:'Semantic boundary → governed Package metadata',
      architectureMode:'package-flow',
      architecture:[
        { code:'SDIA', label:'Semantic governance', icon:'shield' },
        { code:'DOMAIN BOUNDARY', label:'Business semantic boundary', icon:'catalog' },
        { code:'DOMAIN PACKAGE GOVERNANCE', label:'Governed package boundary', icon:'shield' }
      ]
    };
    if (profile.id === 'apim') return {
      eyebrow:'API MANAGEMENT · GDCR / DDCR',
      title:'API Management Governance',
      description:'Domain-Centric governance for SAP Integration Suite.',
      ruleCode:'GDCR', ruleName:'Gateway Domain-Centric Routing', ruleIcon:'proxy',
      scopeTitle:'Deterministic Domain Routing', scopeText:'Semantic facade → DDCR → Backend',
      architectureMode:'linear',
      architecture:[
        { code:'SDIA', label:'Semantic governance layer', icon:'shield' },
        { code:'GDCR', label:'Domain gateway facade', icon:'proxy' },
        { code:'DDCR', label:'Deterministic resolution', icon:'policy' },
        { code:'APIM', label:'Gateway execution', icon:'proxy' }
      ]
    };
    if (profile.id === 'security') return {
      eyebrow:'SECURITY · SDIA', title:'Security Naming Governance',
      description:'Govern Security Material and Keystore aliases while secret values remain exclusively native to SAP.',
      ruleCode:'SDIA', ruleName:'Semantic Domain Integration Architecture', ruleIcon:'keyvalue',
      scopeTitle:'Security Boundary', scopeText:'Domain → Subdomain → Target System → Security Type',
      architectureMode:'linear', architecture:[
        { code:'DOMAIN', label:'Semantic ownership', icon:'shield' },
        { code:'ALIAS', label:'Governed security identity', icon:'keyvalue' },
        { code:'SAP', label:'Native secret lifecycle', icon:'settings' }
      ]
    };
    if (profile.id === 'eventmesh') return {
      eyebrow:'EVENT MESH · EDCP',
      title:'Event Mesh Governance',
      description:'Domain-Centric governance for SAP Integration Suite.',
      ruleCode:'EDCP', ruleName:'Event Domain-Centric Pattern', ruleIcon:'eventmesh',
      scopeTitle:'Event Domain Governance', scopeText:'Domain → Event → Channel → Consumers',
      architectureMode:'linear',
      architecture:[
        { code:'SDIA', label:'Semantic governance layer', icon:'shield' },
        { code:'EDCP', label:'Event domain pattern', icon:'eventmesh' },
        { code:'EVENT', label:'Asynchronous execution', icon:'topic' }
      ]
    };
    return {
      eyebrow:'SDIA · SAP BTP INTEGRATION SUITE', title:'Semantic Domain Governance',
      description:'Domain-Centric governance for SAP Integration Suite.',
      ruleCode:'SDIA', ruleName:'Semantic Domain Integration Architecture', ruleIcon:'shield',
      scopeTitle:'Supported Capability', scopeText:'Cloud Integration · API Management · Event Mesh',
      architectureMode:'linear', architecture:[{ code:'SDIA', label:'Semantic governance layer', icon:'shield' }]
    };
  }

  function overviewArchitectureMarkup(config) {
    if (config.architectureMode === 'package-flow') {
      return `<div class="sdia-overview-domain-package-flow">
        <div class="sdia-overview-domain-flow-row">
          <article class="sdia-overview-arch-node" style="--sdia-arch-delay:70ms"><div>${icon('shield')}</div><b>SDIA</b><span>Semantic governance</span></article>
          <i class="sdia-overview-arch-connector" style="--sdia-line-delay:180ms" aria-hidden="true"><span></span></i>
          <article class="sdia-overview-arch-node sdia-overview-domain-boundary-node" style="--sdia-arch-delay:260ms"><div>${icon('catalog')}</div><b>DOMAIN BOUNDARY</b><span>Business semantic boundary</span></article>
          <i class="sdia-overview-arch-connector sdia-overview-package-governance-line" style="--sdia-line-delay:360ms" aria-hidden="true"><span></span></i>
          <article class="sdia-overview-arch-node sdia-overview-package-governance-node" style="--sdia-arch-delay:450ms"><div>${icon('shield')}</div><b>DOMAIN PACKAGE<br>GOVERNANCE</b><span>Governed package boundary</span></article>
        </div>
        <div class="sdia-overview-ci-platform sdia-overview-ci-platform-inline"><span>SAP</span><b>Cloud Integration</b></div>
        <div class="sdia-overview-package-workchart" aria-label="Governed package metadata">
          <div class="sdia-overview-package-workchart-stem" aria-hidden="true"></div>
          <div class="sdia-overview-package-workchart-fields">
            ${['Name','Short Description','Version','Vendor'].map((field,index) => `<article class="sdia-overview-package-field" style="--sdia-field-delay:${620 + index * 85}ms"><i aria-hidden="true"></i><div>${icon(index === 0 ? 'packages' : index === 1 ? 'catalog' : index === 2 ? 'policy' : 'contact')}</div><b>${field}</b></article>`).join('')}
          </div>
        </div>
      </div>`;
    }
    if (config.architectureMode === 'artifacts') {
      const [domain, artefacts] = config.architecture;
      const children = config.artefacts || [];
      return `<div class="sdia-overview-artifact-tree" style="--sdia-artifact-count:${Math.max(1, children.length)}">
        <div class="sdia-overview-artifact-spine">
          <article class="sdia-overview-arch-node sdia-overview-arch-node-domain" style="--sdia-arch-delay:90ms"><div>${icon(domain.icon)}</div><b>${escapeHtml(domain.code)}</b><span>${escapeHtml(domain.label)}</span></article>
          <i class="sdia-overview-arch-connector" style="--sdia-line-delay:230ms" aria-hidden="true"><span></span></i>
          <article class="sdia-overview-arch-node sdia-overview-arch-node-artifacts" style="--sdia-arch-delay:320ms"><div>${icon(artefacts.icon)}</div><b>${escapeHtml(artefacts.code)}</b><span>${escapeHtml(artefacts.label)}</span></article>
        </div>
        <div class="sdia-overview-artifact-stem" aria-hidden="true"></div>
        <div class="sdia-overview-artifact-children">
          ${children.map((item,index) => `<article class="sdia-overview-artifact-child" style="--sdia-artifact-delay:${560 + index * 80}ms"><i aria-hidden="true"></i><div>${icon(item.icon)}</div><b>${escapeHtml(item.code)}</b></article>`).join('')}
        </div>
      </div>`;
    }
    return config.architecture.map((item, index) => `${index ? `<i class="sdia-overview-arch-connector" style="--sdia-line-delay:${90 + (index - 1) * 180 + 135}ms" aria-hidden="true"><span></span></i>` : ''}<article class="sdia-overview-arch-node" style="--sdia-arch-delay:${90 + index * 180}ms"><div>${icon(item.icon)}</div><b>${escapeHtml(item.code)}</b><span>${escapeHtml(item.label)}</span></article>`).join('');
  }

  function overviewReferencesMarkup(profile) {
    const refs = OVERVIEW_REFERENCES[profile.id] || OVERVIEW_REFERENCES.unknown;
    return refs.map((item) => `<a class="sdia-overview-reference" href="${escapeHtml(item.href)}" target="_blank" rel="noopener noreferrer"><span>${escapeHtml(item.code)}</span><div><b>${escapeHtml(item.title)}</b><small>DOI ${escapeHtml(item.doi)}</small></div><i>${icon('arrow')}</i></a>`).join('');
  }

  function overviewVisualScope(profile = activeProductProfile()) {
    if (profile.id === 'ci') return designContext().type === 'contentpackage' ? 'artifacts' : 'package';
    if (profile.id === 'apim') return 'apim';
    if (profile.id === 'eventmesh') return 'eventmesh';
    if (profile.id === 'security') return integrationSuiteContext().routeType === 'keystore' ? 'certificate' : 'credentials';
    return '';
  }

  function renderOverviewContext(profile = activeProductProfile()) {
    if (profile.id === 'home') return;
    if (!state.overlay) return;
    const config = overviewProductConfig(profile);
    const visualHost = state.overlay.querySelector('#sdia-overview-control-plane-visual');
    const architecture = state.overlay.querySelector('#sdia-overview-architecture-flow');
    const references = state.overlay.querySelector('#sdia-overview-references-list');
    const landscape = state.overlay.querySelector('#sdia-overview-landscape');
    const visualScope = overviewVisualScope(profile);
    if (visualHost) visualHost.innerHTML = visualScope ? SDIA.ControlPlaneVisual.markupForScope(visualScope) : '';
    if (architecture) architecture.innerHTML = overviewArchitectureMarkup(config);
    if (references) references.innerHTML = overviewReferencesMarkup(profile);
    if (landscape) {
      if (profile.id === 'ci') {
        const ciContext = designContext();
        if (ciContext.type === 'contentpackage') {
          landscape.innerHTML = `<div class="sdia-overview-landscape-head"><div><span>ACTIVE PACKAGE BOUNDARY</span><b>${escapeHtml(ciContext.packageId || 'Current package')}</b></div><button type="button" data-sdia-overview-module="package-workspace">Open Package Artifacts →</button></div><div class="sdia-overview-package-context"><div><span>Governance</span><b>ODCP</b></div><div><span>Semantic Scope</span><b>Domain → Package → Artefacts</b></div><p>Artifact counts are intentionally not synthesized. The package artifact inventory will become factual only after its native SAP inventory flow is mapped and validated.</p></div>`;
        } else {
          const snapshot = SDIA.CloudIntegration.Package.getPackageGovernanceOverview?.();
          if (snapshot?.loaded) {
            const domainRows = snapshot.domains.length ? snapshot.domains.slice(0, 3).map((row) => `<div class="sdia-overview-domain-row"><span><b>${escapeHtml(row.code)}</b><small>${escapeHtml(row.name)}</small></span><em>${row.packages}</em></div>`).join('') : '<p class="sdia-overview-empty">No governed Domains detected yet.</p>';
            landscape.innerHTML = `<div class="sdia-overview-landscape-head"><div><span>CURRENT DOMAIN LANDSCAPE</span><b>Real package architecture</b></div></div><div class="sdia-overview-landscape-stats"><div><span>Total</span><b>${snapshot.total}</b></div><div class="is-governed"><span>Governed</span><b>${snapshot.governed}</b></div><div class="is-legacy"><span>Legacy</span><b>${snapshot.unclassified}</b></div><div class="is-domains"><span>Domains</span><b>${snapshot.domains.length}</b></div></div><div class="sdia-overview-domain-list">${domainRows}</div>`;
          } else {
            landscape.innerHTML = `<div class="sdia-overview-landscape-head"><div><span>CURRENT DOMAIN LANDSCAPE</span><b>Tenant inventory not loaded yet</b></div></div><p class="sdia-overview-empty">Load the Governance Map from the sidebar to reconstruct the real package landscape. No synthetic package counts are displayed.</p>`;
          }
        }
      } else {
        landscape.innerHTML = `<div class="sdia-overview-landscape-head"><div><span>CURRENT CAPABILITY LANDSCAPE</span><b>${escapeHtml(profile.capability)}</b></div></div><p class="sdia-overview-empty">Route detection is active. Tenant inventory metrics will appear only after the native ${escapeHtml(profile.modelCode)} inventory adapter is mapped and validated.</p>`;
      }
      landscape.querySelectorAll('[data-sdia-overview-module]').forEach((button) => button.addEventListener('click', () => switchModule(button.dataset.sdiaOverviewModule)));
    }
  }

  function overviewMarkup() {
    return `
      <section class="sdia-module" data-sdia-view="overview">
        <div id="sdia-overview-control-plane-visual" class="sdia-overview-control-plane-visual"></div>
        <article class="sdia-overview-architecture-card">
          <header><span>ARCHITECTURE CONTEXT</span><b>From semantic intent to execution</b></header>
          <div id="sdia-overview-architecture-flow" class="sdia-overview-architecture-flow" aria-label="Active SDIA architecture"></div>
        </article>
        <section id="sdia-overview-landscape" class="sdia-overview-landscape"></section>
        <section class="sdia-overview-references sdia-overview-references-wide">
          <div class="sdia-overview-section-title"><span>ARCHITECTURE REFERENCES</span><b>Research behind this governance context</b></div>
          <div id="sdia-overview-references-list" class="sdia-overview-references-list"></div>
        </section>
      </section>`;
  }


  function whatIsSdiaMarkup() {
    return `<section class="sdia-module sdia-hidden" data-sdia-view="what-is-sdia">
      <div class="sdia-module-heading sdia-what-heading"><span>SDIA · EXPLAINED</span><h1>What is SDIA?</h1><p>A short interactive explanation of what SDIA governs, what technology executes and why the Domain remains visible end to end.</p></div>
      <div id="sdia-what-content" class="sdia-what-content"></div>
    </section>`;
  }

  const WHAT_SDIA_STEPS = Object.freeze([
    ['THE PROBLEM','Without semantic governance, integration objects are commonly named after products, projects or technical implementation details: ServiceNow_to_SuccessFactors, SNDEV, REST_Interface_01. Those names describe technology, not business ownership.'],
    ['THE DOMAIN LAYER','SDIA starts above technology. The business requirement is interpreted as a Domain and Subdomain such as Sales · O2C, Finance · R2R or HR · Core. That semantic boundary becomes the identity contract.'],
    ['WHAT SDIA GOVERNS','SDIA governs the identity of integration artefacts: Package, iFlow, API facade, DDCR policy metadata, credentials, certificates, mappings, queues, topics and reusable resources.'],
    ['WHAT SDIA DOES NOT GOVERN','SDIA does not control SOAP, REST, HTTPS, JDBC, SFTP, JMS, SQS or other transport mechanisms. Technology is free to change while the business Domain remains stable.'],
    ['THE MESSAGE','At runtime the transport delivers an electronic message: XML, JSON, EDI, Plain Text, PDF and others. The Domain does not disappear — it is still the business meaning carried through the integration.'],
    ['THE RESULT','Instead of a tenant full of vendor-centric objects, the same semantic identity can be recognized across Package, iFlow, Credential, Certificate, Value Mapping, API and Event artefacts. The Domain becomes the transversal key.']
  ]);

  function renderWhatIsSdia(stepIndex=0) {
    const host=state.overlay?.querySelector('#sdia-what-content');
    if(!host)return;
    const index=Math.max(0,Math.min(WHAT_SDIA_STEPS.length-1,Number(stepIndex)||0));
    const [title,body]=WHAT_SDIA_STEPS[index];
    host.innerHTML=`<section class="sdia-what-card"><aside>${icon('shield')}<span>SDIA</span><b>${index+1}/${WHAT_SDIA_STEPS.length}</b></aside><article><span>${escapeHtml(title)}</span><h2 id="sdia-what-type-title"></h2><p id="sdia-what-type-body"></p><div class="sdia-what-progress">${WHAT_SDIA_STEPS.map((_,i)=>`<i class="${i<=index?'is-done':''}"></i>`).join('')}</div><footer><button type="button" data-sdia-what-prev ${index===0?'disabled':''}>← Previous</button><button type="button" data-sdia-what-skip>Show text</button><button type="button" data-sdia-what-next>${index===WHAT_SDIA_STEPS.length-1?'Replay':'Next →'}</button></footer></article></section>`;
    const titleNode=host.querySelector('#sdia-what-type-title');
    const bodyNode=host.querySelector('#sdia-what-type-body');
    const token=++whatIsSdiaPlaybackToken;
    const typeText=async(node,value,speed)=>{if(!node)return;node.textContent='';for(const ch of value){if(token!==whatIsSdiaPlaybackToken||!node.isConnected)return;node.textContent+=ch;await delay(speed);}};
    void (async()=>{await typeText(titleNode,title,22);if(token!==whatIsSdiaPlaybackToken)return;await delay(120);await typeText(bodyNode,body,9);})();
    host.querySelector('[data-sdia-what-skip]')?.addEventListener('click',()=>{whatIsSdiaPlaybackToken+=1;if(titleNode)titleNode.textContent=title;if(bodyNode)bodyNode.textContent=body;});
    host.querySelector('[data-sdia-what-prev]')?.addEventListener('click',()=>renderWhatIsSdia(index-1));
    host.querySelector('[data-sdia-what-next]')?.addEventListener('click',()=>renderWhatIsSdia(index===WHAT_SDIA_STEPS.length-1?0:index+1));
  }

  function dashboardMarkup() {
    return `<section class="sdia-module sdia-hidden" data-sdia-view="dashboard">
      <div class="sdia-module-heading sdia-dashboard-heading"><span>SDIA · GOVERNANCE DASHBOARD</span><h1>Tenant Governance Dashboard</h1><p>Governance observability from real tenant metadata. Compliance is shown only where a rule pack is approved; inventory-only readers are clearly labelled.</p></div>
      <div class="sdia-dashboard-toolbar"><button type="button" id="sdia-dashboard-refresh" class="sdia-primary-action">Refresh Dashboard</button><span id="sdia-dashboard-status">Select Refresh Dashboard to read the tenant.</span></div>
      <div id="sdia-dashboard-content" class="sdia-dashboard-content"><div class="sdia-dashboard-empty">No tenant dashboard data loaded yet.</div></div>
    </section>`;
  }

  function dashboardTaxonomyMatch(item, token) {
    const value = normalizeToken(token);
    if (!item || !value) return false;
    return [item.id, item.canonicalCode, ...(item.aliases || [])].map(normalizeToken).filter(Boolean).includes(value);
  }

  function classifyDashboardPackage(item) {
    const technicalName = String(item?.TechnicalName || '').trim();
    const description = String(item?.ShortText || item?.Description || '').trim();
    const tokens = technicalName.split('.').map(normalizeToken).filter(Boolean);
    const domains = state.catalog.domains || [];
    const domainIndex = tokens.findIndex((token) => domains.some((domain) => dashboardTaxonomyMatch(domain, token)));
    const suffix = tokens[tokens.length - 1] || '';
    if (domainIndex < 0) return { status:'Ungoverned', technicalName, description, domain:'—', finding:'No deterministic Domain boundary.' };
    const domain = domains.find((entry) => dashboardTaxonomyMatch(entry, tokens[domainIndex]));
    const subdomainToken = tokens[domainIndex + 1] || '';
    const subdomain = (domain?.subdomains || []).find((entry) => dashboardTaxonomyMatch(entry, subdomainToken));
    if (!subdomain) return { status:'Review', technicalName, description, domain:(domain?.canonicalCode || domain?.id || '').toUpperCase(), finding:'Domain detected; Subdomain is not governed.' };
    const canonicalDomain = normalizeToken(domain.canonicalCode || domain.id);
    const canonicalSubdomain = normalizeToken(subdomain.canonicalCode || subdomain.id);
    const aliasUsed = tokens[domainIndex] !== canonicalDomain || subdomainToken !== canonicalSubdomain;
    if (suffix === 'i') return { status:'Review', technicalName, description, domain:canonicalDomain.toUpperCase(), finding:'Deprecated .i suffix.' };
    if (suffix !== 'integrations') return { status:'Ungoverned', technicalName, description, domain:canonicalDomain.toUpperCase(), finding:'Package suffix is not .integrations.' };
    if (domainIndex > 2) return { status:'Review', technicalName, description, domain:canonicalDomain.toUpperCase(), finding:'Too many scope segments before Domain.' };
    if (aliasUsed) return { status:'Review', technicalName, description, domain:canonicalDomain.toUpperCase(), finding:'Legacy alias used instead of canonical code.' };
    if (!description) return { status:'Review', technicalName, description, domain:canonicalDomain.toUpperCase(), finding:'Governed name; description is missing.' };
    return { status:'Compliant', technicalName, description, domain:canonicalDomain.toUpperCase(), finding:'Canonical Domain boundary recognized.' };
  }

  function classifySemanticAssetName(name='') {
    const raw=String(name||'').trim();
    const tokens=raw.toLowerCase().split(/[._-]+/).filter(Boolean);
    const domains=state.catalog.domains||[];
    const domainIndex=tokens.findIndex((token)=>domains.some((domain)=>dashboardTaxonomyMatch(domain,token)));
    if(domainIndex<0) return {status:'Ungoverned',finding:'Domain not recognized in semantic identity.'};
    const domain=domains.find((entry)=>dashboardTaxonomyMatch(entry,tokens[domainIndex]));
    const sub=(domain?.subdomains||[]).find((entry)=>dashboardTaxonomyMatch(entry,tokens[domainIndex+1]||''));
    if(!sub) return {status:'Review',finding:'Domain found; governed Subdomain not recognized.'};
    return {status:'Compliant',finding:'Domain and Subdomain recognized.'};
  }

  function lifeCycleCreator(item={}) {
    return String(item?.life_cycle?.created_by || item?.lifeCycle?.createdBy || item?.created_by || item?.CreatedBy || item?.deployedBy || '').trim() || 'Unknown';
  }

  function apimRowsFromInventory(inventory={}) {
    const build=(source,type)=>((source?.results)||[]).map((item)=>{
      const name=String(item?.name || item?.Name || item?.title || item?.key || item?.id || '').trim();
      return { type, name:name || '(unnamed)', createdBy:lifeCycleCreator(item), raw:item, ...classifySemanticAssetName(name) };
    });
    return [
      ...build(inventory.providers,'API Provider'),
      ...build(inventory.keyMapEntries,'KVM'),
      ...build(inventory.certificateStores,'Certificate Store')
    ];
  }

  function donutMarkup(percent, counts = {}, options = {}) {
    const available = options.available !== false;
    const good = Number(options.good ?? counts.compliant ?? 0) || 0;
    const review = Number(options.review ?? counts.review ?? 0) || 0;
    const bad = Number(options.bad ?? counts.ungoverned ?? 0) || 0;
    const total = Math.max(0, good + review + bad);
    const goodPct = total ? (good / total) * 100 : 0;
    const reviewEnd = total ? ((good + review) / total) * 100 : 0;
    const safe = Math.max(0, Math.min(100, Number(percent) || goodPct || 0));
    const centerValue = available ? `${Math.round(safe)}%` : (options.center || 'N/A');
    const centerLabel = options.centerLabel || (available ? 'Compliant' : 'Not mapped');
    const donutClass = available ? '' : ' is-unavailable';
    const legendItems = options.legendItems || (available ? [
      ['is-compliant', good, 'compliant'],
      ['is-review', review, 'review'],
      ['is-ungoverned', bad, 'ungoverned']
    ] : []);
    const legend = available
      ? `<div class="sdia-dashboard-legend">${legendItems.map(([cls,value,label]) => `<span class="${cls}">${escapeHtml(String(value))} ${escapeHtml(label)}</span>`).join('')}</div>`
      : `<div class="sdia-dashboard-legend"><span class="is-neutral">${escapeHtml(options.note || 'Assessment rule or native inventory reader is not mapped yet.')}</span></div>`;
    return `<div class="sdia-dashboard-donut${donutClass}" style="--sdia-good:${available ? goodPct : 0}%;--sdia-review-end:${available ? reviewEnd : 0}%"><div><b>${escapeHtml(centerValue)}</b><span>${escapeHtml(centerLabel)}</span></div></div>${legend}`;
  }

  function summarizeStatuses(rows=[]) {
    return rows.reduce((acc,row)=>{acc.total+=1;if(row.status==='Compliant')acc.compliant+=1;else if(row.status==='Review')acc.review+=1;else acc.ungoverned+=1;return acc;},{total:0,compliant:0,review:0,ungoverned:0});
  }

  function dashboardCreatorRows(packages=[],apimRows=[],securityRows=[]) {
    const creators=new Map();
    const add=(creator,status,type,name,meta={})=>{
      const key=creator||'Unknown';
      const current=creators.get(key)||{name:key,total:0,attention:0,ungoverned:0,review:0,items:[]};
      current.total+=1;
      if(status!=='Compliant'){current.attention+=1;if(status==='Ungoverned')current.ungoverned+=1;else current.review+=1;}
      current.items.push({type,name,status,...meta});
      creators.set(key,current);
    };
    packages.forEach(row=>add(row.createdBy,row.status,'Package',row.technicalName,{finding:row.finding}));
    apimRows.forEach(row=>add(row.createdBy,row.status,row.type,row.name,{finding:row.finding}));
    securityRows.forEach(row=>add(row.deployedBy||'Unknown',row.governance==='Governed'?'Compliant':row.governance==='Review'?'Review':'Ungoverned','Security Material',row.name,{finding:row.finding}));
    return [...creators.values()].sort((a,b)=>b.attention-a.attention||b.total-a.total);
  }

  function creatorTypeDonut(items=[]) {
    const colors=['#2b7de9','#2fa564','#e6a425','#a05fd0'];
    const types=['Package','iFlow','API Management','Security'];
    const counts=[
      items.filter(i=>i.type==='Package').length,
      items.filter(i=>i.type==='iFlow').length,
      items.filter(i=>['API Provider','KVM','Certificate Store'].includes(i.type)).length,
      items.filter(i=>i.type==='Security Material').length
    ];
    const total=Math.max(1,counts.reduce((a,b)=>a+b,0));
    let start=0; const segments=[];
    counts.forEach((count,index)=>{const end=start+(count/total)*100;segments.push(`${colors[index]} ${start}% ${end}%`);start=end;});
    return `<div class="sdia-creator-map-donut" style="background:conic-gradient(${segments.join(',')})"><div><b>${counts.reduce((a,b)=>a+b,0)}</b><span>artefacts</span></div></div><div class="sdia-creator-map-legend">${types.map((type,index)=>`<span style="--dot:${colors[index]}"><i></i>${type}<b>${counts[index]}</b></span>`).join('')}</div>`;
  }

  async function loadCreatorIflows(packages=[]) {
    if (dashboardIflowCache) return dashboardIflowCache;
    const queue=packages.slice(); const rows=[]; const workers=[];
    const worker=async()=>{ while(queue.length){ const pkg=queue.shift(); try { const result=await bridgeRequest('LIST_PACKAGE_ARTIFACTS',{TechnicalName:pkg.technicalName,PackageId:pkg.technicalName},20000); (result.results||[]).forEach(item=>{ const type=String(item?.Type||item?.type||'IFlow'); if(type && !/iflow/i.test(type)) return; const name=String(item?.Name||item?.DisplayName||'').trim(); if(!name)return; rows.push({type:'iFlow',name,createdBy:String(item?.CreatedBy||item?.createdBy||'').trim()||'Unknown',status:'Review',finding:'Inventory loaded; canonical iFlow naming rule pack is pending.',packageName:pkg.technicalName}); }); } catch(_){} } };
    for(let i=0;i<Math.min(5,packages.length);i++) workers.push(worker());
    await Promise.all(workers); dashboardIflowCache=rows; return rows;
  }

  function creatorMapDetailMarkup(creator) {
    if(!creator) return '<div class="sdia-creator-map-empty">Select a creator to inspect artefacts.</div>';
    const groups=new Map();
    creator.items.forEach(item=>{ const key=item.type||'Other'; if(!groups.has(key))groups.set(key,[]); groups.get(key).push(item); });
    const groupRows=[...groups.entries()].map(([type,items])=>({type,items:items.slice(0,8)})).slice(0,6);
    return `<section class="sdia-creator-orgchart"><header><span>CREATOR</span><b>${escapeHtml(creator.name)}</b><small>${creator.attention} attention · ${creator.total} artefacts observed</small></header><div class="sdia-creator-org-root">${icon('contact')}<div><b>${escapeHtml(creator.name)}</b><span>CreatedBy</span></div></div><div class="sdia-creator-org-stem" aria-hidden="true"></div><div class="sdia-creator-org-groups" style="--creator-groups:${Math.max(1,groupRows.length)}">${groupRows.map((group,index)=>`<section class="sdia-creator-org-group" style="--group-delay:${120+index*90}ms"><i class="sdia-creator-org-branch" aria-hidden="true"></i><header><span>${escapeHtml(group.type)}</span><b>${group.items.length}</b></header><div>${group.items.map((item,itemIndex)=>`<article style="--item-delay:${260+index*90+itemIndex*55}ms"><b title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</b><small>${escapeHtml(item.status||'Review')}${item.finding?` · ${escapeHtml(item.finding)}`:''}</small></article>`).join('')}</div></section>`).join('')||'<p>No artefact metadata returned.</p>'}</div></section>`;
  }

  function dashboardScopeLabel(scope) {
    return ({overall:'Overall Governance',package:'Package Naming',iflow:'iFlow Naming',apim:'API Provider Governance',security:'Security Alias Governance',event:'Event Naming',kvm:'KVM Inventory',certificate:'Certificate Store Inventory',creator:'Creator Attention'})[scope] || 'Governance Detail';
  }

  async function dashboardScopeRows(scope) {
    if(!dashboardSnapshot) return [];
    if(scope==='package' || scope==='overall') return dashboardSnapshot.packages.map(row=>({type:'Package',name:row.technicalName,status:row.status,finding:row.finding,owner:row.createdBy}));
    if(scope==='iflow') return (await loadCreatorIflows(dashboardSnapshot.packages)).map(row=>({...row,owner:row.createdBy}));
    if(scope==='apim') return dashboardSnapshot.apimRows.filter(row=>row.type==='API Provider').map(row=>({...row,owner:row.createdBy}));
    if(scope==='security') return dashboardSnapshot.securityRows.map(row=>({type:'Security Material',name:row.name,status:row.governance==='Governed'?'Compliant':row.governance==='Review'?'Review':'Ungoverned',finding:row.finding||row.type||'',owner:row.deployedBy||'Unknown'}));
    if(scope==='kvm') return (dashboardSnapshot.apim?.keyMapEntries?.results||[]).map(row=>({type:'KVM',name:String(row?.name||row?.Name||row?.key||'KVM entry'),status:'Inventory',finding:'Inventory reader mapped; canonical rule pending.',owner:String(row?.life_cycle?.created_by||row?.created_by||'Unknown')}));
    if(scope==='certificate') return (dashboardSnapshot.apim?.certificateStores?.results||[]).map(row=>({type:'Certificate Store',name:String(row?.name||row?.Name||'Certificate Store'),status:'Inventory',finding:'Inventory reader mapped; canonical rule pending.',owner:String(row?.life_cycle?.created_by||row?.created_by||'Unknown')}));
    return [];
  }

  function dashboardDetailTreeMarkup(scope, rows=[]) {
    const label=dashboardScopeLabel(scope);
    const groups=new Map();
    rows.forEach(row=>{ const key=row.type||label; if(!groups.has(key))groups.set(key,[]); groups.get(key).push(row); });
    const groupRows=[...groups.entries()].slice(0,6);
    return `<section class="sdia-dashboard-detail-view"><header><div><span>DASHBOARD DETAIL</span><h2>${escapeHtml(label)}</h2><p>${rows.length} observed artefacts · select another dashboard card after returning.</p></div><button type="button" id="sdia-dashboard-detail-back">← Dashboard</button></header><div class="sdia-dashboard-detail-root"><span>${escapeHtml(label)}</span><b>${rows.length}</b></div><div class="sdia-dashboard-detail-stem" aria-hidden="true"></div><div class="sdia-dashboard-detail-groups">${groupRows.length?groupRows.map((group,index)=>`<section class="sdia-dashboard-detail-group" style="--detail-group:${index}"><i aria-hidden="true"></i><header><span>${escapeHtml(group[0])}</span><b>${group[1].length}</b></header><div>${group[1].slice(0,14).map((row,itemIndex)=>`<article style="--detail-item:${itemIndex}"><b>${escapeHtml(row.name||'Unnamed')}</b><span class="${normalizeToken(row.status||'inventory')}">${escapeHtml(row.status||'Inventory')}</span><small>${escapeHtml(row.finding||'No additional finding.')}${row.owner?` · ${escapeHtml(row.owner)}`:''}</small></article>`).join('')}</div></section>`).join(''):`<div class="sdia-dashboard-detail-empty">No inventory is mapped for ${escapeHtml(label)} yet.</div>`}</div></section>`;
  }

  async function openDashboardScope(scope) {
    const content=state.overlay?.querySelector('#sdia-dashboard-content');
    const status=state.overlay?.querySelector('#sdia-dashboard-status');
    if(!content||!dashboardSnapshot)return;
    if(scope==='creator'){ await openCreatorGovernanceMap(); return; }
    if(status) status.textContent=`Opening ${dashboardScopeLabel(scope)} detail…`;
    const rows=await dashboardScopeRows(scope);
    content.innerHTML=dashboardDetailTreeMarkup(scope,rows);
    content.querySelector('#sdia-dashboard-detail-back')?.addEventListener('click',()=>renderDashboardSnapshot());
    if(status) status.textContent=`${dashboardScopeLabel(scope)} · ${rows.length} observed artefacts.`;
  }

  async function openCreatorGovernanceMap(selectedCreator='') {
    const content=state.overlay?.querySelector('#sdia-dashboard-content'); const status=state.overlay?.querySelector('#sdia-dashboard-status');
    if(!content||!dashboardSnapshot)return;
    status.textContent='Opening Creator Governance Map · loading iFlow creator metadata…';
    const iflows=await loadCreatorIflows(dashboardSnapshot.packages);
    const creatorMap=new Map(dashboardSnapshot.creators.map(c=>[c.name,{...c,items:[...(c.items||[])]}]));
    iflows.forEach(item=>{const key=item.createdBy||'Unknown';const c=creatorMap.get(key)||{name:key,total:0,attention:0,ungoverned:0,review:0,items:[]};c.total+=1;c.review+=1;c.attention+=1;c.items.push(item);creatorMap.set(key,c);});
    const creators=[...creatorMap.values()].sort((a,b)=>b.attention-a.attention||b.total-a.total);
    const selected=creators.find(c=>c.name===selectedCreator)||creators[0];
    const allItems=creators.flatMap(c=>c.items||[]);
    content.innerHTML=`<section class="sdia-creator-governance-map"><header><div><span>CREATOR GOVERNANCE MAP</span><h2>Who created what — and where governance needs attention</h2><p>Ownership signal only. This is not a developer quality score.</p></div><button type="button" id="sdia-creator-map-close">← Dashboard</button></header><div class="sdia-creator-map-overview"><div class="sdia-creator-map-summary">${creatorTypeDonut(allItems)}</div><div class="sdia-creator-map-creators">${creators.slice(0,8).map((creator,index)=>`<button type="button" data-sdia-creator="${escapeHtml(creator.name)}" class="${creator.name===selected?.name?'is-active':''}" style="--creator-delay:${index*70}ms"><span>${index+1}</span><b>${escapeHtml(creator.name)}</b><small>${creator.attention} attention · ${creator.total} observed</small></button>`).join('')}</div></div><div id="sdia-creator-map-detail">${creatorMapDetailMarkup(selected)}</div></section>`;
    content.querySelector('#sdia-creator-map-close')?.addEventListener('click',()=>renderDashboardSnapshot());
    content.querySelectorAll('[data-sdia-creator]').forEach(button=>button.addEventListener('click',()=>{content.querySelectorAll('[data-sdia-creator]').forEach(x=>x.classList.toggle('is-active',x===button));const creator=creators.find(c=>c.name===button.dataset.sdiaCreator);const detail=content.querySelector('#sdia-creator-map-detail');if(detail)detail.innerHTML=creatorMapDetailMarkup(creator);}));
    status.textContent=`Creator Governance Map · ${creators.length} creators · ${iflows.length} iFlows loaded.`;
  }

  function renderDashboardSnapshot() {
    const content=state.overlay?.querySelector('#sdia-dashboard-content');
    if(!content||!dashboardSnapshot)return;
    const {packages:rows,counts,compliantPercent,creatorRows,domainRows,issueRows,creatorCleanPercent,cleanCreators,creatorsWithIssues,creatorTotal,apim,apimRows,securityRows}=dashboardSnapshot;
    const apimProviderRows=apimRows.filter(row=>row.type==='API Provider');
    const apimCounts=summarizeStatuses(apimProviderRows);
    const providerPercent=apimCounts.total?(apimCounts.compliant/apimCounts.total)*100:0;
    const securityCounts=summarizeStatuses(securityRows.map(row=>({status:row.governance==='Governed'?'Compliant':row.governance==='Review'?'Review':'Ungoverned'})));
    const securityPercent=securityCounts.total?(securityCounts.compliant/securityCounts.total)*100:0;
    content.innerHTML=`<div class="sdia-dashboard-kpis"><article><span>Total Packages</span><b>${counts.total}</b></article><article class="is-good"><span>Compliant</span><b>${counts.compliant}</b></article><article class="is-review"><span>Needs Review</span><b>${counts.review}</b></article><article class="is-bad"><span>Ungoverned</span><b>${counts.ungoverned}</b></article></div>
      <div class="sdia-dashboard-donut-grid">
        <article class="sdia-dashboard-panel sdia-dashboard-donut-card is-clickable" data-sdia-dashboard-scope="overall" tabindex="0"><header><span>OVERALL</span><b>Approved Governance Score</b><small>Approved Package assessment only.</small></header>${donutMarkup(compliantPercent,counts)}</article>
        <article class="sdia-dashboard-panel sdia-dashboard-donut-card is-clickable" data-sdia-dashboard-scope="package" tabindex="0"><header><span>PACKAGE NAME</span><b>ODCP Package Naming</b></header>${donutMarkup(compliantPercent,counts)}</article>
        <article class="sdia-dashboard-panel sdia-dashboard-donut-card is-clickable" data-sdia-dashboard-scope="iflow" tabindex="0"><header><span>IFLOW NAME</span><b>iFlow Naming</b><small>Inventory can be inspected in Creator Map; rule pack remains pending.</small></header>${donutMarkup(0,{}, {available:false, center:'N/A', centerLabel:'Rule pending', note:'No iFlow compliance percentage is fabricated.'})}</article>
        <article class="sdia-dashboard-panel sdia-dashboard-donut-card is-clickable" data-sdia-dashboard-scope="apim" tabindex="0"><header><span>API PROVIDER</span><b>APIM Semantic Naming Signal</b><small>${apimProviderRows.length} providers read from Management.svc.</small></header>${apimProviderRows.length?donutMarkup(providerPercent,apimCounts):donutMarkup(0,{}, {available:false,center:'N/A',centerLabel:'No data',note:apim?.providers?.error||'No API Provider inventory returned.'})}</article>
        <article class="sdia-dashboard-panel sdia-dashboard-donut-card is-clickable" data-sdia-dashboard-scope="security" tabindex="0"><header><span>SECURITY</span><b>Security Alias Governance</b><small>Uses metadata captured from the native Security workspace in this tab.</small></header>${securityRows.length?donutMarkup(securityPercent,securityCounts):donutMarkup(0,{}, {available:false,center:'N/A',centerLabel:'Open Security',note:'Open Security Materials/Keystore and refresh once to cache metadata.'})}</article>
        <article class="sdia-dashboard-panel sdia-dashboard-donut-card is-clickable" data-sdia-dashboard-scope="event" tabindex="0"><header><span>EVENT NAME</span><b>EDCP Queue / Topic Naming</b></header>${donutMarkup(0,{}, {available:false, center:'N/A', centerLabel:'Reader pending', note:'Event inventory reader is not mapped yet.'})}</article>
        <article class="sdia-dashboard-panel sdia-dashboard-donut-card is-clickable" data-sdia-dashboard-scope="kvm" tabindex="0"><header><span>KVM</span><b>APIM KeyMapEntries</b><small>${apim?.keyMapEntries?.results?.length||0} entries observed.</small></header>${donutMarkup(0,{}, {available:false,center:String(apim?.keyMapEntries?.results?.length||0),centerLabel:'Inventory',note:'Reader mapped; canonical KVM naming rule is still pending.'})}</article>
        <article class="sdia-dashboard-panel sdia-dashboard-donut-card is-clickable" data-sdia-dashboard-scope="certificate" tabindex="0"><header><span>CERTIFICATE STORE</span><b>APIM Certificate Stores</b><small>${apim?.certificateStores?.results?.length||0} stores observed.</small></header>${donutMarkup(0,{}, {available:false,center:String(apim?.certificateStores?.results?.length||0),centerLabel:'Inventory',note:'Reader mapped; certificate-store naming rule is still pending.'})}</article>
        <article class="sdia-dashboard-panel sdia-dashboard-donut-card is-clickable" data-sdia-dashboard-scope="creator" tabindex="0"><header><span>CREATOR ATTENTION</span><b>Creators without detected issues</b><small>Ownership signal only.</small></header>${donutMarkup(creatorCleanPercent,{}, {good:cleanCreators, review:creatorsWithIssues, bad:0, centerLabel:'Clean', legendItems:[['is-compliant',cleanCreators,'without issues'],['is-review',creatorsWithIssues,'with issues'],['is-neutral',creatorTotal,'creators']]})}</article>
      </div>
      <div class="sdia-dashboard-grid">
        <article class="sdia-dashboard-panel"><header><span>DOMAIN COVERAGE</span><b>Packages by governed Domain</b></header><div class="sdia-dashboard-bars">${domainRows.length?domainRows.map(([name,value])=>`<div><span>${escapeHtml(name)}</span><i><em style="width:${Math.max(8,(value/Math.max(1,domainRows[0][1]))*100)}%"></em></i><b>${value}</b></div>`).join(''):'<p>No governed Domain detected.</p>'}</div></article>
        <article class="sdia-dashboard-panel"><header><span>CREATORS WITH ATTENTION</span><b>Inspect ownership and artefact cascade</b><small>Click a creator or open the full map.</small></header><div class="sdia-dashboard-creators">${creatorRows.length?creatorRows.slice(0,5).map((row,index)=>`<button type="button" data-sdia-dashboard-creator="${escapeHtml(row.name)}"><span>${index+1}</span><b>${escapeHtml(row.name)}</b><i>${row.attention} attention</i><small>${row.ungoverned} ungoverned · ${row.review} review · ${row.total} observed</small></button>`).join(''):'<p>No creator metadata returned.</p>'}</div><button type="button" id="sdia-open-creator-map" class="sdia-dashboard-map-action">Open Creator Governance Map →</button></article>
        <article class="sdia-dashboard-panel sdia-dashboard-wide"><header><span>TOP GOVERNANCE ISSUES</span><b>Current non-compliant Package examples</b></header><div class="sdia-dashboard-issues">${issueRows.length?issueRows.map(row=>`<div><span class="${normalizeToken(row.status)}">${escapeHtml(row.status)}</span><b>${escapeHtml(row.technicalName)}</b><small>${escapeHtml(row.finding)}</small></div>`).join(''):'<p>✓ No Package governance issues detected.</p>'}</div></article>
      </div>`;
    content.querySelector('#sdia-open-creator-map')?.addEventListener('click',()=>void openCreatorGovernanceMap());
    content.querySelectorAll('[data-sdia-dashboard-creator]').forEach(button=>button.addEventListener('click',()=>void openCreatorGovernanceMap(button.dataset.sdiaDashboardCreator||'')));
    content.querySelectorAll('[data-sdia-dashboard-scope]').forEach(card=>{
      const open=()=>void openDashboardScope(card.dataset.sdiaDashboardScope||'overall');
      card.addEventListener('click',open);
      card.addEventListener('keydown',(event)=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();open();}});
    });
  }

  async function loadDashboard() {
    const content = state.overlay?.querySelector('#sdia-dashboard-content');
    const status = state.overlay?.querySelector('#sdia-dashboard-status');
    const refresh = state.overlay?.querySelector('#sdia-dashboard-refresh');
    if (!content || !status || !refresh) return;
    refresh.disabled=true; refresh.textContent='Reading Tenant…'; status.textContent='Reading Cloud Integration and APIM inventories…';
    try {
      const [packageResult,apimResult]=await Promise.all([
        bridgeRequest('LIST_PACKAGES',{},30000),
        bridgeRequest('LIST_APIM_INVENTORY',{},30000).catch((error)=>({providers:{results:[],error:error.message},certificateStores:{results:[],error:error.message},keyMapEntries:{results:[],error:error.message}}))
      ]);
      const rows=(packageResult.results||[]).filter(item=>String(item?.TechnicalName||'').trim()).map(item=>({...classifyDashboardPackage(item),createdBy:String(item?.CreatedBy||item?.createdBy||'').trim()||'Unknown',displayName:String(item?.DisplayName||item?.Name||item?.TechnicalName||'').trim()}));
      const counts=summarizeStatuses(rows); const compliantPercent=counts.total?(counts.compliant/counts.total)*100:0;
      const apimRows=apimRowsFromInventory(apimResult); const securityRows=Array.isArray(state.securityInventory)?state.securityInventory:[];
      const creators=dashboardCreatorRows(rows,apimRows,securityRows); const creatorRows=creators.slice(0,8);
      const domains=new Map(); rows.filter(row=>row.domain&&row.domain!=='—').forEach(row=>domains.set(row.domain,(domains.get(row.domain)||0)+1));
      const domainRows=[...domains.entries()].sort((a,b)=>b[1]-a[1]).slice(0,8); const issueRows=rows.filter(row=>row.status!=='Compliant').slice(0,10);
      const creatorsWithIssues=creators.filter(row=>row.attention>0).length, cleanCreators=creators.filter(row=>row.attention===0).length, creatorTotal=creators.length;
      const creatorCleanPercent=creatorTotal?(cleanCreators/creatorTotal)*100:0;
      dashboardSnapshot={packages:rows,counts,compliantPercent,creatorRows,creators,domainRows,issueRows,creatorCleanPercent,cleanCreators,creatorsWithIssues,creatorTotal,apim:apimResult,apimRows,securityRows};
      dashboardIflowCache=null; renderDashboardSnapshot();
      status.textContent=`Dashboard refreshed · ${counts.total} Packages · ${apimResult?.providers?.results?.length||0} API Providers · ${apimResult?.keyMapEntries?.results?.length||0} KVM entries.`;
    } catch(error) {
      content.innerHTML=`<div class="sdia-dashboard-empty">${escapeHtml(error.message)}</div>`; status.textContent=`Dashboard failed · ${error.message}`;
    } finally {refresh.disabled=false;refresh.textContent='Refresh Dashboard';}
  }

  function toggleControlNavigation() {
    const center = state.overlay?.querySelector('.sdia-control-center');
    if (!center) return;
    const collapsed = center.classList.toggle('sdia-nav-collapsed');
    const toggle = center.querySelector('.sdia-cc-nav-toggle');
    toggle?.setAttribute('aria-label', collapsed ? 'Expand navigation' : 'Collapse navigation');
    try { sessionStorage.setItem(NAV_COLLAPSE_KEY, collapsed ? '1' : '0'); } catch (_) {}
  }


  async function navigateHomeExecution(button) {
    if (!(button instanceof HTMLButtonElement) || button.disabled) return;
    const route = button.dataset.sdiaHomeRoute || '';
    const targetProduct = button.dataset.sdiaHomeProduct || '';
    const actionId = button.dataset.sdiaNavigationAction || '';
    if (!route) return;

    const peers = [...(button.closest('.sdia-home-entry-grid')?.querySelectorAll('[data-sdia-home-route]') || [])];
    const small = button.querySelector('small');
    const originalSmall = small?.textContent || '';
    peers.forEach((item) => { item.disabled = true; });
    button.classList.add('is-opening');
    button.setAttribute('aria-busy', 'true');

    const fallbackProgress = (phase) => {
      if (!small) return;
      if (phase === 'locating-native-route') small.textContent = 'Locating native SAP navigation…';
      else if (phase === 'opening-native-route') small.textContent = 'Loading SAP context behind SDIA…';
      else small.textContent = 'Opening in background…';
    };

    let splash = null;
    if (state.settings.transitionSplashEnabled !== false && actionId) {
      splash = SDIA.NavigationExperience?.open?.(actionId, {
        onDismiss: () => fallbackProgress('opening-native-route')
      }) || null;
    }
    if (!splash) fallbackProgress('');

    try {
      await bridgeRequest('NAVIGATE_EXECUTION_CONTEXT', { route, targetProduct }, 30000, (progress) => {
        splash?.setProgress?.(progress.phase, progress.detail || '');
        if (!splash || splash.dismissed) fallbackProgress(progress.phase);
      });

      if (splash) {
        splash.complete();
        await delay(420);
        if (!splash.dismissed) {
          splash.close();
          closeControlCenter();
          return;
        }
        // User deliberately dismissed the splash: keep the SDIA form in front.
        // The SAP context is already ready behind it and can be revealed by
        // closing the Control Center whenever the user chooses.
        peers.forEach((item) => { item.disabled = false; });
        button.classList.remove('is-opening');
        button.removeAttribute('aria-busy');
        if (small) small.textContent = originalSmall;
        showToast('SAP context is ready behind SDIA · close the Control Center when you want to continue.', 6200);
        return;
      }

      // Legacy navigation experience: keep the validated background-loading
      // flow unchanged when contextual splashes are disabled in Settings.
      closeControlCenter();
    } catch (error) {
      splash?.fail?.(error.message || 'SAP context could not be opened.');
      if (splash && !splash.dismissed) {
        await delay(700);
        splash.close();
      }
      showToast(`SAP context could not be opened · ${error.message}`, 7600);
      peers.forEach((item) => { item.disabled = false; });
      button.classList.remove('is-opening');
      button.removeAttribute('aria-busy');
      if (small) small.textContent = originalSmall;
    }
  }

  function renderHomeHub() {
    if (!state.overlay) return;
    const host = state.overlay.querySelector('#sdia-home-hub-content');
    if (!host) return;
    const orientationComplete = Boolean(SDIA.Orientation?.isCompleted?.());
    host.innerHTML = SDIA.HomeUI.markup({ orientationComplete });
    SDIA.HomeUI.init?.(host);
    host.querySelectorAll('[data-sdia-home-module]').forEach((button) => button.addEventListener('click', () => switchModule(button.dataset.sdiaHomeModule)));
    host.querySelectorAll('[data-sdia-home-route]').forEach((button) => button.addEventListener('click', () => {
      void navigateHomeExecution(button);
    }));
  }

  function assessmentMarkup() {
    return `
      <section class="sdia-module sdia-hidden" data-sdia-view="assessment">
        <div class="sdia-module-heading"><span id="sdia-assessment-eyebrow">TENANT ASSESSMENT</span><h1 id="sdia-assessment-title">Package Governance Assessment</h1><p id="sdia-assessment-description">Read the current package inventory and evaluate it against the loaded Domain Catalog.</p></div>
        <div class="sdia-assessment-toolbar sdia-assessment-toolbar-centered">
          <button id="sdia-run-assessment" class="sdia-primary-action" type="button">Run Package Assessment</button>
          <span id="sdia-assessment-status">No assessment executed.</span>
        </div>
        <div id="sdia-assessment-summary" class="sdia-summary-grid sdia-assessment-summary-compact sdia-hidden"></div>
        <div id="sdia-assessment-table-wrap" class="sdia-table-wrap">
          <table class="sdia-assessment-table">
            <thead><tr><th>Package</th><th>Detected scope</th><th>Status</th><th>Finding</th></tr></thead>
            <tbody id="sdia-assessment-body"><tr><td colspan="4" class="sdia-empty-row">Run the assessment to establish a baseline.</td></tr></tbody>
          </table>
        </div>
      </section>`;
  }

  function settingsMarkup() {
    const toggle = (id, title, text) => `<label class="sdia-setting-toggle"><input id="${id}" type="checkbox"><span class="sdia-setting-toggle-control" aria-hidden="true"><i></i></span><span><b>${title}</b><small>${text}</small></span></label>`;
    const appearanceCard = (theme, title, text) => `<button type="button" class="sdia-appearance-card" data-sdia-appearance="${theme}" role="radio" aria-checked="false"><i class="sdia-appearance-preview" aria-hidden="true"><u></u><u></u><u></u></i><span><b>${title}</b><small>${text}</small></span></button>`;
    const visualSwatches = SDIA.VisualExperience.THEMES.map((theme) => `<button type="button" class="sdia-visual-swatch sdia-visual-swatch-shield" data-sdia-visual-theme="${theme.id}" style="--sdia-swatch:${theme.swatch}" title="${theme.label}" aria-label="Use ${theme.label}"><i aria-hidden="true">${icon('shield')}</i><small>${theme.label}</small></button>`).join('');
    return `
      <section class="sdia-module sdia-hidden" data-sdia-view="settings">
        <div class="sdia-module-heading"><span>SETTINGS</span><h1 id="sdia-settings-title">Governance Settings</h1><p id="sdia-settings-description">Operational preferences remain local to this browser profile.</p></div>
        <div class="sdia-settings-shell">
          <div class="sdia-settings-panel">
            <details class="sdia-settings-accordion" open>
              <summary><span>Theme Mode</span><b>Control Center appearance</b><i aria-hidden="true">⌄</i></summary>
              <div class="sdia-settings-accordion-body">
                <div class="sdia-appearance-grid" role="radiogroup" aria-label="Appearance theme">
                  ${appearanceCard('white','White','Clean neutral light')}
                  ${appearanceCard('blue','Light Blue','Cool light surfaces')}
                  ${appearanceCard('cream','Cream','Warm ivory surfaces')}
                </div>
              </div>
            </details>

            <details class="sdia-settings-accordion" open>
              <summary><span>Visual Experience</span><b>Control Plane color rotation</b><i aria-hidden="true">⌄</i></summary>
              <div class="sdia-settings-accordion-body">
                <div class="sdia-visual-experience-panel sdia-visual-experience-panel-refined">
                  <div class="sdia-visual-experience-head"><div><b>Automatic rotation</b><small>Manual selection locks the chosen color until automatic rotation is re-enabled.</small></div><button id="sdia-visual-auto" class="sdia-visual-auto-button" type="button">Automatic · 20 openings</button></div>
                  <div class="sdia-visual-palette sdia-visual-palette-shield" role="radiogroup" aria-label="Control Plane color palette">${visualSwatches}</div>
                  <div id="sdia-visual-rotation-status" class="sdia-visual-rotation-status"><i></i><span>Automatic rotation active.</span></div>
                </div>
              </div>
            </details>

            <details class="sdia-settings-accordion" open>
              <summary><span>Default Package Metadata</span><b>Initialize governed Package forms</b><i aria-hidden="true">⌄</i></summary>
              <div class="sdia-settings-accordion-body">
                <div class="sdia-settings-fields">
                  <label><span>Default Company Code</span><input id="sdia-setting-company" type="text" maxlength="8" placeholder="e.g. acme"></label>
                  <label><span>Default Division Code</span><input id="sdia-setting-division" type="text" maxlength="12" placeholder="e.g. br"></label>
                  <label><span>Default Vendor</span><input id="sdia-setting-vendor" type="text" placeholder="Optional"></label>
                </div>
              </div>
            </details>

            <details class="sdia-settings-accordion">
              <summary><span>Apply Defaults</span><b>Choose what is auto-populated</b><i aria-hidden="true">⌄</i></summary>
              <div class="sdia-settings-accordion-body">
                <div class="sdia-settings-toggle-grid">
                  ${toggle('sdia-setting-company-enabled','Enable Company by default','Preselect the Company scope when opening Package Builder.')}
                  ${toggle('sdia-setting-division-enabled','Enable Division by default','Preselect the Division scope when opening Package Builder.')}
                  ${toggle('sdia-setting-vendor-enabled','Use Default Vendor automatically','Populate Vendor with the saved default value.')}
                </div>
              </div>
            </details>

            <details class="sdia-settings-accordion">
              <summary><span>Session & Behavior</span><b>Governance workspace experience</b><i aria-hidden="true">⌄</i></summary>
              <div class="sdia-settings-accordion-body">
                <div class="sdia-settings-toggle-grid">
                  ${toggle('sdia-setting-preserve-draft','Preserve draft during current session','Keep typed form values when the Control Center is closed accidentally.')}
                  ${toggle('sdia-setting-start-overview','Start new context in Overview','A newly visited Package, APIM or Event Mesh context begins with its executive Overview.')}
                  ${toggle('sdia-setting-restore-workspace','Restore last workspace in current session','Return to the last SDIA workspace when reopening the same context.')}
                  ${toggle('sdia-setting-transition-splash','Contextual transition splash','Show the governed action splash while SAP loads behind SDIA. Disable it to keep background loading.')}
                  ${toggle('sdia-setting-guidance-hints','Show guidance hints in Package Builder','Keep semantic helper text visible while preparing a Package boundary.')}
                </div>
              </div>
            </details>

            <details class="sdia-settings-accordion">
              <summary><span>Maintenance</span><b>Clear temporary local state</b><i aria-hidden="true">⌄</i></summary>
              <div class="sdia-settings-accordion-body">
                <div class="sdia-settings-maintenance-actions"><button id="sdia-reset-session" type="button">Reset Session State</button><button id="sdia-reset-preferences" type="button">Reset Preference Defaults</button></div>
              </div>
            </details>

            <div class="sdia-settings-save-row"><button id="sdia-save-settings" class="sdia-primary-action sdia-settings-save" type="button"><span>Save Settings</span><i aria-hidden="true">✓</i></button></div>
          </div>

          <aside class="sdia-settings-visual-panel" aria-hidden="true">
            <div class="sdia-settings-visual-orb"><span>${icon('settings')}</span></div>
            <div class="sdia-settings-visual-copy"><b>Local browser control center</b><strong>Settings shape the SDIA experience without touching SAP tenant content.</strong><p>Theme, color rotation, default metadata, session behavior and maintenance remain local to this browser profile.</p><ul><li>Theme and visual rotation</li><li>Default Package metadata</li><li>Session and splash behavior</li><li>Safe local reset controls</li></ul></div>
          </aside>
        </div>
      </section>`;
  }

  function applyAppearanceTheme() {
    const theme = ['white','blue','cream'].includes(state.settings.appearance) ? state.settings.appearance : 'white';
    if (state.overlay) state.overlay.dataset.sdiaTheme = theme;
    // Also on the document root so body-level SDIA overlays (governance map
    // expand, compliance advisory, toast) resolve the same themed tokens.
    document.documentElement.dataset.sdiaTheme = theme;
  }

  function visualScopeForModule(module, profile = activeProductProfile()) {
    if (module === 'home-hub') return 'home';
    if (module === 'overview') return overviewVisualScope(profile);
    if (module === 'packages') return 'package';
    if (module === 'package-workspace') return 'artifacts';
    if (module === 'apim') return 'apim';
    if (module === 'eventmesh') return 'eventmesh';
    if (module === 'security') return integrationSuiteContext().routeType === 'keystore' ? 'certificate' : 'credentials';
    if (module === 'capability-action') return capabilityVisualScope(profile);
    return '';
  }

  function switchModule(module, options = {}) {
    if (!state.overlay) return;
    const routeProfile = activeProductProfile();
    const requestedProfile = usesControlPlaneHomeMenu(module) ? SDIA.RouteContext.PRODUCT_PROFILES.home : routeProfile;
    const allowed = allowedModulesForProduct(requestedProfile);
    if (module === 'overview' && requestedProfile.id === 'home' && allowed.includes('home-hub')) module = 'home-hub';
    if (SDIA.Orientation?.requiresCompletion?.(module) && !SDIA.Orientation?.isCompleted?.()) {
      showToast('Complete “How to use SDIA” from Home to activate operational governance capabilities.', 5200);
      module = requestedProfile.id === 'home' && allowed.includes('how-to') ? 'how-to' : 'overview';
    }
    if (!allowed.includes(module)) module = requestedProfile.id === 'home' ? 'home-hub' : defaultModuleForRoute();
    if (!allowed.includes(module)) module = allowed[0] || 'overview';
    const profile = usesControlPlaneHomeMenu(module) ? SDIA.RouteContext.PRODUCT_PROFILES.home : routeProfile;
    const previousModule = state.activeModule;
    const previousAllowed = new Set([...allowedModulesForProduct(routeProfile), ...allowedModulesForProduct(SDIA.RouteContext.PRODUCT_PROFILES.home)]);
    if (options.push !== false && previousModule && previousModule !== module && previousAllowed.has(previousModule)) { state.internalHistory.push(previousModule); if (state.internalHistory.length > 14) state.internalHistory.shift(); }
    state.activeModule = module;
    // Cancel async UI playback of the module being left: the What-is-SDIA
    // typewriter and the Orientation scenario typing must not keep writing into
    // hidden (or soon detached) nodes after a module switch.
    if (previousModule !== module) {
      if (previousModule === 'what-is-sdia') whatIsSdiaPlaybackToken += 1;
      if (previousModule === 'how-to') SDIA.Orientation?.suspendPlayback?.();
      if (previousModule === 'information') SDIA.InformationUI?.suspendPlayback?.();
    }
    applyProductContext();
    const center = state.overlay.querySelector('.sdia-control-center');
    if (center) {
      center.classList.toggle('sdia-overview-context', module === 'overview' || module === 'home-hub');
      center.classList.toggle('sdia-home-hub-context', module === 'home-hub');
    }
    state.overlay.querySelectorAll('.sdia-module').forEach((view) => view.classList.toggle('sdia-hidden', view.dataset.sdiaView !== module));
    state.overlay.querySelectorAll('.sdia-cc-nav [data-sdia-module]').forEach((button) => {
      const associated = module === 'capability-action' ? (state.capabilityReturnModule || profile.primaryModule) : module;
      button.classList.toggle('active', button.dataset.sdiaModule === associated);
    });
    if (module === 'home-hub') renderHomeHub();
    if (module === 'dashboard') void loadDashboard();
    if (module === 'what-is-sdia') renderWhatIsSdia(0);
    if (module === 'how-to') SDIA.Orientation.render();
    if (module === 'catalog') SDIA.CatalogUI.render();
    if (module === 'domain-help') SDIA.GuidanceUI.render();
    if (module === 'information') SDIA.InformationUI.init?.(state.overlay.querySelector('[data-sdia-view="information"]'));
    if (module === 'security') SDIA.Security.onOpen();
    if (module === 'package-map' && !(state.packageMapRows || []).length) void SDIA.CloudIntegration.Package.loadPackageGovernanceMap();
    if (module === 'overview') { renderOverviewContext(profile); const flow = state.overlay.querySelector('.sdia-overview-architecture-flow'); if (flow) { flow.classList.remove('sdia-overview-arch-run'); void flow.offsetWidth; flow.classList.add('sdia-overview-arch-run'); } }
    const visualScope = visualScopeForModule(module, profile);
    if (visualScope) void SDIA.VisualExperience.activate(visualScope, state.overlay);
    refreshContextPanel(); updateWorkspaceChrome(); if (!options.silentPersist) persistControlCenterState('module-switch');
  }

  function handleWorkspaceAction(action, event=null) {
    const profile = activeProductProfile();
    if (action === 'back-internal') { backInternal(); return; }
    if (action === 'control-plane-home') { if (state.activeModule !== 'home-hub') switchModule('home-hub', { push:true }); return; }
    if (action === 'toggle-nav') { toggleControlNavigation(); return; }
    if (action === 'back-capability') { switchModule(state.capabilityReturnModule || profile.primaryModule); return; }
    if (SDIA.CloudIntegration.Package.handleAction(action, event)) return;
    if (SDIA.CloudIntegration.Iflow.handleAction(action, event)) return;
    if (SDIA.ApiManagement.handleAction(action, event)) return;
    if (SDIA.EventMesh.handleAction(action, event)) return;
    SDIA.Security.handleAction(action, event);
  }

  function capabilityVisualScope(profile = activeProductProfile()) {
    if (profile.id === 'ci') return state.activeArtefactType === 'integration-flow' ? 'iflow' : 'artifacts';
    if (profile.id === 'apim') return 'apim';
    if (profile.id === 'eventmesh') return 'eventmesh';
    if (profile.id === 'security') return integrationSuiteContext().routeType === 'keystore' ? 'certificate' : 'credentials';
    return '';
  }

  function openCapabilityAction(title, inputs, note) {
    const profile = activeProductProfile(); state.capabilityReturnModule = profile.primaryModule;
    state.overlay.querySelector('#sdia-capability-action-code').textContent = `${profile.modelCode} · ${profile.capability.toUpperCase()}`;
    state.overlay.querySelector('#sdia-capability-action-eyebrow').textContent = 'SDIA GOVERNANCE MODEL';
    state.overlay.querySelector('#sdia-capability-action-title').textContent = title;
    state.overlay.querySelector('#sdia-capability-action-description').textContent = `Define and validate the semantic boundary for ${title.toLowerCase()}.`;
    state.overlay.querySelector('#sdia-capability-action-product').textContent = profile.capability;
    state.overlay.querySelector('#sdia-capability-action-model').textContent = `${profile.modelCode} — ${profile.modelName}`;
    state.overlay.querySelector('#sdia-capability-action-inputs').textContent = inputs;
    state.overlay.querySelector('#sdia-capability-action-note').textContent = note;
    const visualHost = state.overlay.querySelector('#sdia-capability-action-visual');
    const visualScope = capabilityVisualScope(profile);
    if (visualHost) visualHost.innerHTML = visualScope ? SDIA.ControlPlaneVisual.markupForScope(visualScope) : '';
    switchModule('capability-action');
  }
  function applyProductContext() {
    if (!state.launcher) return;
    const profile = activeProductProfile();
    if (!state.overlay) return;
    const center = state.overlay.querySelector('.sdia-control-center');
    if (center) center.dataset.sdiaProduct = profile.id;

    const homeNavigation = usesControlPlaneHomeMenu(state.activeModule);
    const navProfile = homeNavigation ? SDIA.RouteContext.PRODUCT_PROFILES.home : profile;
    const navigationAllowed = allowedModulesForProduct(navProfile);
    const overviewNav = state.overlay.querySelector('.sdia-cc-nav [data-sdia-module="overview"] span');
    if (overviewNav) overviewNav.textContent = 'Overview';
    state.overlay.querySelectorAll('.sdia-cc-nav [data-sdia-products]').forEach((button) => {
      const products = button.dataset.sdiaProducts || 'all';
      const productVisible = products === 'all' || products.split(',').includes(navProfile.id);
      const moduleVisible = navigationAllowed.includes(button.dataset.sdiaModule);
      button.classList.toggle('sdia-nav-context-hidden', !(productVisible && moduleVisible));
      const orientationLocked = Boolean(productVisible && moduleVisible && SDIA.Orientation?.requiresCompletion?.(button.dataset.sdiaModule) && !SDIA.Orientation?.isCompleted?.());
      button.classList.toggle('sdia-nav-locked', orientationLocked);
      if (orientationLocked) button.title = 'Complete “How to use SDIA” from Home to activate this governance capability.';
      else button.removeAttribute('title');
    });

    if (profile.id !== 'home') renderOverviewContext(profile);
    state.overlay.querySelector('.sdia-control-center')?.classList.toggle('sdia-hide-guidance-hints', state.settings.showGuidanceHints === false);

    const assessmentButton = state.overlay.querySelector('#sdia-run-assessment');
    const assessmentTable = state.overlay.querySelector('#sdia-assessment-table-wrap');
    const assessmentSummary = state.overlay.querySelector('#sdia-assessment-summary');
    if (profile.id === 'ci') {
      state.overlay.querySelector('#sdia-assessment-eyebrow').textContent = 'ODCP · TENANT ASSESSMENT';
      state.overlay.querySelector('#sdia-assessment-title').textContent = 'Package Governance Assessment';
      state.overlay.querySelector('#sdia-assessment-description').textContent = 'Read the current package inventory and evaluate it against the loaded Domain Catalog.';
      assessmentButton.disabled = false;
      assessmentButton.textContent = 'Run Package Assessment';
      assessmentTable.classList.remove('sdia-hidden');
      if (state.lastAssessment) assessmentSummary.classList.remove('sdia-hidden');
    } else {
      state.overlay.querySelector('#sdia-assessment-eyebrow').textContent = `${profile.modelCode} · CAPABILITY ASSESSMENT`;
      state.overlay.querySelector('#sdia-assessment-title').textContent = `${profile.capability} Governance Assessment`;
      state.overlay.querySelector('#sdia-assessment-description').textContent = `The route is detected. Inventory extraction for ${profile.capability} will be connected after its native APIs and rule-pack grammar are validated.`;
      assessmentButton.disabled = true;
      assessmentButton.textContent = `${profile.modelCode} assessment adapter — next phase`;
      state.overlay.querySelector('#sdia-assessment-status').textContent = 'Route detection active · provisioning and inventory adapter not connected.';
      assessmentTable.classList.add('sdia-hidden');
      assessmentSummary.classList.add('sdia-hidden');
    }

    state.overlay.querySelector('#sdia-settings-title').textContent = `${profile.modelCode} Governance Settings`;
    state.overlay.querySelector('#sdia-settings-description').textContent = `Operational preferences remain local to this browser profile. SAP tenant data is never changed from Settings.`;
  }
  function refreshContextPanel() {
    if (!state.overlay) return;
    const suiteContext = integrationSuiteContext();
    const routeProfile = suiteContext.profile;
    const profile = usesControlPlaneHomeMenu(state.activeModule) ? SDIA.RouteContext.PRODUCT_PROFILES.home : routeProfile;
    const ciContext = designContext();
    const activePackageName = state.overlay.querySelector('#sdia-active-package-name');
    if (activePackageName) activePackageName.textContent = ciContext.type === 'contentpackage' ? ciContext.packageId : '—';
    const pill = state.overlay.querySelector('#sdia-cc-status-pill');
    if (pill) {
      pill.innerHTML = `${icon(profile.badgeIcon || 'shield')}<span>${escapeHtml(profile.status)}</span>`;
      pill.classList.toggle('warning', profile.id === 'unknown');
    }
    updateAssessmentContext();
  }
  function bindSettings() {
    const fields = {
      company: state.overlay.querySelector('#sdia-setting-company'), division: state.overlay.querySelector('#sdia-setting-division'), vendor: state.overlay.querySelector('#sdia-setting-vendor'),
      companyEnabled: state.overlay.querySelector('#sdia-setting-company-enabled'), divisionEnabled: state.overlay.querySelector('#sdia-setting-division-enabled'), vendorEnabled: state.overlay.querySelector('#sdia-setting-vendor-enabled'),
      preserveDraft: state.overlay.querySelector('#sdia-setting-preserve-draft'), startOverview: state.overlay.querySelector('#sdia-setting-start-overview'), restoreWorkspace: state.overlay.querySelector('#sdia-setting-restore-workspace'),
      transitionSplash: state.overlay.querySelector('#sdia-setting-transition-splash'), guidanceHints: state.overlay.querySelector('#sdia-setting-guidance-hints')
    };
    const appearanceCards = [...state.overlay.querySelectorAll('[data-sdia-appearance]')];
    const visualSwatches = [...state.overlay.querySelectorAll('[data-sdia-visual-theme]')];
    const visualAuto = state.overlay.querySelector('#sdia-visual-auto');
    const visualStatus = state.overlay.querySelector('#sdia-visual-rotation-status');
    const syncVisualExperience = () => {
      const progress = SDIA.VisualExperience.progress();
      visualSwatches.forEach((swatch) => swatch.classList.toggle('is-active', swatch.dataset.sdiaVisualTheme === progress.theme));
      if (visualAuto) {
        visualAuto.classList.toggle('is-manual', !progress.automatic);
        visualAuto.textContent = progress.automatic ? `Automatic · ${progress.threshold} openings` : 'Resume automatic rotation';
      }
      if (visualStatus) {
        visualStatus.classList.toggle('is-manual', !progress.automatic);
        const theme = SDIA.VisualExperience.THEMES.find((item) => item.id === progress.theme)?.label || progress.theme;
        visualStatus.querySelector('span').textContent = progress.automatic
          ? `${theme} · ${progress.openings}/${progress.threshold} openings · next color in ${progress.remaining}.`
          : `${theme} · manual color lock active.`;
      }
    };
    state.overlay.addEventListener('sdia:visual-experience-changed', syncVisualExperience);
    const syncAppearance = () => {
      appearanceCards.forEach((card) => {
        const active = card.dataset.sdiaAppearance === state.settings.appearance;
        card.classList.toggle('is-active', active);
        card.setAttribute('aria-checked', active ? 'true' : 'false');
      });
    };
    const sync = () => {
      fields.company.value = state.settings.defaultCompanyCode || '';
      fields.division.value = state.settings.defaultDivisionCode || '';
      fields.vendor.value = state.settings.vendor || '';
      fields.companyEnabled.checked = Boolean(state.settings.defaultCompanyPrefixEnabled);
      fields.divisionEnabled.checked = Boolean(state.settings.defaultDivisionEnabled);
      fields.vendorEnabled.checked = state.settings.useDefaultVendor !== false;
      fields.preserveDraft.checked = state.settings.preserveDraftSession !== false;
      fields.startOverview.checked = state.settings.startNewContextInOverview !== false;
      fields.restoreWorkspace.checked = state.settings.restoreLastWorkspaceInSession !== false;
      fields.transitionSplash.checked = state.settings.transitionSplashEnabled !== false;
      fields.guidanceHints.checked = state.settings.showGuidanceHints !== false;
      syncAppearance();
      syncVisualExperience();
    };
    sync();
    appearanceCards.forEach((card) => card.addEventListener('click', async () => {
      const theme = card.dataset.sdiaAppearance;
      if (!theme || theme === state.settings.appearance) return;
      state.settings.appearance = theme;
      applyAppearanceTheme();
      syncAppearance();
      await saveSettings();
      showToast(`Appearance theme applied: ${card.querySelector('b')?.textContent || theme}.`);
    }));
    visualSwatches.forEach((swatch) => swatch.addEventListener('click', async () => {
      await SDIA.VisualExperience.selectManual(swatch.dataset.sdiaVisualTheme);
      syncVisualExperience();
      const label = SDIA.VisualExperience.THEMES.find((item) => item.id === swatch.dataset.sdiaVisualTheme)?.label || swatch.dataset.sdiaVisualTheme;
      showToast(`Control Plane color locked: ${label}.`);
    }));
    visualAuto?.addEventListener('click', async () => {
      await SDIA.VisualExperience.enableAutomatic();
      syncVisualExperience();
      showToast('Automatic Control Plane color rotation enabled · changes every 20 openings.');
    });
    state.overlay.querySelector('#sdia-save-settings').addEventListener('click', async () => {
      state.settings.defaultCompanyCode = normalizeToken(fields.company.value);
      state.settings.defaultDivisionCode = normalizeToken(fields.division.value);
      state.settings.vendor = fields.vendor.value.trim();
      state.settings.defaultCompanyPrefixEnabled = fields.companyEnabled.checked;
      state.settings.defaultDivisionEnabled = fields.divisionEnabled.checked;
      state.settings.useDefaultVendor = fields.vendorEnabled.checked;
      state.settings.preserveDraftSession = fields.preserveDraft.checked;
      state.settings.startNewContextInOverview = fields.startOverview.checked;
      state.settings.restoreLastWorkspaceInSession = fields.restoreWorkspace.checked;
      state.settings.transitionSplashEnabled = fields.transitionSplash.checked;
      state.settings.showGuidanceHints = fields.guidanceHints.checked;
      await saveSettings();
      state.overlay.querySelector('.sdia-control-center')?.classList.toggle('sdia-hide-guidance-hints', state.settings.showGuidanceHints === false);
      if (state.activeModule === 'package-map') SDIA.CloudIntegration.Package.renderPackageGovernanceMap(state.overlay.querySelector('#sdia-package-map-search')?.value || '');
      showToast('Governance settings saved.');
    });
    state.overlay.querySelector('#sdia-reset-session').addEventListener('click', () => {
      clearPersistedControlCenterState();
      try { sessionStorage.removeItem('sdia:package-edit-transaction:v0.2.0'); } catch (_) {}
      state.internalHistory = [];
      showToast('Current SDIA session state cleared.');
    });
    state.overlay.querySelector('#sdia-reset-preferences').addEventListener('click', async () => {
      const keep = { enabledHosts: state.settings.enabledHosts, autoDetectSap: state.settings.autoDetectSap, launcherVisible: state.settings.launcherVisible, launcherLeft: state.settings.launcherLeft, launcherTop: state.settings.launcherTop };
      Object.assign(state.settings, SDIA.Core.DEFAULT_SETTINGS, keep);
      await saveSettings();
      applyAppearanceTheme();
      sync();
      showToast('Local governance preferences restored to defaults.');
    });
    state.overlay.querySelector('#sdia-run-assessment').addEventListener('click', SDIA.CloudIntegration.Package.runPackageAssessment);
  }
  function showToast(message, duration = 3600) {
    if (!state.toast) return;
    clearTimeout(state.toastTimer);
    state.toast.textContent = message;
    state.toast.classList.remove('sdia-hidden');
    state.toastTimer = setTimeout(() => state.toast?.classList.add('sdia-hidden'), duration);
  }

  SDIA.Workspace = Object.freeze({ openControlCenter, closeControlCenter, createControlCenter, switchModule, openCapabilityAction, applyProductContext, refreshContextPanel, showToast });
})();
