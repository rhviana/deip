/* SDIA Governance — persistent local Home action.
 * Changes only the SDIA workspace view. The underlying SAP URL never changes.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};

  function markup() {
    return `<button type="button" id="sdia-control-plane-home" class="sdia-control-plane-home" hidden data-sdia-action="control-plane-home" aria-label="Open SDIA Home without changing the SAP page">
      <span>SDIA HOME</span>
    </button>`;
  }

  SDIA.ControlPlaneHome = Object.freeze({ markup });
})();
