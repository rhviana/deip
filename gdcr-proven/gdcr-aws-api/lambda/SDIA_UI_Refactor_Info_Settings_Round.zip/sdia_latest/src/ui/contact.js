/* SDIA Governance v0.2.0 — project/contact workspace. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { escapeHtml, icon } = SDIA.Core;

  const CONTACT_LINKS = Object.freeze([
    { label:'EventSmartKafka · Open Source Adapters', meta:'GitHub', href:'https://github.com/rhviana/sap-ci-opensource-adapters', icon:'eventmesh' },
    { label:'DEIP · SDIA', meta:'GitHub', href:'https://github.com/rhviana/deip', icon:'map' },
    { label:'LinkedIn', meta:'Professional profile', href:'https://www.linkedin.com/in/viana-deip/', icon:'contact' },
    { label:'SAP CITS · Cloud Integration Technical Specification', meta:'Chrome Web Store', href:'https://chromewebstore.google.com/detail/sap-cits-cloud-integratio/mhlbofflpmjbkdbijilaiddalokmfnfb', icon:'packages' },
    { label:'rhviana@gmail.com', meta:'Contact', href:'mailto:rhviana@gmail.com', icon:'contact' }
  ]);

  function markup() {
    return `<section class="sdia-module sdia-hidden" data-sdia-view="contact">
      <div class="sdia-module-heading"><span>CONTACT · PROJECT AUTHOR</span><h1>Ricardo Luz Holanda Viana</h1><p>Enterprise Integration Architect · DDCR™ Inventor · SAP BTP Expert</p></div>
      <section class="sdia-contact-card">
        <div class="sdia-contact-identity">
          <div class="sdia-contact-avatar">${icon('contact')}</div>
          <div><span>SDIA · DEIP · OPEN SOURCE</span><h2>Domain-Centric integration architecture and governance</h2><p>Research, architecture patterns, SAP Integration Suite tooling and open-source integration components.</p></div>
        </div>
        <div class="sdia-contact-links">
          ${CONTACT_LINKS.map((item) => `<a href="${escapeHtml(item.href)}" target="${item.href.startsWith('mailto:') ? '_self' : '_blank'}" rel="noopener noreferrer"><i>${icon(item.icon)}</i><span><b>${escapeHtml(item.label)}</b><small>${escapeHtml(item.meta)}</small></span><em>${icon('arrow')}</em></a>`).join('')}
        </div>
        <div class="sdia-contact-note"><b>Contact</b><span>The current email is a personal project contact and can be replaced later by a commercial address without changing the workspace structure.</span></div>
      </section>
    </section>`;
  }

  SDIA.ContactUI = Object.freeze({ markup });
})();
