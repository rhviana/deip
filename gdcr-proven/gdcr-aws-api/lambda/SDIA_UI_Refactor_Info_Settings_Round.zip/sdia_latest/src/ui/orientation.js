/* SDIA Governance v1.0.0 — interactive SDIA orientation journey.
 * The journey teaches the semantic decision sequence before technical execution:
 * Requirement -> Business Object -> Process -> Capability -> Domain -> Subdomain -> Boundary -> Execution.
 * Completion is local to the browser profile and never changes SAP tenant data.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { state, escapeHtml, normalizeToken, icon, runtimeUrl } = SDIA.Core;

  const STORAGE_KEY = 'sdiaOrientationStatusV1';
  const JOURNEY_VERSION = '1.0';
  const TOTAL_STEPS = 10;
  const OPERATIONAL_MODULES = new Set([
    'packages','package-map','assessment','package-create','package-edit-list','package-edit-form',
    'package-workspace','capability-action','apim','eventmesh','security'
  ]);

  const runtime = {
    initialized:false,
    completed:false,
    completedAt:null,
    step:0,
    stepComplete:Array(TOTAL_STEPS).fill(false),
    scenarioId:'',
    scenarioConversationDone:false,
    scenarioPlaybackToken:0,
    scenarioDiscovery:{ domain:'', subdomain:'', build:[], feedback:'', completed:false },
    classification:{},
    selectedCard:'',
    catalogDomain:'',
    catalogSubdomain:'',
    moduleClue:'',
    investigator:{},
    builder:{ company:'acme', division:'br', domain:'', subdomain:'' },
    execution:'',
    complianceChoice:'',
    mission:{ domain:'', subdomain:'', execution:'', passed:false, feedback:'' }
  };

  const STEPS = Object.freeze([
    { eyebrow:'01 · WHERE SDIA LIVES', title:'Put the Domain Layer before technology', kind:'architecture' },
    { eyebrow:'02 · GUIDED SCENARIOS', title:'Correct the technology-first reflex and build the Domain Boundary', kind:'scenarios' },
    { eyebrow:'03 · DOMAIN ≠ TECHNOLOGY', title:'Classify the semantic and technical clues', kind:'classification' },
    { eyebrow:'04 · USE THE CATALOG', title:'Discover the governed semantic vocabulary', kind:'catalog' },
    { eyebrow:'05 · USE PRODUCT / MODULE EVIDENCE', title:'A SAP module is evidence — not the Domain', kind:'module-clues' },
    { eyebrow:'06 · INVESTIGATE THE INTENT', title:'Ask the questions that expose the boundary', kind:'investigator' },
    { eyebrow:'07 · BUILD THE BOUNDARY', title:'Turn semantics into a governed identity', kind:'builder' },
    { eyebrow:'08 · CHOOSE TECHNOLOGY LAST', title:'Execution follows the business need', kind:'execution' },
    { eyebrow:'09 · GOVERN, DO NOT IMPRISON', title:'Compliance warns; the user remains sovereign', kind:'compliance' },
    { eyebrow:'10 · FINAL MISSION', title:'Prove the method and activate governance', kind:'mission' }
  ]);

  const MODULE_CLUES = Object.freeze({
    sd: { code:'SD', name:'Sales & Distribution', icon:'packages', paths:[['SALES','OTC','Sales order / order-to-cash'],['SALES','PRICE','Pricing and conditions'],['SALES','BILL','Billing']] },
    mm: { code:'MM', name:'Materials Management', icon:'catalog', paths:[['PROC','PUR','Purchasing / purchase orders'],['LOG','INV','Inventory and stock'],['FIN','AP','Supplier invoice when Finance owns the process']] },
    fi: { code:'FI', name:'Financial Accounting', icon:'assessment', paths:[['FIN','RTR','General ledger / Record to Report'],['FIN','AP','Accounts Payable'],['FIN','AR','Accounts Receivable']] },
    pm: { code:'PM', name:'Plant Maintenance', icon:'settings', paths:[['ASSET','PM','Preventive maintenance'],['ASSET','WO','Maintenance work orders'],['ASSET','MASTER','Technical objects / asset master']] },
    hcm: { code:'HCM', name:'Human Capital Management', icon:'contact', paths:[['HR','CORE','Employee / organizational core'],['HR','PAY','Payroll'],['HR','TIME','Time management']] }
  });

  const INVESTIGATOR = Object.freeze([
    { id:'object', question:'What business object is moving?', correct:'Sales Order', options:['Sales Order','API Proxy','JSON Payload'] },
    { id:'process', question:'What process does it belong to?', correct:'Order to Cash', options:['Order to Cash','Message Mapping','Authentication'] },
    { id:'owner', question:'Who owns the business capability?', correct:'Sales', options:['Sales','Cloud Integration','Integration Developer'] },
    { id:'evidence', question:'Which technical clue supports the decision?', correct:'SAP S/4HANA SD', options:['SAP S/4HANA SD','HTTP Adapter','OAuth 2.0'] },
    { id:'intent', question:'What does the integration need to accomplish?', correct:'Publish an order event', options:['Publish an order event','Use JSON','Call port 443'] }
  ]);


  const GUIDED_SCENARIOS = Object.freeze({
    successfactors: {
      id:'successfactors', product:'SAP SuccessFactors', module:'Employee Central', logo:'src/shared/vendors/assets/vendor-sap.png', tag:'HR',
      title:'Employee master → ServiceNow', brief:'Employee Central worker data must be replicated to ServiceNow.',
      specification:'When employee master data is created or changed in SAP SuccessFactors Employee Central, replicate the required worker information to ServiceNow.',
      wrongPackage:'SuccessFactors_to_ServiceNow', wrongIflow:'SuccessFactors-ServiceNow-Location',
      techTokens:['OData','REST','JSON','Mapping','Groovy','OAuth'],
      messages:[
        { role:'Project Manager', icon:'contact', tone:'business', text:'The functional specification is approved. Please create the integration artefacts and start the SuccessFactors to ServiceNow integration.' },
        { role:'SAP BTP Developer', icon:'packages', tone:'technical', text:'Great. I will create package SuccessFactors_to_ServiceNow, an iFlow called SuccessFactors-ServiceNow-Location, consume Employee Central with OData and map the JSON payload in Cloud Integration.' },
        { role:'Enterprise Architect', icon:'shield', tone:'architect', text:'No. I cannot approve that boundary. SuccessFactors and ServiceNow are products; OData, JSON and mappings are execution concerns. First identify the business capability. Employee Central is evidence for the Human Resources domain, and the subdomain depends on the capability being integrated.' }
      ],
      company:'var', domain:'HR', domainOptions:['HR','FIN','PROC','SVC'], subdomain:'CORE', subdomainOptions:['CORE','REC','LRN','PAY'],
      result:{ object:'Employee / Worker', process:'Employee master data', evidence:'SAP SuccessFactors Employee Central', execution:'Cloud Integration', explanation:'Employee Central carries the core worker, employment and organizational context. Learning, Recruiting or Payroll would lead to different HR subdomains.' }
    },
    ariba: {
      id:'ariba', product:'SAP Ariba', module:'Buying / Procurement', logo:'src/shared/vendors/assets/vendor-sap.png', tag:'PROC',
      title:'Requisition → purchasing', brief:'An approved requisition in Ariba must continue the purchasing process in S/4HANA.',
      specification:'Approved purchase requisitions in SAP Ariba must create or update the required purchasing documents in SAP S/4HANA.',
      wrongPackage:'Ariba_to_S4', wrongIflow:'Ariba-PR-to-S4-PO',
      techTokens:['cXML','SOAP','REST','Mapping','OAuth','JSON'],
      messages:[
        { role:'Project Manager', icon:'contact', tone:'business', text:'The requisition integration is approved. Please create the artefacts and connect SAP Ariba with S/4HANA.' },
        { role:'SAP BTP Developer', icon:'packages', tone:'technical', text:'I will create package Ariba_to_S4, map cXML to the S/4 payload and decide whether SOAP or REST is easier.' },
        { role:'Enterprise Architect', icon:'shield', tone:'architect', text:'Technology first again. Ariba is evidence, not the Domain. Ask what process the requisition belongs to. Purchasing is the capability that must own this boundary.' }
      ],
      company:'var', domain:'PROC', domainOptions:['PROC','LOG','FIN','SALES'], subdomain:'PUR', subdomainOptions:['PUR','REQ','SUP','INV'],
      result:{ object:'Purchase Requisition', process:'Purchasing', evidence:'SAP Ariba Buying', execution:'Cloud Integration', explanation:'A requisition progressing into purchasing belongs to the Sourcing and Procurement domain. Supplier lifecycle, sourcing events or invoicing would resolve to different subdomains.' }
    },
    s4sales: {
      id:'s4sales', product:'SAP S/4HANA', module:'SD · Sales', logo:'src/shared/vendors/assets/vendor-sap.png', tag:'SALES',
      title:'Sales order → fulfillment', brief:'Created sales orders must reach an external fulfillment platform.',
      specification:'When a sales order is created in SAP S/4HANA Sales and Distribution, publish the order to an external fulfillment platform.',
      wrongPackage:'S4_to_Fulfillment', wrongIflow:'ORDERS05_to_REST_Fulfillment',
      techTokens:['IDoc','ORDERS05','REST','JSON','XSLT','Mapping'],
      messages:[
        { role:'Project Manager', icon:'contact', tone:'business', text:'We need created sales orders from S/4HANA delivered to our fulfillment platform. Please start the integration.' },
        { role:'SAP BTP Developer', icon:'packages', tone:'technical', text:'I will call the package S4_to_Fulfillment and use ORDERS05, then transform it to JSON and call the REST API.' },
        { role:'Enterprise Architect', icon:'shield', tone:'architect', text:'ORDERS05 and REST belong to execution. The business object is a Sales Order and the process is Order to Cash. Govern that meaning first.' }
      ],
      company:'var', domain:'SALES', domainOptions:['SALES','COM','LOG','FIN'], subdomain:'OTC', subdomainOptions:['OTC','ORD','CRM','BILL'],
      result:{ object:'Sales Order', process:'Order to Cash', evidence:'SAP S/4HANA SD', execution:'Event or orchestration — chosen last', explanation:'The SD module supports the decision, but the business process defines the boundary. Other SD scenarios can belong to Pricing, Billing, CRM or Sales Order Management.' }
    },
    s4finance: {
      id:'s4finance', product:'SAP S/4HANA', module:'FI · Finance', logo:'src/shared/vendors/assets/vendor-sap.png', tag:'FIN',
      title:'General ledger posting', brief:'Financial postings must be replicated to a downstream finance platform.',
      specification:'Replicate approved general-ledger postings from SAP S/4HANA Finance to the corporate finance platform.',
      wrongPackage:'S4_FI_Posting_Interface', wrongIflow:'BAPI_ACC_DOCUMENT_POST_to_SOAP',
      techTokens:['BAPI','SOAP','OData','XML','Mapping','RFC'],
      messages:[
        { role:'Project Manager', icon:'contact', tone:'business', text:'Finance approved the general-ledger replication. Please create the integration artefacts.' },
        { role:'SAP BTP Developer', icon:'packages', tone:'technical', text:'I will create S4_FI_Posting_Interface and use BAPI_ACC_DOCUMENT_POST or SOAP depending on what is easiest.' },
        { role:'Enterprise Architect', icon:'shield', tone:'architect', text:'Even choosing Finance is not enough. Is this Accounts Payable, Receivable, Treasury or Record to Report? The business process determines the subdomain.' }
      ],
      company:'var', domain:'FIN', domainOptions:['FIN','SALES','PROC','ASSET'], subdomain:'RTR', subdomainOptions:['RTR','AP','AR','TRE'],
      result:{ object:'Journal / GL Posting', process:'Record to Report', evidence:'SAP S/4HANA FI', execution:'Cloud Integration', explanation:'FI is a strong clue for Finance, but SDIA still resolves the specific capability. General-ledger and accounting-cycle integration belongs to Record to Report.' }
    },
    concur: {
      id:'concur', product:'SAP Concur', module:'Expense', logo:'src/shared/vendors/assets/vendor-sap.png', tag:'FIN',
      title:'Employee expense → finance', brief:'Approved employee expenses must post into the enterprise finance process.',
      specification:'Approved expense reports from SAP Concur must be transferred to SAP S/4HANA Finance for reimbursement and accounting.',
      wrongPackage:'Concur_to_S4_Finance', wrongIflow:'ConcurExpense_JSON_to_S4',
      techTokens:['REST','JSON','OAuth','Mapping','SFTP','XML'],
      messages:[
        { role:'Project Manager', icon:'contact', tone:'business', text:'The Concur expense integration is approved. Please connect it to S/4HANA Finance.' },
        { role:'SAP BTP Developer', icon:'packages', tone:'technical', text:'I will create Concur_to_S4_Finance, call the REST API with OAuth and map the JSON expense payload.' },
        { role:'Enterprise Architect', icon:'shield', tone:'architect', text:'Those are valid implementation choices, but they do not define the boundary. The business capability is employee expense management inside Finance.' }
      ],
      company:'var', domain:'FIN', domainOptions:['FIN','HR','PROC','SALES'], subdomain:'EXP', subdomainOptions:['EXP','AP','RTR','INV'],
      result:{ object:'Expense Report', process:'Expense management', evidence:'SAP Concur Expense', execution:'Cloud Integration', explanation:'The product is Concur, but the governed capability is Expense Management. The technology can change without changing that semantic identity.' }
    },
    sfrecruiting: {
      id:'sfrecruiting', product:'SAP SuccessFactors', module:'Recruiting', logo:'src/shared/vendors/assets/vendor-sap.png', tag:'HR',
      title:'Candidate → recruiting process', brief:'Recruiting events and candidate data must integrate with downstream HR services.',
      specification:'Candidate and recruiting-status changes from SAP SuccessFactors Recruiting must be integrated with downstream HR services.',
      wrongPackage:'SuccessFactors_Recruiting_Interfaces', wrongIflow:'SF-Recruiting-REST-CandidateSync',
      techTokens:['OData','REST','JSON','Groovy','Mapping','OAuth'],
      messages:[
        { role:'Project Manager', icon:'contact', tone:'business', text:'Recruiting needs the candidate integration delivered. Please create the package and iFlows.' },
        { role:'SAP BTP Developer', icon:'packages', tone:'technical', text:'I will reuse the SuccessFactors naming and create SuccessFactors_Recruiting_Interfaces with a REST candidate sync iFlow.' },
        { role:'Enterprise Architect', icon:'shield', tone:'architect', text:'SuccessFactors still does not define the subdomain. Employee Central points to CORE; Recruiting points to the Recruiting capability. Same vendor, different boundary.' }
      ],
      company:'var', domain:'HR', domainOptions:['HR','SALES','SVC','FIN'], subdomain:'REC', subdomainOptions:['REC','CORE','ONB','LRN'],
      result:{ object:'Candidate', process:'Recruiting / talent acquisition', evidence:'SAP SuccessFactors Recruiting', execution:'Cloud Integration', explanation:'This scenario proves why product-centric naming fails: two SuccessFactors integrations can legitimately belong to different HR subdomains.' }
    },
    plant: {
      id:'plant', product:'SAP S/4HANA', module:'PM · Plant Maintenance', logo:'src/shared/vendors/assets/vendor-sap.png', tag:'PLANT',
      title:'Maintenance execution', brief:'Maintenance orders must be integrated with a field execution solution.',
      specification:'Release and status changes of plant maintenance orders must be synchronized with the external field execution solution.',
      wrongPackage:'S4_PM_to_FieldApp', wrongIflow:'PM_Order_IDoc_to_REST',
      techTokens:['IDoc','REST','OData','JSON','Mapping','RFC'],
      messages:[
        { role:'Project Manager', icon:'contact', tone:'business', text:'Maintenance wants released orders synchronized to the field solution. Please start development.' },
        { role:'SAP BTP Developer', icon:'packages', tone:'technical', text:'I will create S4_PM_to_FieldApp and decide between IDoc, OData or REST for the order exchange.' },
        { role:'Enterprise Architect', icon:'shield', tone:'architect', text:'PM is evidence. The requirement is about plant maintenance execution, so identify the Plant Operations and Maintenance capability before choosing the protocol.' }
      ],
      company:'var', domain:'PLANT', domainOptions:['PLANT','MNE','ASSET','LOG'], subdomain:'MAINT', subdomainOptions:['MAINT','OPS','INSP','SAFE'],
      result:{ object:'Maintenance Order', process:'Maintenance execution', evidence:'SAP S/4HANA PM', execution:'Cloud Integration', explanation:'A module name is a clue, not a naming convention. Maintenance planning or engineering master data could legitimately resolve to a different Domain or Subdomain.' }
    },
    salesforce: {
      id:'salesforce', product:'Salesforce', module:'Sales Cloud', logo:'src/shared/vendors/assets/vendor-salesforce.png', tag:'SALES',
      title:'Account / opportunity sync', brief:'Commercial account and opportunity data must synchronize with the enterprise backend.',
      specification:'Synchronize account and opportunity changes from Salesforce Sales Cloud with the enterprise backend.',
      wrongPackage:'Salesforce_to_SAP', wrongIflow:'Salesforce-REST-OpportunitySync',
      techTokens:['REST','OAuth','JSON','API','Mapping','Webhook'],
      messages:[
        { role:'Project Manager', icon:'contact', tone:'business', text:'Sales needs Salesforce account and opportunity updates synchronized with our backend.' },
        { role:'SAP BTP Developer', icon:'packages', tone:'technical', text:'I will create Salesforce_to_SAP, use the Salesforce REST API and OAuth, then map the JSON payload.' },
        { role:'Enterprise Architect', icon:'shield', tone:'architect', text:'Vendor-neutral governance means Salesforce is only evidence. The capability is customer relationship management inside the Sales domain.' }
      ],
      company:'var', domain:'SALES', domainOptions:['SALES','CUST','COM','SVC'], subdomain:'CRM', subdomainOptions:['CRM','OPP','OTC','LEAD'],
      result:{ object:'Account / Opportunity', process:'Customer relationship management', evidence:'Salesforce Sales Cloud', execution:'API or orchestration — chosen last', explanation:'SDIA does not require SAP products. The same semantic method applies to any vendor because the business capability owns the boundary.' }
    },
    workday: {
      id:'workday', product:'Workday', module:'HCM', logo:'src/shared/vendors/assets/vendor-workday.png', tag:'HR',
      title:'Worker master synchronization', brief:'Worker master data must synchronize with enterprise HR and service systems.',
      specification:'Worker master and employment changes from Workday HCM must be synchronized with enterprise HR and service platforms.',
      wrongPackage:'Workday_to_ServiceNow', wrongIflow:'Workday-SOAP-WorkerSync',
      techTokens:['SOAP','REST','XML','XSLT','OAuth','Mapping'],
      messages:[
        { role:'Project Manager', icon:'contact', tone:'business', text:'Please integrate Workday worker changes with the enterprise service platform.' },
        { role:'SAP BTP Developer', icon:'packages', tone:'technical', text:'I will create Workday_to_ServiceNow and use the Workday SOAP service with XSLT transformations.' },
        { role:'Enterprise Architect', icon:'shield', tone:'architect', text:'SOAP and XSLT are execution details. Worker master and employment data belong to the Human Resources core capability regardless of the vendor.' }
      ],
      company:'var', domain:'HR', domainOptions:['HR','SVC','FIN','IT'], subdomain:'CORE', subdomainOptions:['CORE','PAY','TIME','REC'],
      result:{ object:'Worker', process:'Employee master data', evidence:'Workday HCM', execution:'Cloud Integration', explanation:'This is the same HR/CORE business capability as Employee Central, proving that the Domain Boundary survives a change of technology or vendor.' }
    },
    aribasupplier: {
      id:'aribasupplier', product:'SAP Ariba', module:'Supplier Lifecycle', logo:'src/shared/vendors/assets/vendor-sap.png', tag:'PROC',
      title:'Supplier lifecycle governance', brief:'Supplier master and qualification changes must reach downstream enterprise systems.',
      specification:'Approved supplier lifecycle and qualification changes in SAP Ariba must be propagated to downstream enterprise systems.',
      wrongPackage:'Ariba_Supplier_Master_Integration', wrongIflow:'AribaSupplier_cXML_S4Sync',
      techTokens:['cXML','REST','SOAP','JSON','Mapping','OAuth'],
      messages:[
        { role:'Project Manager', icon:'contact', tone:'business', text:'Supplier lifecycle integration is approved. Please create the Ariba package and start development.' },
        { role:'SAP BTP Developer', icon:'packages', tone:'technical', text:'I will create Ariba_Supplier_Master_Integration and use cXML or REST depending on the available endpoint.' },
        { role:'Enterprise Architect', icon:'shield', tone:'architect', text:'This is another Ariba example with a different capability. Purchasing would be PUR; supplier lifecycle belongs to Supplier Management. Product names cannot carry that distinction.' }
      ],
      company:'var', domain:'PROC', domainOptions:['PROC','CUST','FIN','LOG'], subdomain:'SUP', subdomainOptions:['SUP','ONB','RISK','SRC'],
      result:{ object:'Supplier', process:'Supplier lifecycle / qualification', evidence:'SAP Ariba Supplier Lifecycle', execution:'Cloud Integration', explanation:'Two Ariba integrations can belong to different subdomains. The process — not the product — determines the governed identity.' }
    }
  });

  function catalogDomains() { return Array.isArray(state.catalog?.domains) ? state.catalog.domains : []; }
  function findDomain(code) {
    const token = normalizeToken(code);
    return catalogDomains().find((item) => [item.canonicalCode,item.id,...(item.aliases || [])].map(normalizeToken).includes(token)) || null;
  }
  function findSubdomain(domain, code) {
    const token = normalizeToken(code);
    return (domain?.subdomains || []).find((item) => [item.canonicalCode,item.id,...(item.aliases || [])].map(normalizeToken).includes(token)) || null;
  }

  async function init() {
    if (runtime.initialized) return runtime.completed;
    runtime.initialized = true;
    try {
      const data = await chrome.storage.local.get(STORAGE_KEY);
      const status = data?.[STORAGE_KEY] || {};
      runtime.completed = status.completed === true;
      runtime.completedAt = status.completedAt || null;
    } catch (_) {}
    globalThis.dispatchEvent(new CustomEvent('sdia:orientation-ready', { detail:snapshot() }));
    return runtime.completed;
  }

  function snapshot() {
    return { completed:runtime.completed, completedAt:runtime.completedAt, version:JOURNEY_VERSION, step:runtime.step };
  }
  function isCompleted() { return runtime.completed === true; }
  function requiresCompletion(module) { return OPERATIONAL_MODULES.has(String(module || '')); }

  async function persistCompletion() {
    runtime.completed = true;
    runtime.completedAt = new Date().toISOString();
    const payload = { completed:true, completedAt:runtime.completedAt, version:JOURNEY_VERSION };
    try { await chrome.storage.local.set({ [STORAGE_KEY]:payload }); } catch (_) {}
    globalThis.dispatchEvent(new CustomEvent('sdia:orientation-changed', { detail:snapshot() }));
    SDIA.Workspace?.applyProductContext?.();
    SDIA.Workspace?.refreshContextPanel?.();
    return payload;
  }

  function resetJourneyProgress({ keepCompletion=true } = {}) {
    runtime.step = 0;
    runtime.stepComplete = Array(TOTAL_STEPS).fill(false);
    runtime.scenarioId = '';
    runtime.scenarioConversationDone = false;
    runtime.scenarioPlaybackToken += 1;
    runtime.scenarioDiscovery = { domain:'', subdomain:'', build:[], feedback:'', completed:false };
    runtime.classification = {};
    runtime.selectedCard = '';
    runtime.catalogDomain = '';
    runtime.catalogSubdomain = '';
    runtime.moduleClue = '';
    runtime.investigator = {};
    runtime.builder = { company:'acme', division:'br', domain:'', subdomain:'' };
    runtime.execution = '';
    runtime.complianceChoice = '';
    runtime.mission = { domain:'', subdomain:'', execution:'', passed:false, feedback:'' };
    if (!keepCompletion) {
      runtime.completed = false;
      runtime.completedAt = null;
    }
  }

  function markup() {
    return `<section class="sdia-module sdia-hidden" data-sdia-view="how-to">
      <div class="sdia-orientation-shell">
        <header class="sdia-orientation-header">
          <div><span>HOW TO USE SDIA</span><h1>From business requirement to governed execution</h1><p>Learn the SDIA decision sequence through ten different interactive models. Technology comes last.</p></div>
          <div class="sdia-orientation-status" id="sdia-orientation-status"></div>
        </header>
        <div class="sdia-orientation-progress" id="sdia-orientation-progress" aria-label="Orientation progress"></div>
        <div class="sdia-orientation-stage" id="sdia-orientation-stage"></div>
        <footer class="sdia-orientation-footer">
          <button type="button" id="sdia-orientation-back">← Back</button>
          <div><span id="sdia-orientation-step-label">Step 1 of 10</span><b id="sdia-orientation-step-state">Explore the model</b></div>
          <button type="button" id="sdia-orientation-next" class="sdia-primary-action">Next →</button>
        </footer>
      </div>
    </section>`;
  }

  function render() {
    if (!state.overlay) return;
    const stage = state.overlay.querySelector('#sdia-orientation-stage');
    if (!stage) return;
    const step = STEPS[runtime.step];
    stage.dataset.sdiaOrientationKind = step.kind;
    stage.innerHTML = `<div class="sdia-orientation-step-enter"><div class="sdia-orientation-step-heading"><span>${escapeHtml(step.eyebrow)}</span><h2>${escapeHtml(step.title)}</h2></div>${stepMarkup(runtime.step)}</div>`;
    renderProgress();
    bindStep(runtime.step);
    updateFooter();
  }

  function renderProgress() {
    if (!state.overlay) return;
    const progress = state.overlay.querySelector('#sdia-orientation-progress');
    const status = state.overlay.querySelector('#sdia-orientation-status');
    if (progress) progress.innerHTML = STEPS.map((step,index) => `<button type="button" data-sdia-orientation-jump="${index}" class="${index === runtime.step ? 'active' : ''}${runtime.stepComplete[index] ? ' complete' : ''}" aria-label="Step ${index + 1}: ${escapeHtml(step.title)}"><i>${runtime.stepComplete[index] ? '✓' : index + 1}</i><span>${escapeHtml(step.kind.replace(/-/g,' '))}</span></button>`).join('');
    if (status) {
      status.classList.toggle('complete', runtime.completed);
      status.innerHTML = runtime.completed
        ? `<i>${icon('shield')}</i><span>SDIA GOVERNANCE</span><b>ACTIVE</b><small>Orientation completed</small><button type="button" id="sdia-orientation-replay">Replay journey</button>`
        : `<i>${icon('journey')}</i><span>ORIENTATION</span><b>REQUIRED</b><small>Complete 10 steps to activate governance capabilities</small>`;
      status.querySelector('#sdia-orientation-replay')?.addEventListener('click', () => { resetJourneyProgress({ keepCompletion:true }); render(); });
    }
    progress?.querySelectorAll('[data-sdia-orientation-jump]').forEach((button) => button.addEventListener('click', () => {
      const target = Number(button.dataset.sdiaOrientationJump);
      if (!Number.isInteger(target)) return;
      // Revisiting previous steps is always allowed. Forward jumps require prior completion.
      if (target <= runtime.step || runtime.completed || runtime.stepComplete.slice(0,target).every(Boolean)) {
        runtime.step = target; render();
      }
    }));
  }

  function updateFooter() {
    if (!state.overlay) return;
    const back = state.overlay.querySelector('#sdia-orientation-back');
    const next = state.overlay.querySelector('#sdia-orientation-next');
    const label = state.overlay.querySelector('#sdia-orientation-step-label');
    const stateLabel = state.overlay.querySelector('#sdia-orientation-step-state');
    if (back) back.disabled = runtime.step === 0;
    if (label) label.textContent = `Step ${runtime.step + 1} of ${TOTAL_STEPS}`;
    const canAdvance = runtime.step === 0 || runtime.stepComplete[runtime.step] || runtime.completed;
    if (stateLabel) stateLabel.textContent = runtime.stepComplete[runtime.step] ? 'Step completed' : runtime.step === 0 ? 'Explore the model' : 'Complete the interaction to continue';
    if (next) {
      next.classList.toggle('sdia-hidden', runtime.step === TOTAL_STEPS - 1);
      next.disabled = !canAdvance;
      next.textContent = runtime.step === TOTAL_STEPS - 2 ? 'Final Mission →' : 'Next →';
    }
  }

  function stepMarkup(index) {
    if (index === 0) return architectureStep();
    if (index === 1) return requirementStep();
    if (index === 2) return classificationStep();
    if (index === 3) return catalogStep();
    if (index === 4) return moduleClueStep();
    if (index === 5) return investigatorStep();
    if (index === 6) return builderStep();
    if (index === 7) return executionStep();
    if (index === 8) return complianceStep();
    return missionStep();
  }

  function architectureStep() {
    return `<div class="sdia-orientation-architecture">
      <section class="sdia-orientation-business-intent"><span>BUSINESS REQUIREMENT</span><b>What does the business need to achieve?</b><p>Start with intent, ownership and capability — never with an adapter or protocol.</p></section>
      <i class="sdia-orientation-flow-arrow"><span></span></i>
      <section class="sdia-orientation-domain-layer"><header><div>${icon('shield')}</div><span>SDIA · DOMAIN LAYER</span><b>Semantic boundary & governance contract</b></header><div class="sdia-orientation-boundary-tokens"><span>DOMAIN</span><i>→</i><span>SUBDOMAIN</span><i>→</i><span>BOUNDARY</span></div><p>Every governed artefact carries business meaning before it reaches a technology.</p></section>
      <i class="sdia-orientation-flow-arrow is-second"><span></span></i>
      <section class="sdia-orientation-execution-rack"><header><span>EXECUTION LAYER</span><b>SAP BTP Integration Suite</b></header><div><article>${icon('packages')}<b>Cloud Integration</b><small>Orchestration</small></article><article>${icon('proxy')}<b>API Management</b><small>API execution</small></article><article>${icon('eventmesh')}<b>Event Mesh / AEM</b><small>Event execution</small></article></div></section>
      <footer><b>Business defines the intent.</b><span>SDIA defines the Domain Boundary.</span><em>Technology executes it.</em></footer>
    </div>`;
  }

  function scenarioDomainOption(code) {
    const domain = findDomain(code);
    return { code:String(domain?.canonicalCode || code).toUpperCase(), name:domain?.name || code };
  }

  function scenarioSubdomainOption(scenario, code) {
    const domain = findDomain(scenario.domain);
    const subdomain = findSubdomain(domain, code);
    return { code:String(subdomain?.canonicalCode || code).toUpperCase(), name:subdomain?.name || code };
  }

  function scenarioExpectedTokens(scenario) {
    return [scenario.company, scenario.division, String(scenario.domain || '').toLowerCase(), String(scenario.subdomain || '').toLowerCase(), 'integrations'].filter(Boolean).map(normalizeToken);
  }

  function scenarioDiscoveryMarkup(scenario) {
    const discovery = runtime.scenarioDiscovery || {};
    const selectedDomain = String(discovery.domain || '').toUpperCase();
    const selectedSubdomain = String(discovery.subdomain || '').toUpperCase();
    const domainCorrect = selectedDomain === String(scenario.domain).toUpperCase();
    const subdomainCorrect = selectedSubdomain === String(scenario.subdomain).toUpperCase();
    const expectedTokens = scenarioExpectedTokens(scenario);
    const built = Array.isArray(discovery.build) ? discovery.build : [];
    const nextIndex = built.length;
    const distractors = [normalizeToken(scenario.product), normalizeToken(scenario.module), 'rest', 'soap'].filter(Boolean);
    const tokenBank = [...new Set([...expectedTokens, ...distractors])];
    const technicalName = expectedTokens.join('.');
    return `<section class="sdia-guided-discovery ${discovery.completed ? 'is-complete' : ''}">
      <div class="sdia-guided-tech-correction">
        <section class="sdia-guided-wrong-naming"><span>DEVELOPER PROPOSAL</span><div><p><small>PACKAGE</small><b>${escapeHtml(scenario.wrongPackage)}</b></p><p><small>IFLOW</small><b>${escapeHtml(scenario.wrongIflow)}</b></p></div><em>Product / interface-centric naming</em></section>
        <section class="sdia-guided-tech-cloud"><span>EXECUTION NOISE</span><div>${scenario.techTokens.map((token,index) => `<b style="--sdia-tech-token:${index}">${escapeHtml(token)}</b>`).join('')}</div><footer>Execution Layer</footer></section>
      </div>
      <div class="sdia-guided-architect-rule"><i>${icon('shield')}</i><div><span>ENTERPRISE ARCHITECT</span><b>Do not name the architecture after products, adapters or protocols.</b><p>Extract the business capability first. Technology belongs to the Execution Layer and can change later.</p></div></div>
      <section class="sdia-guided-discovery-step">
        <header><span>1 · DISCOVER THE DOMAIN</span><b>Which business capability owns this requirement?</b></header>
        <div class="sdia-guided-choice-grid">${scenario.domainOptions.map((code) => { const item=scenarioDomainOption(code); const selected=selectedDomain===item.code; const good=selected && item.code===String(scenario.domain).toUpperCase(); return `<button type="button" data-sdia-scenario-domain="${escapeHtml(item.code)}" class="${selected ? (good ? 'correct' : 'wrong') : ''}"><strong>${escapeHtml(item.code)}</strong><span>${escapeHtml(item.name)}</span></button>`; }).join('')}</div>
        ${discovery.domain && !domainCorrect ? `<p class="sdia-guided-feedback error">Not yet. Re-read the business object and process; the product name is only evidence.</p>` : domainCorrect ? `<p class="sdia-guided-feedback success">✓ Domain identified: ${escapeHtml(String(scenario.domain).toUpperCase())} · ${escapeHtml(scenarioDomainOption(scenario.domain).name)}</p>` : ''}
      </section>
      ${domainCorrect ? `<section class="sdia-guided-discovery-step is-entering"><header><span>2 · DISCOVER THE SUBDOMAIN</span><b>Which capability inside ${escapeHtml(String(scenario.domain).toUpperCase())} actually owns this process?</b></header><div class="sdia-guided-choice-grid">${scenario.subdomainOptions.map((code) => { const item=scenarioSubdomainOption(scenario,code); const selected=selectedSubdomain===item.code; const good=selected && item.code===String(scenario.subdomain).toUpperCase(); return `<button type="button" data-sdia-scenario-subdomain="${escapeHtml(item.code)}" class="${selected ? (good ? 'correct' : 'wrong') : ''}"><strong>${escapeHtml(item.code)}</strong><span>${escapeHtml(item.name)}</span></button>`; }).join('')}</div>${discovery.subdomain && !subdomainCorrect ? `<p class="sdia-guided-feedback error">Close, but this process belongs to another ${escapeHtml(String(scenario.domain).toUpperCase())} capability.</p>` : subdomainCorrect ? `<p class="sdia-guided-feedback success">✓ Subdomain identified: ${escapeHtml(String(scenario.subdomain).toUpperCase())} · ${escapeHtml(scenarioSubdomainOption(scenario,scenario.subdomain).name)}</p>` : ''}</section>` : ''}
      ${domainCorrect && subdomainCorrect ? `<section class="sdia-guided-boundary-builder is-entering"><header><div><span>3 · BUILD THE GOVERNED PACKAGE</span><b>Click the tokens in the correct architectural order.</b><p>Products and protocols are deliberate distractors. They do not belong in the Package Domain Boundary.</p></div><button type="button" data-sdia-scenario-reset-build>Reset</button></header><div class="sdia-guided-token-bank">${tokenBank.map((token) => `<button type="button" data-sdia-scenario-token="${escapeHtml(token)}" ${built.includes(token) ? 'disabled' : ''}>${escapeHtml(token)}</button>`).join('')}</div><div class="sdia-guided-boundary-assembly"><span>PACKAGE BOUNDARY</span><div>${expectedTokens.map((token,index) => `<b class="${built[index] === token ? 'filled' : ''}">${escapeHtml(built[index] || '…')}</b>${index < expectedTokens.length - 1 ? '<i>.</i>' : ''}`).join('')}</div><small>${escapeHtml(discovery.feedback || `Next token: ${String(expectedTokens[nextIndex] || 'complete').toUpperCase()}`)}</small></div></section>` : ''}
      ${discovery.completed ? `<section class="sdia-guided-resolution is-entering"><header>${icon('shield')}<div><span>BOUNDARY DISCOVERED BY YOU</span><b>${escapeHtml(technicalName)}</b></div></header><div class="sdia-guided-before-after"><p class="bad"><small>✕ Product-centric</small><b>${escapeHtml(scenario.wrongPackage)}</b></p><i>→</i><p class="good"><small>✓ Domain-governed</small><b>${escapeHtml(technicalName)}</b></p></div><div class="sdia-guided-result-facts"><p><small>Business Object</small><b>${escapeHtml(scenario.result.object)}</b></p><p><small>Business Process</small><b>${escapeHtml(scenario.result.process)}</b></p><p><small>Product / Module Evidence</small><b>${escapeHtml(scenario.result.evidence)}</b></p><p><small>Execution</small><b>${escapeHtml(scenario.result.execution)}</b></p></div><p>${escapeHtml(scenario.result.explanation)}</p><strong>The Package carries the business boundary. The iFlow belongs inside that boundary and should express business intent — not vendor or protocol names.</strong></section>` : ''}
    </section>`;
  }

  function requirementStep() {
    const selected = GUIDED_SCENARIOS[runtime.scenarioId] || null;
    const scenarioCards = Object.values(GUIDED_SCENARIOS).map((scenario) => `<button type="button" class="sdia-guided-scenario-card${selected?.id === scenario.id ? ' selected' : ''}" data-sdia-guided-scenario="${escapeHtml(scenario.id)}"><span class="sdia-guided-product-logo"><img src="${escapeHtml(runtimeUrl(scenario.logo))}" alt=""><em>${escapeHtml(scenario.tag)}</em></span><span class="sdia-guided-scenario-copy"><small>${escapeHtml(scenario.product)} · ${escapeHtml(scenario.module)}</small><b>${escapeHtml(scenario.title)}</b><em>${escapeHtml(scenario.brief)}</em></span><i>→</i></button>`).join('');
    const conversation = selected ? `<section class="sdia-guided-conversation" data-sdia-scenario-conversation="${escapeHtml(selected.id)}"><header><div><span>FUNCTIONAL SPECIFICATION → ARCHITECTURE</span><b>${escapeHtml(selected.product)} · ${escapeHtml(selected.title)}</b><small>The answer is intentionally hidden. Follow the conversation, then build the boundary yourself.</small></div><button type="button" id="sdia-scenario-skip-typing">Skip typing</button></header><div class="sdia-guided-functional-spec"><span>FUNCTIONAL SPECIFICATION</span><p>${escapeHtml(selected.specification)}</p></div><div class="sdia-guided-message-stream">${selected.messages.map((message,index) => `<article class="sdia-guided-message ${runtime.scenarioConversationDone ? 'is-complete' : 'is-pending'} tone-${escapeHtml(message.tone)}" data-sdia-scenario-message="${index}"><aside><i>${icon(message.icon)}</i><span>${escapeHtml(message.role)}</span></aside><div><p data-sdia-scenario-message-text>${runtime.scenarioConversationDone ? escapeHtml(message.text) : ''}</p><span class="sdia-guided-typing-cursor" aria-hidden="true"></span></div></article>`).join('')}</div>${runtime.scenarioConversationDone ? scenarioDiscoveryMarkup(selected) : ''}</section>` : `<section class="sdia-guided-conversation is-empty"><div>${icon('journey')}</div><span>CHOOSE A BUSINESS CASE</span><b>Ten scenarios. One governance method.</b><p>Select a case. A Project Manager brings the requirement, a Developer starts technology-first, the Enterprise Architect corrects the reasoning, and you build the Domain Boundary yourself.</p><small>SAP scenarios dominate the catalog, with Salesforce and Workday proving that SDIA remains vendor-neutral.</small></section>`;
    return `<div class="sdia-guided-scenarios"><section class="sdia-guided-scenario-selector"><header><span>GUIDED SCENARIOS</span><b>Choose a real-world integration case</b><p>Do not memorize answers. Learn the reasoning pattern that survives product and technology changes.</p></header><div>${scenarioCards}</div><footer><b>Requirement → Capability → Domain → Subdomain → Boundary → Execution</b><span>Technology is valid — but it comes last.</span></footer></section>${conversation}</div>`;
  }

  function classificationStep() {
    const cards = [
      ['hr','HR','Business semantic'],['core','CORE','Business capability'],['sf','SuccessFactors Employee Central','Product evidence'],['ci','SAP Cloud Integration','Execution technology']
    ];
    const remaining = cards.filter(([id]) => !Object.values(runtime.classification).includes(id));
    const lane = (id,title,hint) => {
      const cardId = runtime.classification[id];
      const card = cards.find(([cid]) => cid === cardId);
      return `<button type="button" class="sdia-classification-lane${card ? ' filled' : ''}" data-sdia-classification-lane="${id}"><span>${title}</span><small>${hint}</small>${card ? `<b>${escapeHtml(card[1])}</b>` : '<em>Drop or click a selected card here</em>'}</button>`;
    };
    return `<div class="sdia-orientation-classification">
      <div class="sdia-classification-pool"><span>CLUES</span><p>Drag a card, or click it and then click its destination.</p><div>${remaining.map(([id,label,type]) => `<button type="button" draggable="true" data-sdia-classification-card="${id}" class="${runtime.selectedCard === id ? 'selected' : ''}"><small>${type}</small><b>${escapeHtml(label)}</b></button>`).join('') || '<strong>✓ Every clue is classified.</strong>'}</div></div>
      <i class="sdia-classification-divider">→</i>
      <div class="sdia-classification-lanes">${lane('domain','DOMAIN','Business ownership')}${lane('subdomain','SUBDOMAIN','Business capability')}${lane('evidence','PRODUCT EVIDENCE','A clue, not the boundary')}${lane('execution','EXECUTION LAYER','Technology comes last')}</div>
      <footer><b>Rule:</b> SuccessFactors is not the Domain. Cloud Integration is not the Domain. <strong>HR / CORE</strong> is the semantic boundary.</footer>
    </div>`;
  }

  function catalogStep() {
    const domains = catalogDomains();
    const selected = findDomain(runtime.catalogDomain);
    const selectedSub = findSubdomain(selected, runtime.catalogSubdomain);
    return `<div class="sdia-orientation-catalog-explorer${selected ? ' has-focus' : ''}">
      <section class="sdia-orientation-catalog-list"><header><span>CANONICAL DOMAIN CATALOG</span><b>${domains.length} business Domains</b><small>Choose the business capability family that owns the integration.</small></header><div>${domains.map((item) => `<button type="button" data-sdia-orientation-domain="${escapeHtml(item.canonicalCode)}" class="${selected?.canonicalCode === item.canonicalCode ? 'selected' : ''}"><strong>${escapeHtml(String(item.canonicalCode || '').toUpperCase())}</strong><span>${escapeHtml(item.name)}</span><em>${(item.subdomains || []).length}</em></button>`).join('')}</div></section>
      <section class="sdia-orientation-catalog-tree">${selected ? `<header><button type="button" data-sdia-catalog-clear>← Domains</button><span>DOMAIN</span><b>${escapeHtml(selected.name)}</b><small>${escapeHtml(selected.description || '')}</small></header><i></i><div>${(selected.subdomains || []).map((sub,index) => `<button type="button" style="--sdia-orientation-delay:${index * 35}ms" data-sdia-orientation-subdomain="${escapeHtml(sub.canonicalCode)}" class="${selectedSub?.canonicalCode === sub.canonicalCode ? 'selected' : ''}"><strong>${escapeHtml(String(sub.canonicalCode || '').toUpperCase())}</strong><span>${escapeHtml(sub.name)}</span></button>`).join('')}</div>${selectedSub ? `<footer><b>Selected semantic boundary</b><span>${escapeHtml(String(selected.canonicalCode).toUpperCase())} / ${escapeHtml(String(selectedSub.canonicalCode).toUpperCase())}</span><small>${escapeHtml(selectedSub.scopeDescription || '')}</small></footer>` : '<footer><small>Select a Subdomain to complete the Catalog discovery.</small></footer>'}` : '<div class="sdia-orientation-catalog-empty"><div>'+icon('catalog')+'</div><b>The Catalog answers:</b><span>“I know the business area. Which governed Subdomain should I use?”</span></div>'}</section>
    </div>`;
  }

  function moduleClueStep() {
    const selected = MODULE_CLUES[runtime.moduleClue];
    return `<div class="sdia-orientation-module-clues">
      <section class="sdia-module-clue-picker"><header><span>TECHNICAL / PRODUCT EVIDENCE</span><b>Select a familiar SAP module</b><p>The module narrows the search. It never replaces semantic analysis.</p></header><div>${Object.entries(MODULE_CLUES).map(([id,item]) => `<button type="button" data-sdia-module-clue="${id}" class="${runtime.moduleClue === id ? 'selected' : ''}"><i>${icon(item.icon)}</i><strong>${item.code}</strong><span>${escapeHtml(item.name)}</span></button>`).join('')}</div></section>
      <section class="sdia-module-clue-result">${selected ? `<header><span>${escapeHtml(selected.code)} IS EVIDENCE</span><b>Possible business boundaries depend on process intent</b></header><div>${selected.paths.map((path,index) => `<article style="--sdia-orientation-delay:${index * 90}ms"><strong>${escapeHtml(path[0])}</strong><i>→</i><strong>${escapeHtml(path[1])}</strong><span>${escapeHtml(path[2])}</span></article>`).join('')}</div><footer><b>Do not map ${escapeHtml(selected.code)} directly to one Domain.</b><span>Ask what business process the integration serves.</span></footer>` : `<div class="sdia-module-clue-empty">${icon('help')}<b>Example</b><p>MM may indicate Procurement, Logistics or even Finance depending on the process. SDIA uses the module as evidence, not as taxonomy.</p></div>`}</section>
    </div>`;
  }

  function investigatorStep() {
    const correctCount = INVESTIGATOR.filter((q) => runtime.investigator[q.id] === q.correct).length;
    return `<div class="sdia-orientation-investigator"><section class="sdia-investigator-case"><span>CASE</span><b>Created sales orders must be published from SAP S/4HANA to a fulfillment platform.</b><p>Use business questions to eliminate technical noise.</p><div class="sdia-investigator-meter"><i style="--sdia-investigator-progress:${correctCount / INVESTIGATOR.length * 100}%"></i><span>${correctCount}/${INVESTIGATOR.length} semantic signals resolved</span></div></section><section class="sdia-investigator-questions">${INVESTIGATOR.map((q,index) => `<article class="${runtime.investigator[q.id] === q.correct ? 'resolved' : ''}"><span>${String(index+1).padStart(2,'0')}</span><div><b>${escapeHtml(q.question)}</b><div>${q.options.map((option) => `<button type="button" data-sdia-investigator="${q.id}" data-value="${escapeHtml(option)}" class="${runtime.investigator[q.id] === option ? (option === q.correct ? 'correct' : 'wrong') : ''}">${escapeHtml(option)}</button>`).join('')}</div></div></article>`).join('')}</section>${correctCount === INVESTIGATOR.length ? '<footer><span>SUGGESTED BOUNDARY</span><b>SALES → OTC</b><small>Business object + process + owner + module evidence + intent all point to the same semantic boundary.</small></footer>' : ''}</div>`;
  }

  function builderStep() {
    const domains = catalogDomains();
    const selectedDomain = findDomain(runtime.builder.domain);
    const selectedSubdomain = findSubdomain(selectedDomain, runtime.builder.subdomain);
    const parts = [runtime.builder.company, runtime.builder.division, selectedDomain?.canonicalCode, selectedSubdomain?.canonicalCode, 'integrations'].filter(Boolean).map(normalizeToken);
    const technicalName = selectedDomain && selectedSubdomain ? parts.join('.') : 'Select Domain and Subdomain';
    return `<div class="sdia-orientation-builder">
      <section class="sdia-builder-controls"><header><span>BOUNDARY INPUT</span><b>Build a governed package identity</b></header><div class="sdia-builder-fields"><label><span>Company <small>optional</small></span><input id="sdia-orientation-company" value="${escapeHtml(runtime.builder.company)}" maxlength="12"></label><label><span>Division <small>optional</small></span><input id="sdia-orientation-division" value="${escapeHtml(runtime.builder.division)}" maxlength="12"></label><label><span>Domain</span><select id="sdia-orientation-builder-domain"><option value="">Select Domain</option>${domains.map((item) => `<option value="${escapeHtml(item.canonicalCode)}" ${selectedDomain?.canonicalCode === item.canonicalCode ? 'selected' : ''}>${escapeHtml(String(item.canonicalCode).toUpperCase())} · ${escapeHtml(item.name)}</option>`).join('')}</select></label><label><span>Subdomain</span><select id="sdia-orientation-builder-subdomain" ${selectedDomain ? '' : 'disabled'}><option value="">Select Subdomain</option>${(selectedDomain?.subdomains || []).map((item) => `<option value="${escapeHtml(item.canonicalCode)}" ${selectedSubdomain?.canonicalCode === item.canonicalCode ? 'selected' : ''}>${escapeHtml(String(item.canonicalCode).toUpperCase())} · ${escapeHtml(item.name)}</option>`).join('')}</select></label></div></section>
      <section class="sdia-builder-live"><span>LIVE DOMAIN BOUNDARY</span><div class="sdia-builder-stack">${runtime.builder.company ? `<article><small>COMPANY</small><b>${escapeHtml(runtime.builder.company.toUpperCase())}</b></article><i></i>` : ''}${runtime.builder.division ? `<article><small>DIVISION</small><b>${escapeHtml(runtime.builder.division.toUpperCase())}</b></article><i></i>` : ''}${selectedDomain ? `<article class="is-semantic"><small>DOMAIN</small><b>${escapeHtml(String(selectedDomain.canonicalCode).toUpperCase())}</b><span>${escapeHtml(selectedDomain.name)}</span></article><i></i>` : '<article class="is-pending"><small>DOMAIN</small><b>SELECT</b></article><i></i>'}${selectedSubdomain ? `<article class="is-semantic"><small>SUBDOMAIN</small><b>${escapeHtml(String(selectedSubdomain.canonicalCode).toUpperCase())}</b><span>${escapeHtml(selectedSubdomain.name)}</span></article><i></i>` : '<article class="is-pending"><small>SUBDOMAIN</small><b>SELECT</b></article><i></i>'}<article class="is-package"><small>PACKAGE BOUNDARY</small><b>${escapeHtml(technicalName)}</b></article></div></section>
    </div>`;
  }

  function executionStep() {
    const choices = [
      ['orchestration','Orchestration','Cloud Integration','packages','Coordinate transformations, mappings, calls and process steps.'],
      ['api','API','API Management','proxy','Expose, protect and govern synchronous API access.'],
      ['event','Event','Event Mesh / AEM','eventmesh','Publish or consume asynchronous business events.']
    ];
    const active = choices.find(([id]) => id === runtime.execution);
    return `<div class="sdia-orientation-execution-choice"><section class="sdia-execution-boundary"><span>BOUNDARY ALREADY DECIDED</span><b>SALES / OTC</b><small>Now — and only now — choose how it needs to execute.</small></section><i class="sdia-execution-choice-arrow">↓</i><section class="sdia-execution-choice-grid">${choices.map(([id,title,product,iconName,detail]) => `<button type="button" data-sdia-execution="${id}" class="${runtime.execution === id ? 'selected' : ''}"><i>${icon(iconName)}</i><span>${escapeHtml(title)}</span><b>${escapeHtml(product)}</b><small>${escapeHtml(detail)}</small></button>`).join('')}</section>${active ? `<footer><span>EXECUTION DECISION</span><b>${escapeHtml(active[1])} → ${escapeHtml(active[2])}</b><small>The Domain Boundary survives even if the execution technology changes later.</small></footer>` : ''}</div>`;
  }

  function complianceStep() {
    const choice = runtime.complianceChoice;
    return `<div class="sdia-orientation-compliance"><section class="sdia-compliance-simulation"><header><div>${icon('shield')}</div><span>SDIA COMPLIANCE WARNING</span><b>This change is outside SDIA compliance.</b></header><div><p><span>Expected</span><b>var.hr.core.integrations</b></p><p class="is-current"><span>Current</span><b>whatever.package.name</b></p></div><aside>⚠ The user can continue, but the package may be detected as Unclassified / Ungoverned.</aside><footer><button type="button" data-sdia-compliance="review">No · Review</button><button type="button" data-sdia-compliance="continue" class="sdia-primary-action">Yes · Continue Anyway</button></footer></section><section class="sdia-compliance-principle">${choice === 'review' ? `<div class="is-safe">${icon('shield')}<span>REVIEW</span><b>The user returns to the form and keeps the governed boundary.</b></div>` : choice === 'continue' ? `<div class="is-advisory">${icon('assessment')}<span>ADVISORY GOVERNANCE</span><b>SDIA allows the Save. Assessment will surface the deviation later.</b></div>` : `<div>${icon('help')}<span>PRINCIPLE</span><b>Governance must inform and protect architecture without hijacking the SAP platform.</b></div>`}<p><strong>SDIA governs.</strong> It does not imprison the platform.</p></section></div>`;
  }

  function missionStep() {
    const domainChoices = [['HR','Human Resources'],['SALES','Sales'],['FIN','Finance']];
    const subdomainChoices = [['CORE','Employee Core'],['OTC','Order to Cash'],['RTR','Record to Report']];
    const executionChoices = [['ci','Cloud Integration'],['api','API Management'],['event','Event Mesh / AEM']];
    const chooser = (key, choices) => `<div class="sdia-mission-choices">${choices.map(([value,label]) => `<button type="button" data-sdia-mission-key="${key}" data-value="${value}" class="${runtime.mission[key] === value ? 'selected' : ''}"><strong>${escapeHtml(value.toUpperCase())}</strong><span>${escapeHtml(label)}</span></button>`).join('')}</div>`;
    return `<div class="sdia-orientation-mission"><section class="sdia-mission-brief"><span>FINAL MISSION</span><b>Replicate created sales orders from SAP S/4HANA SD to an external fulfillment platform using an event-driven architecture.</b><p>Apply the SDIA method. Do not start with the technology.</p></section><section class="sdia-mission-decision"><article><span>1 · DOMAIN</span>${chooser('domain',domainChoices)}</article><article><span>2 · SUBDOMAIN</span>${chooser('subdomain',subdomainChoices)}</article><article><span>3 · EXECUTION NEED</span>${chooser('execution',executionChoices)}</article></section><section class="sdia-mission-result ${runtime.mission.passed ? 'passed' : ''}">${runtime.mission.passed ? `<div>${icon('shield')}</div><span>SEMANTIC DECISION VERIFIED</span><b>SALES → OTC → Event Mesh / AEM</b><p>Business intent produced the boundary. Technology was selected last.</p><button type="button" id="sdia-orientation-activate" class="sdia-primary-action">${runtime.completed ? '✓ SDIA Governance Active' : 'Activate SDIA Governance'}</button>` : `<button type="button" id="sdia-orientation-validate" class="sdia-primary-action">Validate Decision</button><small id="sdia-mission-feedback">${escapeHtml(runtime.mission.feedback || 'Choose one value in each dimension.')}</small>`}</section></div>`;
  }

  function markStepComplete(index, value=true) {
    runtime.stepComplete[index] = Boolean(value);
    renderProgress();
    updateFooter();
  }

  function bindStep(index) {
    if (!state.overlay) return;
    if (index === 1) bindRequirement();
    else if (index === 2) bindClassification();
    else if (index === 3) bindCatalog();
    else if (index === 4) bindModuleClues();
    else if (index === 5) bindInvestigator();
    else if (index === 6) bindBuilder();
    else if (index === 7) bindExecution();
    else if (index === 8) bindCompliance();
    else if (index === 9) bindMission();
  }

  function bindRequirement() {
    state.overlay.querySelectorAll('[data-sdia-guided-scenario]').forEach((button) => button.addEventListener('click', () => {
      runtime.scenarioId = button.dataset.sdiaGuidedScenario;
      runtime.scenarioConversationDone = false;
      runtime.scenarioPlaybackToken += 1;
      runtime.scenarioDiscovery = { domain:'', subdomain:'', build:[], feedback:'', completed:false };
      render();
    }));
    state.overlay.querySelector('#sdia-scenario-skip-typing')?.addEventListener('click', () => finishScenarioTyping(true));
    state.overlay.querySelectorAll('[data-sdia-scenario-domain]').forEach((button) => button.addEventListener('click', () => {
      const scenario = GUIDED_SCENARIOS[runtime.scenarioId];
      runtime.scenarioDiscovery.domain = button.dataset.sdiaScenarioDomain || '';
      runtime.scenarioDiscovery.subdomain = '';
      runtime.scenarioDiscovery.build = [];
      runtime.scenarioDiscovery.completed = false;
      runtime.scenarioDiscovery.feedback = runtime.scenarioDiscovery.domain === String(scenario?.domain || '').toUpperCase() ? 'Domain confirmed. Now resolve the Subdomain.' : 'Use the business process — not the product name.';
      render();
    }));
    state.overlay.querySelectorAll('[data-sdia-scenario-subdomain]').forEach((button) => button.addEventListener('click', () => {
      const scenario = GUIDED_SCENARIOS[runtime.scenarioId];
      runtime.scenarioDiscovery.subdomain = button.dataset.sdiaScenarioSubdomain || '';
      runtime.scenarioDiscovery.build = [];
      runtime.scenarioDiscovery.completed = false;
      runtime.scenarioDiscovery.feedback = runtime.scenarioDiscovery.subdomain === String(scenario?.subdomain || '').toUpperCase() ? 'Subdomain confirmed. Build the Package Boundary.' : 'Look at the specific business capability inside the Domain.';
      render();
    }));
    state.overlay.querySelectorAll('[data-sdia-scenario-token]').forEach((button) => button.addEventListener('click', () => {
      const scenario = GUIDED_SCENARIOS[runtime.scenarioId];
      if (!scenario) return;
      const expected = scenarioExpectedTokens(scenario);
      const token = normalizeToken(button.dataset.sdiaScenarioToken || '');
      const build = runtime.scenarioDiscovery.build || (runtime.scenarioDiscovery.build = []);
      const expectedNext = expected[build.length];
      if (token !== expectedNext) {
        const technicalNoise = ['rest','soap','odata','json','xml','xslt','groovy','idoc'].includes(token) || normalizeToken(scenario.product) === token || normalizeToken(scenario.module) === token;
        runtime.scenarioDiscovery.feedback = technicalNoise ? 'That token belongs to product/technology evidence — not to the Domain Boundary.' : `Expected the next semantic token, not “${token}”.`;
        const assembly = state.overlay.querySelector('.sdia-guided-boundary-assembly');
        assembly?.classList.add('error'); setTimeout(() => assembly?.classList.remove('error'), 480);
        const feedback = assembly?.querySelector('small'); if (feedback) feedback.textContent = runtime.scenarioDiscovery.feedback;
        return;
      }
      build.push(token);
      runtime.scenarioDiscovery.feedback = build.length === expected.length ? 'Governed Package Boundary completed.' : `Good. Next: ${String(expected[build.length]).toUpperCase()}`;
      if (build.length === expected.length) {
        runtime.scenarioDiscovery.completed = true;
        markStepComplete(1);
      }
      render();
    }));
    state.overlay.querySelector('[data-sdia-scenario-reset-build]')?.addEventListener('click', () => {
      runtime.scenarioDiscovery.build = [];
      runtime.scenarioDiscovery.completed = false;
      runtime.scenarioDiscovery.feedback = 'Build the boundary again from semantic tokens.';
      markStepComplete(1, false);
      render();
    });
    if (runtime.scenarioId && !runtime.scenarioConversationDone) startScenarioTyping();
  }

  function startScenarioTyping() {
    const scenario = GUIDED_SCENARIOS[runtime.scenarioId];
    if (!scenario || runtime.scenarioConversationDone || !state.overlay) return;
    const token = ++runtime.scenarioPlaybackToken;
    const articles = [...state.overlay.querySelectorAll('[data-sdia-scenario-message]')];
    let messageIndex = 0;
    const typeMessage = () => {
      if (token !== runtime.scenarioPlaybackToken || !state.overlay?.isConnected) return;
      const message = scenario.messages[messageIndex];
      const article = articles[messageIndex];
      if (!message || !article) { finishScenarioTyping(false, token); return; }
      article.classList.remove('is-pending'); article.classList.add('is-active');
      const target = article.querySelector('[data-sdia-scenario-message-text]');
      let charIndex = 0;
      const tick = () => {
        if (token !== runtime.scenarioPlaybackToken || !target?.isConnected) return;
        charIndex = Math.min(message.text.length, charIndex + 2);
        target.textContent = message.text.slice(0, charIndex);
        if (charIndex < message.text.length) { setTimeout(tick, 10); return; }
        article.classList.remove('is-active'); article.classList.add('is-complete');
        messageIndex += 1;
        setTimeout(typeMessage, 240);
      };
      tick();
    };
    typeMessage();
  }

  // Cancels any in-flight scenario typing loop without marking the conversation
  // as done. Called by the workspace shell when the how-to module is hidden
  // (module switch / Control Center close) so pending setTimeout chains stop
  // instead of writing into hidden nodes. The in-flight ticks already guard on
  // the playback token and node.isConnected; this simply invalidates the token.
  function suspendPlayback() {
    runtime.scenarioPlaybackToken += 1;
  }

  function finishScenarioTyping(skip=false, expectedToken=null) {
    if (expectedToken !== null && expectedToken !== runtime.scenarioPlaybackToken) return;
    const scenario = GUIDED_SCENARIOS[runtime.scenarioId];
    if (!scenario || !state.overlay) return;
    runtime.scenarioPlaybackToken += 1;
    state.overlay.querySelectorAll('[data-sdia-scenario-message]').forEach((article,index) => {
      article.classList.remove('is-pending','is-active'); article.classList.add('is-complete');
      const target = article.querySelector('[data-sdia-scenario-message-text]');
      if (target) target.textContent = scenario.messages[index]?.text || '';
    });
    runtime.scenarioConversationDone = true;
    render();
  }

  function bindClassification() {
    const expected = { domain:'hr', subdomain:'core', evidence:'sf', execution:'ci' };
    const tryPlace = (cardId, laneId) => {
      const lane = state.overlay.querySelector(`[data-sdia-classification-lane="${laneId}"]`);
      if (expected[laneId] !== cardId) {
        lane?.classList.add('error'); setTimeout(() => lane?.classList.remove('error'), 650); return;
      }
      runtime.classification[laneId] = cardId; runtime.selectedCard = '';
      if (Object.keys(expected).every((key) => runtime.classification[key] === expected[key])) markStepComplete(2);
      render();
    };
    state.overlay.querySelectorAll('[data-sdia-classification-card]').forEach((card) => {
      card.addEventListener('click', () => { runtime.selectedCard = card.dataset.sdiaClassificationCard; render(); });
      card.addEventListener('dragstart', (event) => { event.dataTransfer?.setData('text/sdia-card', card.dataset.sdiaClassificationCard); });
    });
    state.overlay.querySelectorAll('[data-sdia-classification-lane]').forEach((lane) => {
      lane.addEventListener('dragover', (event) => event.preventDefault());
      lane.addEventListener('drop', (event) => { event.preventDefault(); tryPlace(event.dataTransfer?.getData('text/sdia-card'), lane.dataset.sdiaClassificationLane); });
      lane.addEventListener('click', () => { if (runtime.selectedCard) tryPlace(runtime.selectedCard, lane.dataset.sdiaClassificationLane); });
    });
  }

  function bindCatalog() {
    state.overlay.querySelectorAll('[data-sdia-orientation-domain]').forEach((button) => button.addEventListener('click', () => {
      runtime.catalogDomain = button.dataset.sdiaOrientationDomain; runtime.catalogSubdomain = ''; render();
    }));
    state.overlay.querySelectorAll('[data-sdia-orientation-subdomain]').forEach((button) => button.addEventListener('click', () => {
      runtime.catalogSubdomain = button.dataset.sdiaOrientationSubdomain; markStepComplete(3); render();
    }));
    state.overlay.querySelector('[data-sdia-catalog-clear]')?.addEventListener('click', () => { runtime.catalogDomain = ''; runtime.catalogSubdomain = ''; render(); });
  }

  function bindModuleClues() {
    state.overlay.querySelectorAll('[data-sdia-module-clue]').forEach((button) => button.addEventListener('click', () => {
      runtime.moduleClue = button.dataset.sdiaModuleClue; markStepComplete(4); render();
    }));
  }

  function bindInvestigator() {
    state.overlay.querySelectorAll('[data-sdia-investigator]').forEach((button) => button.addEventListener('click', () => {
      const id = button.dataset.sdiaInvestigator;
      runtime.investigator[id] = button.dataset.value;
      const complete = INVESTIGATOR.every((q) => runtime.investigator[q.id] === q.correct);
      if (complete) markStepComplete(5);
      render();
    }));
  }

  function bindBuilder() {
    const company = state.overlay.querySelector('#sdia-orientation-company');
    const division = state.overlay.querySelector('#sdia-orientation-division');
    const domain = state.overlay.querySelector('#sdia-orientation-builder-domain');
    const subdomain = state.overlay.querySelector('#sdia-orientation-builder-subdomain');
    const update = () => {
      runtime.builder.company = normalizeToken(company?.value || '');
      runtime.builder.division = normalizeToken(division?.value || '');
      runtime.builder.domain = domain?.value || '';
      if (!findDomain(runtime.builder.domain)) runtime.builder.subdomain = '';
      else runtime.builder.subdomain = subdomain?.value || runtime.builder.subdomain;
      const complete = Boolean(findDomain(runtime.builder.domain) && findSubdomain(findDomain(runtime.builder.domain), runtime.builder.subdomain));
      if (complete) markStepComplete(6);
      render();
    };
    company?.addEventListener('change', update); division?.addEventListener('change', update);
    domain?.addEventListener('change', () => { runtime.builder.domain = domain.value; runtime.builder.subdomain = ''; render(); });
    subdomain?.addEventListener('change', () => { runtime.builder.subdomain = subdomain.value; if (runtime.builder.subdomain) markStepComplete(6); render(); });
  }

  function bindExecution() {
    state.overlay.querySelectorAll('[data-sdia-execution]').forEach((button) => button.addEventListener('click', () => {
      runtime.execution = button.dataset.sdiaExecution; markStepComplete(7); render();
    }));
  }

  function bindCompliance() {
    state.overlay.querySelectorAll('[data-sdia-compliance]').forEach((button) => button.addEventListener('click', () => {
      runtime.complianceChoice = button.dataset.sdiaCompliance; markStepComplete(8); render();
    }));
  }

  function bindMission() {
    state.overlay.querySelectorAll('[data-sdia-mission-key]').forEach((button) => button.addEventListener('click', () => {
      runtime.mission[button.dataset.sdiaMissionKey] = button.dataset.value; runtime.mission.passed = false; runtime.mission.feedback = ''; render();
    }));
    state.overlay.querySelector('#sdia-orientation-validate')?.addEventListener('click', () => {
      const ok = runtime.mission.domain === 'SALES' && runtime.mission.subdomain === 'OTC' && runtime.mission.execution === 'event';
      runtime.mission.passed = ok;
      runtime.mission.feedback = ok ? '' : 'Re-read the business intent: Sales Order + Order to Cash + event-driven execution.';
      if (ok) markStepComplete(9);
      render();
    });
    state.overlay.querySelector('#sdia-orientation-activate')?.addEventListener('click', async () => {
      if (!runtime.mission.passed) return;
      await persistCompletion();
      markStepComplete(9);
      render();
      SDIA.Workspace?.showToast?.('SDIA Governance activated. Operational governance capabilities are now available.', 5200);
    });
  }

  function bindShell() {
    if (!state.overlay || state.overlay.dataset.sdiaOrientationBound === '1') return;
    state.overlay.dataset.sdiaOrientationBound = '1';
    state.overlay.querySelector('#sdia-orientation-back')?.addEventListener('click', () => { if (runtime.step > 0) { runtime.step -= 1; render(); } });
    state.overlay.querySelector('#sdia-orientation-next')?.addEventListener('click', () => {
      const canAdvance = runtime.step === 0 || runtime.stepComplete[runtime.step] || runtime.completed;
      if (!canAdvance || runtime.step >= TOTAL_STEPS - 1) return;
      if (runtime.step === 0) runtime.stepComplete[0] = true;
      runtime.step += 1; render();
    });
  }

  function onModuleOpen() { bindShell(); render(); }

  void init();
  SDIA.Orientation = Object.freeze({ STORAGE_KEY, TOTAL_STEPS, init, snapshot, isCompleted, requiresCompletion, markup, render:onModuleOpen, resetJourneyProgress, persistCompletion, suspendPlayback });
})();
