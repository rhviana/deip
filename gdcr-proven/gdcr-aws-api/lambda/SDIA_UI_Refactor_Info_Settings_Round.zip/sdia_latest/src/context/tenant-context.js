/* SDIA Governance — tenant context resolver.
 * Reads the authenticated Integration Suite landing capability endpoint and
 * normalizes the tenant/subaccount identity for popup and future licensing.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};

  const CACHE_TTL_MS = 120000;
  let cache = null;
  let cacheTs = 0;

  function normalize(payload = {}) {
    const activeCapabilities = Array.isArray(payload.activeCapabilities) ? payload.activeCapabilities : [];
    const seed = activeCapabilities.find((item) => item && (item.subdomainId || item.tenantId)) || {};
    return Object.freeze({
      host: location.hostname,
      subaccount: String(seed.subdomainId || payload.subdomainId || '').trim(),
      tenantId: String(seed.tenantId || payload.tenantId || '').trim(),
      planName: String(payload.planName || seed.appPlan || '').trim(),
      provisioner: Boolean(payload.provisioner),
      capabilityNames: Object.freeze(activeCapabilities.map((item) => String(item?.capabilityName || '').trim()).filter(Boolean)),
      capabilityCount: activeCapabilities.length
    });
  }

  async function fetchTenantContext(force = false) {
    if (!force && cache && (Date.now() - cacheTs) < CACHE_TTL_MS) return cache;
    const response = await fetch('/manageTenant/is-landing/v1.0/usercapabilities', {
      method: 'GET',
      credentials: 'include',
      cache: 'no-store',
      headers: { 'Accept': 'application/json' }
    });
    if (!response.ok) throw new Error(`Tenant context request failed (${response.status}).`);
    const payload = await response.json();
    cache = normalize(payload);
    cacheTs = Date.now();
    return cache;
  }

  SDIA.TenantContext = Object.freeze({ get: fetchTenantContext, normalize });
})();
