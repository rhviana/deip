/* SDIA Governance — active user context resolver.
 * Reads the Integration Suite user endpoint under the current authenticated
 * session and normalizes the identity for popup and future licensing.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};

  const CACHE_TTL_MS = 120000;
  let cache = null;
  let cacheTs = 0;

  function cleanIdentity(value) {
    const raw = String(value || '').trim();
    const markdownMail = raw.match(/\[([^\]]+)\]\(mailto:[^)]+\)/i);
    if (markdownMail) return markdownMail[1].trim();
    return raw.replace(/^mailto:/i, '').trim();
  }

  function normalizeRecord(record = {}) {
    const firstName = String(record.FirstName || '').trim();
    const lastName = String(record.LastName || '').trim();
    const fullName = `${firstName} ${lastName}`.trim() || cleanIdentity(record.Name);
    return Object.freeze({
      userId: cleanIdentity(record.Name),
      email: cleanIdentity(record.Email),
      firstName,
      lastName,
      fullName,
      loggedOut: Boolean(record.LoggedOut)
    });
  }

  async function fetchUserContext(force = false) {
    if (!force && cache && (Date.now() - cacheTs) < CACHE_TTL_MS) return cache;
    const response = await fetch('/api/1.0/user', {
      method: 'GET',
      credentials: 'include',
      cache: 'no-store',
      headers: { 'Accept': 'application/json' }
    });
    if (!response.ok) throw new Error(`User context request failed (${response.status}).`);
    const payload = await response.json();
    const record = Array.isArray(payload) ? payload[0] || {} : payload || {};
    cache = normalizeRecord(record);
    cacheTs = Date.now();
    return cache;
  }

  SDIA.UserContext = Object.freeze({ get: fetchUserContext, normalizeRecord, cleanIdentity });
})();
