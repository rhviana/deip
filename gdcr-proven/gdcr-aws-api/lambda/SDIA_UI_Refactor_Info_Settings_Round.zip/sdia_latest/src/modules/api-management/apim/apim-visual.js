/* SDIA — API Management Control Plane visual configuration. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const CONFIG = Object.freeze({
    scope:'apim', type:'apim',
    eyebrow:'API MANAGEMENT',
    title:'Secure APIs with Domain Control',
    accent:'Domain Control',
    description:'Apply domain policies, deterministic facade naming and gateway governance across the API lifecycle without owning native SAP execution.',
    assetDir:'src/modules/api-management/apim/assets/control-plane',
    footerTitle:'SDIA — API Management Control Plane',
    footerMeta:'Policies · Contracts · Security · Compliance'
  });
  SDIA.VisualExperience.register(CONFIG.scope, CONFIG);
  SDIA.ApiManagementControlPlaneVisual = Object.freeze({ markup:()=>SDIA.ControlPlaneVisual.markup(CONFIG), config:CONFIG });
})();
