/* SDIA Governance v1.0.0 — API Management / GDCR workspace only. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { icon } = SDIA.Core;
  function apimMarkup() {
    return `
      <section class="sdia-module sdia-hidden" data-sdia-view="apim">
        ${SDIA.ApiManagementControlPlaneVisual.markup()}
        <div class="sdia-choice-grid sdia-capability-choice-grid">
          <button type="button" data-sdia-action="apim-assess"><i>${icon('assessment')}</i><div><b>Assess API Management</b><p>Review API proxy names, base paths, domain coverage and gateway governance consistency.</p><span>Open assessment workspace →</span></div></button>
          <button type="button" data-sdia-action="apim-naming"><i>${icon('proxy')}</i><div><b>Govern API Proxy Naming</b><p>Validate the Domain-Centric facade name and URL boundary. SDIA does not create the API Proxy.</p><span>Open naming governance →</span></div></button>
          <button type="button" data-sdia-action="apim-ddcr-policy"><i>${icon('policy')}</i><div><b>DDCR JavaScript Policy</b><p>Prepare the deterministic DDCR JavaScript policy for manual import into the existing API Proxy.</p><span>Open DDCR policy model →</span></div></button>
          <button type="button" data-sdia-action="apim-kvm"><i>${icon('keyvalue')}</i><div><b>KVM Endpoint-Destination Keys</b><p>Prepare governed key/value entries used by DDCR to resolve destination endpoints. SDIA does not provision the Proxy.</p><span>Open KVM key model →</span></div></button>
          <button type="button" data-sdia-action="apim-routing"><i>${icon('policy')}</i><div><b>Review GDCR + DDCR Routing</b><p>Inspect facade naming, deterministic route continuity and destination-key resolution.</p><span>Open routing governance →</span></div></button>
        </div>
        <div class="sdia-scope-banner"><b>Read-only APIM inventory mapped</b><span>SDIA reads API Providers, KeyMapEntries and CertificateStores for governance observability. It does not create API Proxies. DDCR remains the only generated operational asset: JavaScript policy for manual import plus endpoint-destination KVM model.</span></div>
      </section>`;
  }

  function handleAction(action) {
    if (action === 'apim-assess') { SDIA.Workspace.switchModule('assessment'); return true; }
    if (action === 'apim-naming') { SDIA.Workspace.openCapabilityAction('API Proxy Naming','Domain, Entity, Action, Semantic Target and URL Facade','SDIA validates the governed facade identity only. API Proxy creation remains a native SAP/user responsibility.'); return true; }
    if (action === 'apim-ddcr-policy') { SDIA.Workspace.openCapabilityAction('DDCR JavaScript Policy','Domain Route, KVM Lookup Key, Destination Resolution and Fallback','Prepare the DDCR JavaScript policy as a manual-import asset. SDIA does not create or save the API Proxy.'); return true; }
    if (action === 'apim-kvm') { SDIA.Workspace.openCapabilityAction('KVM Endpoint-Destination Keys','Domain Route Key, Destination Endpoint, Scope and Resolution Purpose','Prepare only the endpoint-destination key model consumed by DDCR. Native KVM persistence remains under SAP/user control.'); return true; }
    if (action === 'apim-routing') { SDIA.Workspace.openCapabilityAction('GDCR Routing Review','Domain Route, Entity, Action, Target and Technical Binding','This workspace will compare semantic facade routes against deterministic gateway metadata.'); return true; }
    return false;
  }
  SDIA.ApiManagement = Object.freeze({ markup:apimMarkup, handleAction });
})();
