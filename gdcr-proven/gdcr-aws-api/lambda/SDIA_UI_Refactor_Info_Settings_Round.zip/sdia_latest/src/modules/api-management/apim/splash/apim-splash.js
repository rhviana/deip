/* SDIA API Management — APIM transition splash. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { runtimeUrl } = SDIA.Core;
  SDIA.NavigationExperience.register('open-apim', {
    eyebrow:'API MANAGEMENT · GDCR / DDCR',
    title:'Preparing APIM Governance',
    subtitle:'SDIA loads the gateway execution context while preserving the Domain façade and deterministic routing perspective.',
    sceneMarkup:() => `<div class="sdia-apim-splash-scene"><span class="sdia-apim-source">API</span><span class="sdia-apim-line left"><i></i></span><span class="sdia-apim-gateway"><img src="${runtimeUrl('src/modules/api-management/apim/splash/assets/apim.png')}" alt=""></span><span class="sdia-apim-line right"><i></i></span><span class="sdia-apim-target">DOMAIN</span><span class="sdia-apim-shield"><img src="${runtimeUrl('src/shared/brand/assets/icon128.png')}" alt=""></span></div>`
  });
})();
