/* SDIA — Certificate / Keystore Control Plane visual configuration. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const CONFIG = Object.freeze({
    scope:'certificate', type:'certificate',
    eyebrow:'CERTIFICATES / KEYSTORE',
    title:'Govern Certificates with Domain Trust',
    accent:'Domain Trust',
    description:'Govern certificate and key-pair aliases while certificate payloads and private keys remain entirely inside native SAP security stores.',
    assetDir:'src/modules/security/keystore/assets/control-plane',
    footerTitle:'SDIA — Certificate Control Plane',
    footerMeta:'Certificates · Keystore · Trust · Expiry · Compliance'
  });
  SDIA.VisualExperience.register(CONFIG.scope, CONFIG);
  SDIA.KeystoreControlPlaneVisual = Object.freeze({ markup:()=>SDIA.ControlPlaneVisual.markup(CONFIG), config:CONFIG });
})();
