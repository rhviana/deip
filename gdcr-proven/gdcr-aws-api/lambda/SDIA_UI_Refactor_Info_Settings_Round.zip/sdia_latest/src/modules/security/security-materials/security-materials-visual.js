/* SDIA — Security Materials / Credentials Control Plane visual configuration. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const CONFIG = Object.freeze({
    scope:'credentials', type:'credentials',
    eyebrow:'SECURITY MATERIALS',
    title:'Govern Credentials with Domain Identity',
    accent:'Domain Identity',
    description:'Govern aliases and semantic ownership for credentials and security materials without reading or storing secret values.',
    assetDir:'src/modules/security/security-materials/assets/control-plane',
    footerTitle:'SDIA — Credentials Control Plane',
    footerMeta:'Credentials · Security Materials · Ownership · Access Control'
  });
  SDIA.VisualExperience.register(CONFIG.scope, CONFIG);
  SDIA.SecurityMaterialsControlPlaneVisual = Object.freeze({ markup:()=>SDIA.ControlPlaneVisual.markup(CONFIG), config:CONFIG });
})();
