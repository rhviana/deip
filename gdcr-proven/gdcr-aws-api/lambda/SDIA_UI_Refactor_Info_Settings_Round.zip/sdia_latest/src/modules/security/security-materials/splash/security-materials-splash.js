/* SDIA Security Materials — credentials transition splash. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { runtimeUrl } = SDIA.Core;
  SDIA.NavigationExperience.register('open-security-materials', {
    eyebrow:'SECURITY MATERIALS · SDIA',
    title:'Preparing Security Materials',
    subtitle:'SDIA opens the native credentials context while the Control Plane keeps the governed security perspective in front.',
    sceneMarkup:() => `<div class="sdia-security-splash-scene"><span class="sdia-security-token"><img src="${runtimeUrl('src/modules/security/security-materials/splash/assets/credential.png')}" alt=""></span><span class="sdia-security-vault"><img src="${runtimeUrl('src/shared/brand/assets/icon128.png')}" alt=""></span><i></i></div>`
  });
})();
