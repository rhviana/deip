/* SDIA Keystore — certificates transition splash. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { runtimeUrl } = SDIA.Core;
  SDIA.NavigationExperience.register('open-keystore', {
    eyebrow:'CERTIFICATES / KEYSTORE · SDIA',
    title:'Preparing Certificate Governance',
    subtitle:'SDIA opens the native Keystore while certificate material remains framed by the governed Control Plane.',
    sceneMarkup:() => `<div class="sdia-keystore-splash-scene"><span class="sdia-keystore-certificate"><img src="${runtimeUrl('src/modules/security/keystore/splash/assets/certificate.png')}" alt=""></span><span class="sdia-keystore-slot"><i></i><b></b></span><span class="sdia-keystore-shield"><img src="${runtimeUrl('src/shared/brand/assets/icon128.png')}" alt=""></span></div>`
  });
})();
