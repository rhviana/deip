/* SDIA Event Mesh / AEM — governed event transition splash. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { runtimeUrl } = SDIA.Core;
  SDIA.NavigationExperience.register('open-eventmesh', {
    eyebrow:'EVENT MESH / AEM · EDCP',
    title:'Preparing EM / AEM Governance',
    subtitle:'SDIA loads the event execution context while Domain identity remains continuous across queues, topics and event channels.',
    sceneMarkup:() => `<div class="sdia-event-splash-scene"><span class="sdia-event-center"><img src="${runtimeUrl('src/modules/event-mesh/eventmesh/splash/assets/eventmesh.png')}" alt=""></span><i class="n1"></i><i class="n2"></i><i class="n3"></i><i class="n4"></i><b class="p1"></b><b class="p2"></b><b class="p3"></b><b class="p4"></b><span class="sdia-event-shield"><img src="${runtimeUrl('src/shared/brand/assets/icon128.png')}" alt=""></span></div>`
  });
})();
