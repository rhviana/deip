/* SDIA — Event Mesh / AEM Control Plane visual configuration. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const CONFIG = Object.freeze({
    scope:'eventmesh', type:'eventmesh',
    eyebrow:'EVENT MESH / AEM',
    title:'Event-Driven with Domain Semantics',
    accent:'Domain Semantics',
    description:'Govern event channels, namespaces, queues, topics and subscriptions while preserving semantic Domain identity across event-driven execution.',
    assetDir:'src/modules/event-mesh/eventmesh/assets/control-plane',
    footerTitle:'SDIA — Event Mesh / AEM Control Plane',
    footerMeta:'Events · Channels · Schema · Governance'
  });
  SDIA.VisualExperience.register(CONFIG.scope, CONFIG);
  SDIA.EventMeshControlPlaneVisual = Object.freeze({ markup:()=>SDIA.ControlPlaneVisual.markup(CONFIG), config:CONFIG });
})();
