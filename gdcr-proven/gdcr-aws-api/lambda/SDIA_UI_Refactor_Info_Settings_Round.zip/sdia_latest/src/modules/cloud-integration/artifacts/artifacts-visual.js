/* SDIA — Package Artifacts Control Plane visual configuration. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const CONFIG = Object.freeze({
    scope:'artifacts', type:'artifacts',
    eyebrow:'PACKAGE ARTIFACTS',
    title:'Govern Artifacts with Domain Continuity',
    accent:'Domain Continuity',
    description:'Keep iFlows, mappings, scripts, KVMs and reusable resources semantically bound to the active Domain Package.',
    assetDir:'src/modules/cloud-integration/artifacts/assets/control-plane',
    footerTitle:'SDIA — Package Artifacts Control Plane',
    footerMeta:'iFlow · Mapping · Script · KVM · Resources'
  });
  SDIA.VisualExperience.register(CONFIG.scope, CONFIG);
  SDIA.PackageArtifactsControlPlaneVisual = Object.freeze({ markup:()=>SDIA.ControlPlaneVisual.markup(CONFIG), config:CONFIG });
})();
