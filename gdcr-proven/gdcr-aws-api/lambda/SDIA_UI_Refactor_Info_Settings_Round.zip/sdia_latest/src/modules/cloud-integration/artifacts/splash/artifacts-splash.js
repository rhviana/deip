/* SDIA Cloud Integration — Create Package Artefacts transition splash. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { runtimeUrl } = SDIA.Core;
  SDIA.NavigationExperience.register('create-artifacts', {
    eyebrow:'CLOUD INTEGRATION · ODCP',
    title:'Preparing Package Artefacts',
    subtitle:'SDIA opens the package execution context so governed artefacts can be created inside the Domain boundary.',
    sceneMarkup:() => `<div class="sdia-artifacts-splash-scene"><span class="sdia-artifacts-boundary"><i></i><i></i><i></i><i></i></span><span class="sdia-artifacts-token a"><img src="${runtimeUrl('src/modules/cloud-integration/artifacts/splash/assets/artifact.png')}" alt=""></span><span class="sdia-artifacts-token b"><img src="${runtimeUrl('src/modules/cloud-integration/artifacts/splash/assets/artifact.png')}" alt=""></span><span class="sdia-artifacts-token c"><img src="${runtimeUrl('src/modules/cloud-integration/artifacts/splash/assets/artifact.png')}" alt=""></span><span class="sdia-artifacts-shield"><img src="${runtimeUrl('src/shared/brand/assets/icon128.png')}" alt=""></span></div>`
  });
})();
