/* SDIA Governance v0.2.0 — Cloud Integration package governance.
 * Native SAP Package behavior remains protected; this module only coordinates the existing bridge contract.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { state, constants, normalizeToken, normalizeText, clampText, escapeHtml, icon } = SDIA.Core;
  const { DESCRIPTION_PREFIX, SHORT_DESCRIPTION_MAX } = constants;
  const designContext = (...args) => SDIA.RouteContext.designContext(...args);
  const activeProductProfile = (...args) => SDIA.RouteContext.activeProductProfile(...args);
  const bridgeRequest = (...args) => SDIA.BridgeClient.request(...args);
  const showToast = (...args) => SDIA.Workspace.showToast(...args);
  const closeControlCenter = (...args) => SDIA.Workspace.closeControlCenter(...args);
  const switchModule = (...args) => SDIA.Workspace.switchModule(...args);
  const PACKAGE_EDIT_TX_KEY = 'sdia:package-edit-transaction:v0.2.0';
  const PACKAGE_EDIT_TTL = 120000;
  let packageEditResumeRunning = false;
  let packageEditResumeTimer = null;

  function canonicalCode(item) {
    return normalizeToken(item?.canonicalCode || item?.id || '');
  }

  function taxonomyTokens(item) {
    return [...new Set([item?.id, item?.canonicalCode, ...(item?.aliases || [])]
      .map(normalizeToken).filter(Boolean))];
  }

  function taxonomyMatches(item, token) {
    const normalized = normalizeToken(token);
    return Boolean(normalized) && taxonomyTokens(item).includes(normalized);
  }

  function findDomain(token) {
    return (state.catalog.domains || []).find((item) => taxonomyMatches(item, token)) || null;
  }

  function findSubdomain(domain, token) {
    return (domain?.subdomains || []).find((item) => taxonomyMatches(item, token)) || null;
  }

  function taxonomyOptionLabel(item) {
    const code = canonicalCode(item).toUpperCase();
    return code ? `${item?.name || item?.id || code} — ${code}` : (item?.name || item?.id || '');
  }

  function readPackageEditTransaction() {
    try {
      const raw = sessionStorage.getItem(PACKAGE_EDIT_TX_KEY);
      if (!raw) return null;
      const tx = JSON.parse(raw);
      if (!tx || !tx.id || !tx.payload?.TechnicalName) return null;
      return tx;
    } catch (_) { return null; }
  }

  function writePackageEditTransaction(tx) {
    try { sessionStorage.setItem(PACKAGE_EDIT_TX_KEY, JSON.stringify(tx)); } catch (_) {}
    return tx;
  }

  function clearPackageEditTransaction() {
    try { sessionStorage.removeItem(PACKAGE_EDIT_TX_KEY); } catch (_) {}
    if (packageEditResumeTimer) clearTimeout(packageEditResumeTimer);
    packageEditResumeTimer = null;
  }

  function updatePackageEditTransaction(tx, stage, patch = {}) {
    const now = Date.now();
    return writePackageEditTransaction({ ...tx, ...patch, stage, updatedAt: now, stageStartedAt: stage === tx.stage ? (tx.stageStartedAt || now) : now });
  }

  function schedulePackageEditResume(delayMs = 650) {
    if (packageEditResumeTimer) clearTimeout(packageEditResumeTimer);
    packageEditResumeTimer = setTimeout(() => { packageEditResumeTimer = null; void resumePendingPackageEdit(); }, delayMs);
  }

  function packageEditTargetOpen(tx) {
    const context = designContext();
    return context.type === 'contentpackage' && normalizeText(context.packageId) === normalizeText(tx?.payload?.TechnicalName);
  }

  function packageEditHeaderOpen(tx) {
    return packageEditTargetOpen(tx) && /(?:[?&#]|\b)section=HEADER\b/i.test(SDIA.RouteContext.routeText());
  }

  function packageEditStageMessage(stage) {
    return {
      'open-package': 'Locating the selected package in SAP Cloud Integration…',
      'await-package-route': 'Opening the selected package in SAP Cloud Integration…',
      'enable-edit': 'Locating the native SAP Edit action…',
      'await-edit-header': 'SAP Edit selected. Waiting for the native Header and edit lock…',
      'apply-values': 'Applying Display Name, Short Description, Version and Vendor…'
    }[stage] || 'Preparing SAP Header…';
  }

  function packageEditStageProgress(stage) {
    return {
      'open-package': 'locating-package',
      'await-package-route': 'opening-package',
      'enable-edit': 'locating-edit',
      'await-edit-header': 'opening-header',
      'apply-values': 'filling-fields'
    }[stage] || 'locating-package';
  }

  function syncPendingPackageEditUi(tx) {
    if (!tx) return;
    state.packageEditBusy = true;
    if (tx.selectedPackage) state.selectedPackage = { ...tx.selectedPackage };
    setPackageEditBusy(true, 'Preparing SAP Header…');
    setPackageEditProgress(packageEditStageProgress(tx.stage));
    const status = state.overlay?.querySelector('#sdia-package-edit-action-status');
    if (status) { status.className = 'sdia-create-status'; status.textContent = packageEditStageMessage(tx.stage); }
  }

  function failPendingPackageEdit(error) {
    const message = error?.message || String(error || 'Package edit preparation failed.');
    clearPackageEditTransaction();
    state.packageEditBusy = false;
    setPackageEditBusy(false);
    setPackageEditProgress('error');
    const status = state.overlay?.querySelector('#sdia-package-edit-action-status');
    if (status) { status.className = 'sdia-create-status error'; status.textContent = message; }
    showToast(`Package edit preparation failed · ${message}`, 9000);
  }

  async function completePendingPackageEdit(tx, result) {
    clearPackageEditTransaction();
    state.packageEditBusy = false;
    setPackageEditBusy(false);
    setPackageEditProgress('success');
    const status = state.overlay?.querySelector('#sdia-package-edit-action-status');
    if (status) { status.className = 'sdia-create-status success'; status.textContent = 'Native SAP Header prepared. Review the values and click Save.'; }
    closeControlCenter();
    showToast(`Package metadata applied · ${tx.payload.TechnicalName} · review and click Save`, 7600);
    console.info('[SDIA] Resumable native package edit Header prepared', result);
  }

  async function resumePendingPackageEdit() {
    if (packageEditResumeRunning) return;
    let tx = readPackageEditTransaction();
    if (!tx) return;
    if (Date.now() - Number(tx.createdAt || 0) > PACKAGE_EDIT_TTL) { failPendingPackageEdit(new Error('Package edit transaction expired before SAP completed the native navigation.')); return; }

    packageEditResumeRunning = true;
    try {
      syncPendingPackageEditUi(tx);

      if (!packageEditTargetOpen(tx)) {
        if (tx.stage === 'await-package-route') {
          const elapsed = Date.now() - Number(tx.stageStartedAt || 0);
          const openAttempts = Number(tx.attempts?.open || 0);
          if (elapsed > 30000) throw new Error(`SAP did not open package ${tx.payload.TechnicalName} within 30 seconds after two native navigation attempts.`);
          if (elapsed > 12000 && openAttempts < 2) {
            tx = updatePackageEditTransaction(tx, 'await-package-route', { attempts: { ...(tx.attempts || {}), open: openAttempts + 1 }, stageStartedAt: tx.stageStartedAt });
            syncPendingPackageEditUi(tx);
            await bridgeRequest('OPEN_PACKAGE_FOR_EDIT', tx.payload, 9000);
          }
          schedulePackageEditResume(700);
          return;
        }
        if (designContext().type !== 'design') throw new Error(`Return to Integrations and APIs (/shell/design) before editing ${tx.payload.TechnicalName}.`);
        tx = updatePackageEditTransaction(tx, 'await-package-route', { attempts: { ...(tx.attempts || {}), open: Number(tx.attempts?.open || 0) + 1 } });
        syncPendingPackageEditUi(tx);
        await bridgeRequest('OPEN_PACKAGE_FOR_EDIT', tx.payload, 9000);
        schedulePackageEditResume(650);
        return;
      }

      if (packageEditHeaderOpen(tx)) {
        tx = updatePackageEditTransaction(tx, 'apply-values', { attempts: { ...(tx.attempts || {}), apply: Number(tx.attempts?.apply || 0) + 1 } });
        syncPendingPackageEditUi(tx);
        try {
          const result = await bridgeRequest('APPLY_PACKAGE_EDIT_VALUES', tx.payload, 20000, (progress) => {
            if (progress?.phase) setPackageEditProgress(progress.phase);
          });
          await completePendingPackageEdit(tx, result);
          return;
        } catch (error) {
          const current = readPackageEditTransaction();
          const attempts = Number(current?.attempts?.apply || tx.attempts?.apply || 1);
          if (attempts < 2 && packageEditHeaderOpen(tx)) {
            tx = updatePackageEditTransaction(current || tx, 'apply-values');
            schedulePackageEditResume(900);
            return;
          }
          throw error;
        }
      }

      if (tx.stage === 'await-edit-header') {
        if (Date.now() - Number(tx.stageStartedAt || 0) > 18000) throw new Error('SAP Edit was triggered, but the native Header did not become ready within 18 seconds.');
        schedulePackageEditResume(650);
        return;
      }

      tx = updatePackageEditTransaction(tx, 'await-edit-header', { attempts: { ...(tx.attempts || {}), edit: Number(tx.attempts?.edit || 0) + 1 } });
      syncPendingPackageEditUi(tx);
      await bridgeRequest('ENABLE_PACKAGE_EDIT', tx.payload, 9000);
      schedulePackageEditResume(650);
    } catch (error) {
      const current = readPackageEditTransaction();
      // If SAP replaced the document during a native navigation, the old content script may lose
      // its bridge response. A new document will resume from sessionStorage. Do not turn that into
      // a false timeout while the expected target route is already active.
      if (current && (packageEditTargetOpen(current) || packageEditHeaderOpen(current)) && /did not respond within/i.test(error?.message || '')) {
        schedulePackageEditResume(700);
      } else {
        failPendingPackageEdit(error);
      }
    } finally {
      packageEditResumeRunning = false;
    }
  }
  function normalizeDescription(value, fallbackToAutomatic = true) {
    const raw = String(value || '').trim();
    const source = raw || (fallbackToAutomatic ? automaticDescription() : DESCRIPTION_PREFIX);
    const withoutPrefix = source.replace(/^SDIA\s*-\s*Scope\s*&\s*Governance\s*:\s*/i, '').trim();
    const withPrefix = `${DESCRIPTION_PREFIX}${withoutPrefix ? ` ${withoutPrefix}` : ''}`;
    return clampText(withPrefix, SHORT_DESCRIPTION_MAX);
  }

  function packagesMarkup() {
    return `
      <section class="sdia-module sdia-hidden" data-sdia-view="packages">
        ${SDIA.PackageControlPlaneVisual.markup()}
        <div class="sdia-choice-grid sdia-package-choice-grid">
          <button type="button" data-sdia-action="assess-packages">
            <i>${icon('scan')}</i><div><b>Assess Existing Packages</b><p>Review naming, domain alignment, suffix and classification coverage.</p><span>Run Assessment</span></div>
          </button>
          <button type="button" data-sdia-action="create-package">
            <i>${icon('create')}</i><div><b>Create a Domain Boundary Package</b><p>Build the governed package boundary and prepare the native SAP Header.</p><span>Open Builder</span></div>
          </button>
          <button type="button" data-sdia-action="edit-package-governance">
            <i>${icon('packages')}</i><div><b>Edit Package Governance</b><p>Select an existing package and prepare its native SAP Header for governed metadata updates.</p><span>Load Package List</span></div>
          </button>
        </div>
        <div class="sdia-scope-banner"><b>Current pilot scope</b><span>Package creation, assessment and governed package metadata editing through native SAP Cloud Integration Header flows.</span></div>
      </section>`;
  }

  function packageMapMarkup() {
    return `
      <section class="sdia-module sdia-hidden" data-sdia-view="package-map">
        <div class="sdia-package-map-hero-row sdia-package-map-hero-row-clean">
          <div class="sdia-package-map-hero-main">
            <div class="sdia-module-heading sdia-package-map-heading">
              <span>ODCP · PACKAGE ARCHITECTURE</span>
              <h1>Domain Governance Package Map</h1>
              <p>Reconstruct the tenant package architecture from real inventory.</p>
            </div>
          </div>
          <div class="sdia-package-map-command-area">
            <div id="sdia-package-map-summary" class="sdia-package-map-summary sdia-package-map-summary-inline" aria-live="polite"></div>
            <div class="sdia-package-map-toolbar sdia-package-map-toolbar-compact">
              <button id="sdia-refresh-package-map" class="sdia-primary-action" type="button" data-sdia-action="refresh-package-map">Refresh Governance Map</button>
              <div class="sdia-package-search-box sdia-package-map-search-inline">
                <i>${icon('scan')}</i>
                <input id="sdia-package-map-search" type="search" autocomplete="off" spellcheck="false" placeholder="Search domain, subdomain or package" aria-label="Search package governance map">
                <button id="sdia-package-map-search-clear" class="sdia-package-search-clear" type="button" aria-label="Clear governance map search">×</button>
              </div>
            </div>
            <span id="sdia-package-map-filter-status" class="sdia-package-filter-status"></span>
            <span id="sdia-package-map-status" class="sdia-package-map-status" aria-live="polite"></span>
            <small class="sdia-package-map-assessment-note">Unclassified and ungoverned packages are reported in Package Governance Assessment. The architecture below renders only packages with a recognized Domain.</small>
          </div>
        </div>
        <section id="sdia-package-map-architecture" class="sdia-package-map-panel sdia-package-map-main-panel">
          <div class="sdia-package-map-panel-heading sdia-package-map-architecture-heading">
            <div><span>PACKAGE ARCHITECTURE</span><b>Company → Division → Domain → Subdomain → Package → iFlows</b><small>Company and Division are omitted when they do not exist. Select a Package to load its real Integration Flows inline.</small></div>
            <div class="sdia-package-map-architecture-actions">
              <button type="button" data-sdia-map-expand>Expand Architecture</button>
              <button type="button" data-sdia-map-export>Export PDF</button>
              <button type="button" data-sdia-map-close class="sdia-hidden">× Close</button>
            </div>
          </div>
          <div id="sdia-package-map-tree" class="sdia-package-map-tree"><div class="sdia-package-map-empty">Load the current tenant package inventory to build the map.</div></div>
        </section>
      </section>`;
  }

  function packageEditListMarkup() {
    return `
      <section class="sdia-module sdia-hidden" data-sdia-view="package-edit-list">
        <div class="sdia-module-heading"><span>ODCP · PACKAGE GOVERNANCE</span><h1>Select a Package to Edit</h1><p>Choose a package from the current SAP Cloud Integration tenant. The selected package opens in an SDIA metadata form before the native SAP Header is prepared.</p></div>
        <div class="sdia-assessment-toolbar sdia-package-list-toolbar">
          <button id="sdia-refresh-package-edit-list" class="sdia-primary-action" type="button" data-sdia-action="refresh-package-edit-list">Refresh Package List</button>
          <span id="sdia-package-edit-status">Package inventory not loaded.</span>
        </div>
        <div class="sdia-package-search-row">
          <div class="sdia-package-search-box">
            <i>${icon('scan')}</i>
            <input id="sdia-package-edit-search" type="search" autocomplete="off" spellcheck="false" placeholder="Search packages by name, technical name or description" aria-label="Search packages">
            <button id="sdia-package-edit-search-clear" class="sdia-package-search-clear" type="button" aria-label="Clear package search">×</button>
          </div>
          <span id="sdia-package-edit-filter-status" class="sdia-package-filter-status">Showing all loaded packages.</span>
        </div>
        <div class="sdia-table-wrap sdia-package-edit-table-wrap">
          <table class="sdia-assessment-table sdia-package-edit-table">
            <thead><tr><th>Display Name</th><th>Short Description</th></tr></thead>
            <tbody id="sdia-package-edit-body"><tr><td colspan="2" class="sdia-empty-row">Loading package inventory…</td></tr></tbody>
          </table>
        </div>
        <div class="sdia-package-list-hint">Click any package row to open its governed metadata form. Technical Name remains available in the edit form.</div>
      </section>`;
  }

  function packageEditFormMarkup() {
    return `
      <section class="sdia-module sdia-hidden" data-sdia-view="package-edit-form">
        <div class="sdia-module-heading compact sdia-package-edit-heading">
          <h1>Edit Package Governance</h1>
          <p>Update editable package metadata through the native SAP Cloud Integration Header. Technical Name remains owned by SAP and is read-only.</p>
        </div>
        <div class="sdia-package-edit-form-card">
          <div class="sdia-package-edit-form-grid">
            <label class="sdia-package-edit-technical"><span>Technical Name</span><input id="sdia-edit-technical-name" type="text" readonly><small>Read-only in SAP Cloud Integration.</small></label>
            <label><span>Display Name</span><input id="sdia-edit-display-name" type="text" required aria-describedby="sdia-edit-display-name-error"><small id="sdia-edit-display-name-error" class="sdia-field-error" role="alert" hidden></small></label>
            <label class="sdia-package-edit-description"><span>Short Description</span><textarea id="sdia-edit-short-description" rows="3" maxlength="255" aria-describedby="sdia-edit-description-counter"></textarea><small class="sdia-description-meta"><span>Maximum 255 characters.</span><b id="sdia-edit-description-counter">0 / 255</b></small></label>
            <label><span>Version</span><input id="sdia-edit-version" type="text"></label>
            <label><span>Vendor</span><input id="sdia-edit-vendor" type="text" placeholder="Optional"></label>
          </div>
          <div id="sdia-package-edit-progress" class="sdia-package-edit-progress" aria-live="polite">
            <div class="sdia-package-edit-progress-track" aria-hidden="true"><span></span></div>
            <span data-edit-step="package"><i></i><b>Package</b></span>
            <span data-edit-step="edit"><i></i><b>SAP Edit</b></span>
            <span data-edit-step="header"><i></i><b>Native Header</b></span>
            <span data-edit-step="values"><i></i><b>Apply Values</b></span>
          </div>
          <div class="sdia-package-edit-action-row">
            <div id="sdia-package-edit-action-status" class="sdia-create-status">Select metadata values and prepare the native SAP Header.</div>
            <button id="sdia-prepare-package-edit" class="sdia-primary-action sdia-package-edit-action" type="button" data-sdia-action="prepare-package-edit"><span class="sdia-action-spinner" aria-hidden="true"></span><span id="sdia-prepare-package-edit-label">Open Package Header in SAP Cloud Integration</span></button>
          </div>
          <small class="sdia-package-edit-save-note">SDIA never presses Save. Review the native SAP Header and save with the standard SAP action.</small>
        </div>
      </section>`;
  }

  function packageCreateMarkup() {
    return `
      <section class="sdia-module sdia-hidden" data-sdia-view="package-create">
        <div class="sdia-builder-layout sdia-package-create-layout">
          <div class="sdia-builder-form sdia-package-builder-form">
            <div class="sdia-module-heading compact">
              <h1>Create a Domain Boundary Package</h1>
              <p>Define the semantic boundary. Company and Division are optional. Domain is the governance key and Subdomain completes the boundary.</p>
            </div>

            <div class="sdia-package-form-columns">
              <section class="sdia-package-form-panel sdia-package-boundary-panel" aria-label="Domain boundary">
                <div class="sdia-package-panel-heading"><b>Boundary</b><span>Scope identifiers</span></div>
                <div class="sdia-package-boundary-fields">
                  <div class="sdia-scope-field-group">
                    <label class="sdia-switch-row sdia-compact-switch"><input id="sdia-company-enabled" type="checkbox"><span><b>Include Company Code</b><small>Optional first segment.</small></span></label>
                    <label id="sdia-company-field"><span>Company Code</span><input id="sdia-company" type="text" maxlength="8" placeholder="tk" aria-describedby="sdia-company-hint sdia-company-error"><small id="sdia-company-hint">Example: <code>tk</code></small><small id="sdia-company-error" class="sdia-field-error" role="alert" hidden></small></label>
                  </div>
                  <div class="sdia-scope-field-group">
                    <label class="sdia-switch-row sdia-compact-switch"><input id="sdia-division-enabled" type="checkbox"><span><b>Include Division Code</b><small>Optional division segment.</small></span></label>
                    <label id="sdia-division-field"><span>Division Code</span><input id="sdia-division" type="text" maxlength="12" list="sdia-division-list" placeholder="es" aria-describedby="sdia-division-hint sdia-division-error"><small id="sdia-division-hint">Example: <code>es</code> or <code>pr</code></small><small id="sdia-division-error" class="sdia-field-error" role="alert" hidden></small></label>
                  </div>
                  <div class="sdia-governance-select-field" data-sdia-boundary-selector="domain">
                    <span id="sdia-domain-label">Domain</span>
                    <button id="sdia-domain-trigger" class="sdia-governance-select-trigger" type="button" aria-haspopup="listbox" aria-expanded="false" aria-labelledby="sdia-domain-label sdia-domain-trigger-label" aria-describedby="sdia-domain-trigger-summary sdia-domain-error"><span><b id="sdia-domain-trigger-label">Select governed Domain</b><small id="sdia-domain-trigger-summary">Choose the primary business boundary</small></span><i aria-hidden="true">⌄</i></button>
                    <div id="sdia-domain-menu" class="sdia-governance-select-menu sdia-hidden" role="dialog" aria-label="Select Domain"><label class="sdia-governance-select-search"><span>⌕</span><input id="sdia-domain-search" type="search" placeholder="Search Domain or code" autocomplete="off"></label><div id="sdia-domain-options" class="sdia-governance-select-options" role="listbox"></div></div>
                    <select id="sdia-domain" class="sdia-governance-native-select" tabindex="-1" aria-hidden="true"></select>
                    <small id="sdia-domain-selection-meta" class="sdia-governance-selection-meta">Catalog-driven semantic boundary.</small>
                    <small id="sdia-domain-error" class="sdia-field-error" role="alert" hidden></small>
                  </div>
                  <div class="sdia-governance-select-field" data-sdia-boundary-selector="subdomain">
                    <span id="sdia-subdomain-label">Subdomain</span>
                    <button id="sdia-subdomain-trigger" class="sdia-governance-select-trigger" type="button" aria-haspopup="listbox" aria-expanded="false" aria-labelledby="sdia-subdomain-label sdia-subdomain-trigger-label" aria-describedby="sdia-subdomain-trigger-summary sdia-subdomain-error" disabled><span><b id="sdia-subdomain-trigger-label">Select Domain first</b><small id="sdia-subdomain-trigger-summary">Capability boundary follows the Domain</small></span><i aria-hidden="true">⌄</i></button>
                    <div id="sdia-subdomain-menu" class="sdia-governance-select-menu sdia-hidden" role="dialog" aria-label="Select Subdomain"><label class="sdia-governance-select-search"><span>⌕</span><input id="sdia-subdomain-search" type="search" placeholder="Search Subdomain or code" autocomplete="off"></label><div id="sdia-subdomain-options" class="sdia-governance-select-options" role="listbox"></div></div>
                    <select id="sdia-subdomain" class="sdia-governance-native-select" tabindex="-1" aria-hidden="true"></select>
                    <small id="sdia-subdomain-selection-meta" class="sdia-governance-selection-meta">Select a Domain to load governed capabilities.</small>
                    <small id="sdia-subdomain-error" class="sdia-field-error" role="alert" hidden></small>
                  </div>
                </div>
              </section>

              <section class="sdia-package-form-panel sdia-package-metadata-panel" aria-label="Package metadata">
                <div class="sdia-package-panel-heading"><b>Package Metadata</b><span>SAP Header values</span></div>
                <div class="sdia-package-metadata-fields">
                  <label class="sdia-package-description-field"><span>Package Description</span><textarea id="sdia-description" rows="4" maxlength="255" aria-describedby="sdia-description-counter"></textarea><small class="sdia-description-meta"><span>SAP Short Description · absolute maximum 255 characters.</span><b id="sdia-description-counter">0 / 255</b></small></label>
                  <div class="sdia-package-meta-row">
                    <label><span>Version</span><input id="sdia-version" type="text" value="1.0.0"></label>
                    <label><span>Vendor</span><input id="sdia-vendor" type="text" placeholder="Optional"></label>
                  </div>
                </div>
              </section>
              <datalist id="sdia-division-list"></datalist>
            </div>
          </div>

          <aside class="sdia-builder-preview sdia-package-preview">
            <span class="sdia-section-label">DOMAIN BOUNDARY PREVIEW</span>
            <div id="sdia-domain-boundary-viz" class="sdia-domain-boundary-viz" aria-live="polite">
              <div class="sdia-boundary-caption"><span>DOMAIN BOUNDARY</span><b id="sdia-boundary-state">Select Domain</b></div>
              <div class="sdia-boundary-chain" aria-label="Package domain boundary">
                <div class="sdia-boundary-node is-omitted" data-boundary-node="company"><small>Company</small><b id="sdia-boundary-company">—</b></div>
                <div class="sdia-boundary-node is-omitted" data-boundary-node="division"><small>Division</small><b id="sdia-boundary-division">—</b></div>
                <div class="sdia-boundary-node is-primary" data-boundary-node="domain"><small>Domain</small><b id="sdia-boundary-domain">—</b><em>PRIMARY KEY</em></div>
                <div class="sdia-boundary-node" data-boundary-node="subdomain"><small>Subdomain</small><b id="sdia-boundary-subdomain">—</b></div>
              </div>
              <div id="sdia-boundary-package" class="sdia-boundary-package"><span>GENERATED PACKAGE</span><strong id="sdia-boundary-package-name">Domain + Subdomain required</strong><i aria-hidden="true">✓</i></div>
            </div>


            <div class="sdia-package-header-action">
              <div id="sdia-sap-header-progress" class="sdia-sap-header-progress" aria-live="polite">
                <div class="sdia-header-progress-track" aria-hidden="true"><span></span></div>
                <div class="sdia-header-progress-steps">
                  <span data-header-step="boundary"><i></i><b>Boundary</b></span>
                  <span data-header-step="create"><i></i><b>SAP Create</b></span>
                  <span data-header-step="header"><i></i><b>Native Header</b></span>
                  <span data-header-step="values"><i></i><b>Apply Values</b></span>
                </div>
              </div>
              <div class="sdia-package-action-row">
                <div id="sdia-create-status" class="sdia-create-status">Complete the domain boundary to enable native SAP Header preparation.</div>
                <button id="sdia-prepare-package" class="sdia-primary-action sdia-prepare-package-action" type="button"><span class="sdia-action-spinner" aria-hidden="true"></span><span id="sdia-prepare-package-label">Open Package Header in SAP Cloud Integration</span></button>
              </div>
              <p>SDIA never presses Save. Review the native SAP Header and save it with the standard SAP action.</p>
            </div>
          </aside>
        </div>
      </section>`;
  }

  const packageCreateTouchedFields = new Set();

  function setFieldError(field, errorId, message) {
    const text = String(message || '');
    if (field) field.setAttribute('aria-invalid', text ? 'true' : 'false');
    const errorEl = state.overlay?.querySelector(`#${errorId}`);
    if (errorEl) {
      errorEl.textContent = text;
      errorEl.hidden = !text;
    }
  }

  function validatePackageCreateFields(scope = selectedScope(), force = false) {
    if (!state.overlay) return;
    const show = (id) => force || packageCreateTouchedFields.has(id);
    setFieldError(
      state.overlay.querySelector('#sdia-company'), 'sdia-company-error',
      show('sdia-company') && scope.companyEnabled && !scope.company
        ? 'Company Code is required while Include Company Code is enabled.' : ''
    );
    setFieldError(
      state.overlay.querySelector('#sdia-division'), 'sdia-division-error',
      show('sdia-division') && scope.divisionEnabled && !scope.division
        ? 'Division Code is required while Include Division Code is enabled.' : ''
    );
    setFieldError(
      state.overlay.querySelector('#sdia-domain-trigger'), 'sdia-domain-error',
      show('sdia-domain') && !scope.domainId ? 'Domain is required. Choose the primary business boundary.' : ''
    );
    setFieldError(
      state.overlay.querySelector('#sdia-subdomain-trigger'), 'sdia-subdomain-error',
      show('sdia-subdomain') && scope.domainId && !scope.subdomainId
        ? 'Subdomain is required to complete the domain boundary.' : ''
    );
  }

  function bindEnterToPrimaryAction(ids, buttonId) {
    ids.forEach((id) => {
      const field = state.overlay.querySelector(`#${id}`);
      if (!field || field.dataset.sdiaEnterBound) return;
      field.dataset.sdiaEnterBound = '1';
      field.addEventListener('keydown', (event) => {
        if (event.key !== 'Enter' || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
        const primary = state.overlay.querySelector(`#${buttonId}`);
        if (!primary || primary.disabled) return;
        event.preventDefault();
        primary.click();
      });
    });
  }

  function bindPackageBuilder() {
    if (!state.overlay) return;
    const bindOnce = (id, type, handler) => {
      const field = state.overlay.querySelector(`#${id}`);
      if (!field || field.dataset.sdiaBound) return;
      field.dataset.sdiaBound = '1';
      field.addEventListener(type, handler);
    };
    const markTouched = (...ids) => ids.forEach((id) => packageCreateTouchedFields.add(id));
    // Scope changes regenerate the automatic description only while the user has not
    // customized it (state.descriptionDirty); the preview always refreshes once.
    const scopeChanged = (touchedIds) => {
      markTouched(...touchedIds);
      applyAutomaticDescription();
      updatePackagePreview();
    };
    // One listener per field/event: text inputs react to `input`, checkboxes and the
    // native mirror selects react to `change` (custom menus dispatch `change` only).
    bindOnce('sdia-company', 'input', () => scopeChanged(['sdia-company']));
    bindOnce('sdia-division', 'input', () => scopeChanged(['sdia-division']));
    bindOnce('sdia-company-enabled', 'change', () => scopeChanged(['sdia-company-enabled', 'sdia-company']));
    bindOnce('sdia-division-enabled', 'change', () => scopeChanged(['sdia-division-enabled', 'sdia-division']));
    bindOnce('sdia-domain', 'change', () => {
      populateSubdomains();
      scopeChanged(['sdia-domain', 'sdia-subdomain']);
    });
    bindOnce('sdia-subdomain', 'change', () => scopeChanged(['sdia-subdomain']));
    bindOnce('sdia-version', 'input', () => { markTouched('sdia-version'); updatePackagePreview(); });
    bindOnce('sdia-vendor', 'input', () => { markTouched('sdia-vendor'); updatePackagePreview(); });

    const description = state.overlay.querySelector('#sdia-description');
    if (description && !description.dataset.sdiaBound) {
      description.dataset.sdiaBound = '1';
      // Single `input` handler (covers the old input+change+keyup trio): manual edits
      // mark the description dirty; clearing the field re-enables the automatic text.
      description.addEventListener('input', () => {
        if (description.value.length > SHORT_DESCRIPTION_MAX) description.value = description.value.slice(0, SHORT_DESCRIPTION_MAX);
        state.descriptionDirty = Boolean(description.value.trim());
        updatePackagePreview();
      });
      description.addEventListener('blur', () => {
        const hasManualText = Boolean(description.value.trim());
        description.value = normalizeDescription(description.value);
        state.descriptionDirty = hasManualText;
        updatePackagePreview();
      });
    }
    bindEnterToPrimaryAction(['sdia-company', 'sdia-division', 'sdia-version', 'sdia-vendor'], 'sdia-prepare-package');
    bindGovernanceBoundarySelectors();
    const prepareButton = state.overlay.querySelector('#sdia-prepare-package');
    if (prepareButton && !prepareButton.dataset.sdiaBound) {
      prepareButton.dataset.sdiaBound = '1';
      prepareButton.addEventListener('click', preparePackageInSap);
    }
  }

  function boundarySelectorItems(kind) {
    if (kind === 'domain') return state.catalog.domains || [];
    const domain = findDomain(state.overlay?.querySelector('#sdia-domain')?.value || '');
    return domain?.subdomains || [];
  }

  function renderBoundarySelectorOptions(kind, query = '') {
    if (!state.overlay) return;
    const list = state.overlay.querySelector(`#sdia-${kind}-options`);
    if (!list) return;
    const selectedValue = state.overlay.querySelector(`#sdia-${kind}`)?.value || '';
    const needle = normalizeText(query);
    const items = boundarySelectorItems(kind).filter((item) => {
      if (!needle) return true;
      return normalizeText(`${item.name || ''} ${canonicalCode(item)} ${(item.aliases || []).join(' ')}`).includes(needle);
    });
    list.innerHTML = items.length ? items.map((item) => {
      const code = canonicalCode(item).toUpperCase();
      const selected = taxonomyMatches(item, selectedValue);
      const detail = kind === 'domain' ? `${(item.subdomains || []).length} governed subdomains` : (item.scopeDescription || 'Governed integration capability');
      return `<button type="button" role="option" aria-selected="${selected ? 'true' : 'false'}" class="sdia-governance-select-option${selected ? ' is-selected' : ''}" data-sdia-boundary-option="${kind}" data-value="${escapeHtml(item.id)}"><span><b>${escapeHtml(code)}</b><strong>${escapeHtml(item.name || item.id)}</strong></span><small>${escapeHtml(detail)}</small><i aria-hidden="true">${selected ? '✓' : '›'}</i></button>`;
    }).join('') : `<div class="sdia-governance-select-empty">No matching governed ${kind === 'domain' ? 'Domains' : 'Subdomains'}.</div>`;
  }

  function syncGovernanceBoundarySelector(kind) {
    if (!state.overlay) return;
    const select = state.overlay.querySelector(`#sdia-${kind}`);
    const trigger = state.overlay.querySelector(`#sdia-${kind}-trigger`);
    const label = state.overlay.querySelector(`#sdia-${kind}-trigger-label`);
    const summary = state.overlay.querySelector(`#sdia-${kind}-trigger-summary`);
    const meta = state.overlay.querySelector(`#sdia-${kind}-selection-meta`);
    if (!select || !trigger || !label || !summary || !meta) return;

    if (kind === 'domain') {
      const domain = findDomain(select.value);
      if (domain) {
        const code = canonicalCode(domain).toUpperCase();
        label.textContent = `${code} · ${domain.name}`;
        summary.textContent = `${(domain.subdomains || []).length} governed subdomains`;
        meta.textContent = `Canonical code: ${code} · ${domain.description || 'Business semantic boundary.'}`;
      } else {
        label.textContent = 'Select governed Domain';
        summary.textContent = `${(state.catalog.domains || []).length} business Domains available`;
        meta.textContent = 'Catalog-driven semantic boundary.';
      }
      trigger.disabled = false;
    } else {
      const domain = findDomain(state.overlay.querySelector('#sdia-domain')?.value || '');
      const subdomain = findSubdomain(domain, select.value);
      trigger.disabled = !domain;
      if (subdomain) {
        const code = canonicalCode(subdomain).toUpperCase();
        label.textContent = `${code} · ${subdomain.name}`;
        summary.textContent = domain ? `${canonicalCode(domain).toUpperCase()} · ${domain.name}` : 'Governed capability';
        meta.textContent = `Canonical code: ${code} · ${subdomain.scopeDescription || 'Governed integration capability.'}`;
      } else if (domain) {
        label.textContent = 'Select governed Subdomain';
        summary.textContent = `${(domain.subdomains || []).length} ${domain.name} capabilities available`;
        meta.textContent = `Choose the capability boundary inside ${canonicalCode(domain).toUpperCase()} · ${domain.name}.`;
      } else {
        label.textContent = 'Select Domain first';
        summary.textContent = 'Capability boundary follows the Domain';
        meta.textContent = 'Select a Domain to load governed capabilities.';
      }
    }
    renderBoundarySelectorOptions(kind, state.overlay.querySelector(`#sdia-${kind}-search`)?.value || '');
  }

  function closeGovernanceBoundaryMenus(except = '') {
    if (!state.overlay) return;
    ['domain','subdomain'].forEach((kind) => {
      if (kind === except) return;
      state.overlay.querySelector(`#sdia-${kind}-menu`)?.classList.add('sdia-hidden');
      state.overlay.querySelector(`#sdia-${kind}-trigger`)?.setAttribute('aria-expanded', 'false');
    });
  }

  function bindGovernanceBoundarySelectors() {
    if (!state.overlay || state.overlay.dataset.sdiaBoundarySelectorsBound) return;
    state.overlay.dataset.sdiaBoundarySelectorsBound = '1';
    ['domain','subdomain'].forEach((kind) => {
      const trigger = state.overlay.querySelector(`#sdia-${kind}-trigger`);
      const menu = state.overlay.querySelector(`#sdia-${kind}-menu`);
      const search = state.overlay.querySelector(`#sdia-${kind}-search`);
      trigger?.addEventListener('click', (event) => {
        event.preventDefault();
        if (trigger.disabled) return;
        const opening = menu?.classList.contains('sdia-hidden');
        closeGovernanceBoundaryMenus(kind);
        menu?.classList.toggle('sdia-hidden', !opening);
        trigger.setAttribute('aria-expanded', opening ? 'true' : 'false');
        if (opening) {
          if (search) search.value = '';
          renderBoundarySelectorOptions(kind, '');
          requestAnimationFrame(() => search?.focus());
        }
      });
      search?.addEventListener('input', () => renderBoundarySelectorOptions(kind, search.value));
    });
    state.overlay.addEventListener('click', (event) => {
      const option = event.target instanceof Element ? event.target.closest('[data-sdia-boundary-option]') : null;
      if (option) {
        const kind = option.dataset.sdiaBoundaryOption;
        const select = state.overlay.querySelector(`#sdia-${kind}`);
        if (!select) return;
        select.value = option.dataset.value || '';
        select.dispatchEvent(new Event('change', { bubbles:true }));
        closeGovernanceBoundaryMenus();
        syncGovernanceBoundarySelector('domain');
        syncGovernanceBoundarySelector('subdomain');
        return;
      }
      if (!(event.target instanceof Element) || event.target.closest('.sdia-governance-select-field')) return;
      closeGovernanceBoundaryMenus();
    });
  }

  function populateCatalogControls() {
    if (!state.overlay) return;
    const domain = state.overlay.querySelector('#sdia-domain');
    const previousDomain = domain?.value || '';
    if (domain) {
      domain.innerHTML = '<option value="">Select domain</option>' + (state.catalog.domains || [])
        .map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(taxonomyOptionLabel(item))}</option>`).join('');
      const previousMatch = findDomain(previousDomain);
      if (previousMatch && [...domain.options].some((option) => option.value === previousMatch.id)) domain.value = previousMatch.id;
    }
    const list = state.overlay.querySelector('#sdia-division-list');
    if (list) list.innerHTML = (state.catalog.divisions || []).map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.name || item.id)}</option>`).join('');
    populateSubdomains();
    syncGovernanceBoundarySelector('domain');
    syncGovernanceBoundarySelector('subdomain');
  }

  function populateSubdomains() {
    if (!state.overlay) return;
    const domainValue = state.overlay.querySelector('#sdia-domain')?.value || '';
    const domain = findDomain(domainValue);
    const subdomain = state.overlay.querySelector('#sdia-subdomain');
    if (!subdomain) return;
    const previous = subdomain.value;
    subdomain.innerHTML = '<option value="">Select subdomain</option>' + (domain?.subdomains || [])
      .map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(taxonomyOptionLabel(item))}</option>`).join('');
    const previousMatch = findSubdomain(domain, previous);
    if (previousMatch && [...subdomain.options].some((option) => option.value === previousMatch.id)) subdomain.value = previousMatch.id;
    else if (!domain || !previousMatch) subdomain.value = '';
    syncGovernanceBoundarySelector('domain');
    syncGovernanceBoundarySelector('subdomain');
  }

  function resetBuilderFromSettings() {
    if (!state.overlay) return;
    state.overlay.querySelector('#sdia-company-enabled').checked = Boolean(state.settings.defaultCompanyPrefixEnabled);
    state.overlay.querySelector('#sdia-company').value = state.settings.defaultCompanyCode || '';
    state.overlay.querySelector('#sdia-division-enabled').checked = Boolean(state.settings.defaultDivisionEnabled);
    state.overlay.querySelector('#sdia-division').value = state.settings.defaultDivisionCode || '';
    state.overlay.querySelector('#sdia-vendor').value = state.settings.useDefaultVendor === false ? '' : (state.settings.vendor || '');
    state.overlay.querySelector('#sdia-version').value = '1.0.0';
    state.descriptionDirty = false;
    packageCreateTouchedFields.clear();
    toggleOptionalFields();
    applyAutomaticDescription();
    updatePackagePreview();
  }

  function toggleOptionalFields() {
    state.overlay.querySelector('#sdia-company-field').classList.toggle('sdia-disabled-field', !state.overlay.querySelector('#sdia-company-enabled').checked);
    state.overlay.querySelector('#sdia-division-field').classList.toggle('sdia-disabled-field', !state.overlay.querySelector('#sdia-division-enabled').checked);
  }

  function selectedScope() {
    const companyEnabled = state.overlay.querySelector('#sdia-company-enabled').checked;
    const divisionEnabled = state.overlay.querySelector('#sdia-division-enabled').checked;
    const company = companyEnabled ? normalizeToken(state.overlay.querySelector('#sdia-company').value) : '';
    const division = divisionEnabled ? normalizeToken(state.overlay.querySelector('#sdia-division').value) : '';
    const domainSelection = state.overlay.querySelector('#sdia-domain').value;
    const subdomainSelection = state.overlay.querySelector('#sdia-subdomain').value;
    const domain = findDomain(domainSelection);
    const subdomain = findSubdomain(domain, subdomainSelection);
    const domainId = canonicalCode(domain);
    const subdomainId = canonicalCode(subdomain);
    return { companyEnabled, divisionEnabled, company, division, domainId, subdomainId, domain, subdomain };
  }

  function shortLabel(value, fallback) {
    const text = String(value || fallback || '').trim();
    return (text.split('/')[0] || fallback || '').trim();
  }

  function automaticDescription() {
    const scope = selectedScope();
    if (!scope.domainId || !scope.subdomainId) {
      return normalizeDescription(`${DESCRIPTION_PREFIX} Select Domain and Subdomain to define the governed package boundary.`, false);
    }
    const domainLabel = shortLabel(scope.domain?.name, scope.domainId);
    const subdomainLabel = shortLabel(scope.subdomain?.name, scope.subdomainId);
    const ownership = [];
    if (scope.division) ownership.push(`"${scope.division.toUpperCase()}" division`);
    if (scope.company) ownership.push(`company "${scope.company.toUpperCase()}"`);
    const ownerText = ownership.length ? ` for ${ownership.join(' of ')}` : '';
    const scopeDescription = String(scope.subdomain?.scopeDescription || `${subdomainLabel} integration processes`).replace(/[.\s]+$/g, '');
    const description = `${DESCRIPTION_PREFIX} Centralized package boundary${ownerText}, within the "${domainLabel}" domain and "${subdomainLabel}" subdomain. Scope: ${scopeDescription}.`;
    return normalizeDescription(description, false);
  }

  function updateDescriptionCounter(value) {
    if (!state.overlay) return;
    const counter = state.overlay.querySelector('#sdia-description-counter');
    if (!counter) return;
    const length = String(value || '').length;
    counter.textContent = `${length} / ${SHORT_DESCRIPTION_MAX}`;
    counter.classList.toggle('warning', length >= 230 && length < SHORT_DESCRIPTION_MAX);
    counter.classList.toggle('limit', length >= SHORT_DESCRIPTION_MAX);
  }

  function applyAutomaticDescription() {
    if (!state.overlay) return;
    toggleOptionalFields();
    const textarea = state.overlay.querySelector('#sdia-description');
    if (!textarea) return;
    // Respect manual edits: only regenerate while state.descriptionDirty is false.
    // The flag is set by the description input/blur handlers and cleared when the user
    // empties the field or on form reset / context bootstrap (resetBuilderFromSettings).
    if (state.descriptionDirty) {
      updateDescriptionCounter(textarea.value);
      return;
    }
    textarea.value = automaticDescription();
    updateDescriptionCounter(textarea.value);
  }

  function buildPackage() {
    const scope = selectedScope();
    if ((scope.companyEnabled && !scope.company) || (scope.divisionEnabled && !scope.division) || !scope.domainId || !scope.subdomainId) return null;
    const segments = [scope.company, scope.division, scope.domainId, scope.subdomainId, 'integrations'].filter(Boolean);
    const technicalName = segments.join('.');
    const description = normalizeDescription(state.overlay.querySelector('#sdia-description').value);
    return {
      Category: 'Integration',
      SupportedPlatforms: 'SAP HANA Cloud Integration',
      TechnicalName: technicalName,
      DisplayName: technicalName,
      ShortText: description,
      Version: state.overlay.querySelector('#sdia-version').value.trim() || '1.0.0',
      Vendor: state.overlay.querySelector('#sdia-vendor').value.trim(),
      Description: description,
      Products: ''
    };
  }

  function updateBoundaryVisualization(scope, pkg) {
    if (!state.overlay) return;
    const viz = state.overlay.querySelector('#sdia-domain-boundary-viz');
    if (!viz) return;

    const nodeState = (name, enabled, value) => {
      const node = viz.querySelector(`[data-boundary-node="${name}"]`);
      if (!node) return;
      node.classList.toggle('is-omitted', !enabled);
      node.classList.toggle('is-populated', Boolean(enabled && value));
      const target = node.querySelector('b');
      if (target) target.textContent = enabled && value ? String(value).toUpperCase() : '—';
    };

    nodeState('company', scope.companyEnabled, scope.company);
    nodeState('division', scope.divisionEnabled, scope.division);
    nodeState('domain', true, scope.domainId);
    nodeState('subdomain', true, scope.subdomainId);

    const stateLabel = state.overlay.querySelector('#sdia-boundary-state');
    const packageName = state.overlay.querySelector('#sdia-boundary-package-name');
    const packageBox = state.overlay.querySelector('#sdia-boundary-package');
    let message = 'Select Domain';
    let generated = 'Domain + Subdomain required';

    if (scope.companyEnabled && !scope.company) {
      message = 'Company code required';
      generated = 'Complete Company Code';
    } else if (scope.divisionEnabled && !scope.division) {
      message = 'Division code required';
      generated = 'Complete Division Code';
    } else if (!scope.domainId) {
      message = 'Select Domain';
    } else if (!scope.subdomainId) {
      message = 'Select Subdomain';
      generated = `${scope.domainId}.…`;
    } else if (pkg) {
      message = 'Domain Boundary Ready';
      generated = pkg.TechnicalName;
    }

    if (stateLabel) stateLabel.textContent = message;
    if (packageName) packageName.textContent = generated;
    if (packageBox) packageBox.classList.toggle('is-ready', Boolean(pkg));
    viz.classList.toggle('is-ready', Boolean(pkg));

    const signature = [scope.companyEnabled ? scope.company : '-', scope.divisionEnabled ? scope.division : '-', scope.domainId, scope.subdomainId, Boolean(pkg)].join('|');
    if (viz.dataset.signature !== signature) {
      viz.dataset.signature = signature;
      viz.classList.remove('sdia-boundary-change');
      void viz.offsetWidth;
      viz.classList.add('sdia-boundary-change');
    }
  }

  function setHeaderProgress(phase = 'idle') {
    if (!state.overlay) return;
    const progress = state.overlay.querySelector('#sdia-sap-header-progress');
    if (!progress) return;
    const steps = [...progress.querySelectorAll('[data-header-step]')];
    const phaseMap = {
      idle: { active: -1, completeThrough: -1, progress: 0 },
      ready: { active: -1, completeThrough: 0, progress: 12 },
      'locating-create': { active: 1, completeThrough: 0, progress: 34 },
      'opening-route': { active: 2, completeThrough: 1, progress: 58 },
      'route-opened': { active: 2, completeThrough: 1, progress: 70 },
      'filling-fields': { active: 3, completeThrough: 2, progress: 86 },
      success: { active: -1, completeThrough: 3, progress: 100 },
      error: { active: -1, completeThrough: -1, progress: 0 }
    };
    const cfg = phaseMap[phase] || phaseMap.idle;
    progress.classList.toggle('is-active', !['idle', 'ready'].includes(phase));
    progress.classList.toggle('is-success', phase === 'success');
    progress.classList.toggle('is-error', phase === 'error');
    progress.style.setProperty('--sdia-header-progress', `${cfg.progress}%`);
    steps.forEach((step, index) => {
      step.classList.toggle('is-complete', index <= cfg.completeThrough);
      step.classList.toggle('is-active', index === cfg.active);
    });
  }

  function setPrepareButtonState(busy, label = 'Open Package Header in SAP Cloud Integration') {
    if (!state.overlay) return;
    const button = state.overlay.querySelector('#sdia-prepare-package');
    const text = state.overlay.querySelector('#sdia-prepare-package-label');
    if (!button || !text) return;
    button.classList.toggle('is-busy', Boolean(busy));
    button.setAttribute('aria-busy', busy ? 'true' : 'false');
    text.textContent = label;
  }

  function updatePackagePreview() {
    if (!state.overlay) return;
    toggleOptionalFields();
    syncGovernanceBoundarySelector('domain');
    syncGovernanceBoundarySelector('subdomain');
    const pkg = buildPackage();
    state.generatedPackage = pkg;
    const scope = selectedScope();
    updateBoundaryVisualization(scope, pkg);
    const descriptionField = state.overlay.querySelector('#sdia-description');
    const liveDescription = String(descriptionField.value || '').slice(0, SHORT_DESCRIPTION_MAX);
    updateDescriptionCounter(liveDescription);
    validatePackageCreateFields(scope);
    const prepareButton = state.overlay.querySelector('#sdia-prepare-package');
    prepareButton.disabled = !pkg || state.packageCreateBusy;
    if (!state.packageCreateBusy) setHeaderProgress(pkg ? 'ready' : 'idle');
    const status = state.overlay.querySelector('#sdia-create-status');
    if (status && !state.packageCreateBusy && !status.classList.contains('error') && !status.classList.contains('success')) {
      status.textContent = pkg
        ? 'Domain Boundary Ready · native SAP package Header can be prepared.'
        : 'Complete the domain boundary to enable native SAP Header preparation.';
    }
  }

  async function preparePackageInSap() {
    updatePackagePreview();
    const pkg = state.generatedPackage;
    if (!pkg) {
      validatePackageCreateFields(selectedScope(), true);
      return showToast('Complete the enabled codes, Domain and Subdomain first.', 4500);
    }
    const context = designContext();
    if (!['design', 'package-create'].includes(context.type)) {
      showToast('Open Integrations and APIs before preparing a package.', 5000);
      return;
    }
    if (state.packageCreateBusy) return;

    const button = state.overlay.querySelector('#sdia-prepare-package');
    const status = state.overlay.querySelector('#sdia-create-status');
    state.packageCreateBusy = true;
    button.disabled = true;
    setPrepareButtonState(true, 'Preparing SAP Header…');
    setHeaderProgress('locating-create');
    status.className = 'sdia-create-status busy';
    status.textContent = 'Locating the native SAP Create action…';

    try {
      const result = await bridgeRequest('PREPARE_PACKAGE', pkg, 36000, (progress) => {
        const messages = {
          'locating-create': 'Locating the native SAP Create action…',
          'opening-route': 'Opening the native SAP package Header…',
          'route-opened': 'Native SAP Header opened. Applying governed values…',
          'filling-fields': 'Applying Name, Technical Name and Short Description…'
        };
        const progressMessage = messages[progress.phase] || progress.detail || 'Preparing SAP Header…';
        setHeaderProgress(progress.phase);
        setPrepareButtonState(true, progress.phase === 'filling-fields' ? 'Applying Governed Values…' : 'Preparing SAP Header…');
        status.textContent = progressMessage;
      });
      state.pendingPackageName = pkg.TechnicalName;
      setHeaderProgress('success');
      status.className = 'sdia-create-status success';
      status.textContent = 'Native SAP Header prepared. Review the values and click Save.';
      closeControlCenter();
      showToast(`Governed package fields applied · ${pkg.TechnicalName} · review and click Save`, 7600);
      console.info('[SDIA] Native package Header prepared', result);
    } catch (error) {
      setHeaderProgress('error');
      status.className = 'sdia-create-status error';
      status.textContent = error.message;
      showToast(`Package Header preparation failed · ${error.message}`, 9000);
    } finally {
      state.packageCreateBusy = false;
      setPrepareButtonState(false);
      updatePackagePreview();
    }
  }

  function evaluatePackageName(name, description) {
    const technicalName = String(name || '').trim();
    const tokens = technicalName.split('.').map(normalizeToken).filter(Boolean);
    const domains = state.catalog.domains || [];
    const domainIndex = tokens.findIndex((token) => domains.some((domain) => taxonomyMatches(domain, token)));
    const suffix = tokens[tokens.length - 1] || '';
    let domain = null;
    let subdomain = null;
    if (domainIndex >= 0) {
      domain = domains.find((item) => taxonomyMatches(item, tokens[domainIndex]));
      subdomain = findSubdomain(domain, tokens[domainIndex + 1]);
    }
    const descriptionPresent = Boolean(String(description || '').trim());
    const canonicalDomainUsed = domain ? tokens[domainIndex] === canonicalCode(domain) : false;
    const canonicalSubdomainUsed = subdomain ? tokens[domainIndex + 1] === canonicalCode(subdomain) : false;
    if (domain && subdomain && suffix === 'integrations' && domainIndex <= 2) {
      const canonicalScope = `${canonicalCode(domain)}.${canonicalCode(subdomain)}`;
      if (!canonicalDomainUsed || !canonicalSubdomainUsed) {
        return { status: 'Review', scope: `${shortLabel(domain.name, domain.id)} / ${shortLabel(subdomain.name, subdomain.id)}`, finding: `Legacy alias recognized; canonical Domain/Subdomain code is ${canonicalScope}.` };
      }
      return { status: descriptionPresent ? 'Compliant' : 'Review', scope: `${shortLabel(domain.name, domain.id)} / ${shortLabel(subdomain.name, subdomain.id)}`, finding: descriptionPresent ? 'Canonical Domain boundary recognized.' : 'Governed name; description is missing.' };
    }
    if (domain && subdomain && suffix === 'i') {
      return { status: 'Review', scope: `${shortLabel(domain.name, domain.id)} / ${shortLabel(subdomain.name, subdomain.id)}`, finding: 'Deprecated short suffix .i; use .integrations.' };
    }
    if (domain && !subdomain) return { status: 'Review', scope: `${shortLabel(domain.name, domain.id)} / Unknown`, finding: 'Domain detected, but subdomain is not registered.' };
    return { status: 'Ungoverned', scope: 'Not classified', finding: 'No deterministic Domain/Subdomain boundary was recognized.' };
  }

  function packageEditSearchResults(query = '') {
    const rows = state.packageEditRows || [];
    const needle = normalizeText(query);
    if (!needle) return rows.map((row, index) => ({ row, index, score:0 }));

    const matches = [];
    rows.forEach((row, index) => {
      const display = normalizeText(row.displayName);
      const technical = normalizeText(row.technicalName);
      const description = normalizeText(row.description);
      let score = Infinity;

      if (needle.length === 1) {
        if (display.startsWith(needle)) score = 0;
        else if (technical.startsWith(needle)) score = 1;
      } else {
        if (display.startsWith(needle)) score = 0;
        else if (technical.startsWith(needle)) score = 1;
        else if (display.includes(needle)) score = 2;
        else if (technical.includes(needle)) score = 3;
        else if (description.includes(needle)) score = 4;
      }
      if (Number.isFinite(score)) matches.push({ row, index, score });
    });

    return matches.sort((a, b) =>
      a.score - b.score ||
      normalizeText(a.row.displayName || a.row.technicalName).localeCompare(normalizeText(b.row.displayName || b.row.technicalName))
    );
  }

  function renderPackageEditList(query = '') {
    if (!state.overlay) return;
    const body = state.overlay.querySelector('#sdia-package-edit-body');
    const filterStatus = state.overlay.querySelector('#sdia-package-edit-filter-status');
    const search = state.overlay.querySelector('#sdia-package-edit-search');
    const clear = state.overlay.querySelector('#sdia-package-edit-search-clear');
    const rows = state.packageEditRows || [];
    const needle = String(query || '');
    const results = packageEditSearchResults(needle);

    if (search) search.placeholder = rows.length
      ? `Search ${rows.length} packages by name, technical name or description`
      : 'Search packages by name, technical name or description';
    if (clear) clear.classList.toggle('is-visible', Boolean(needle.trim()));
    if (filterStatus) filterStatus.textContent = needle.trim()
      ? `Showing ${results.length} of ${rows.length} packages`
      : `Showing ${rows.length} packages`;

    if (!body) return;
    if (!rows.length) {
      body.innerHTML = '<tr><td colspan="2" class="sdia-empty-row">No packages returned by the tenant.</td></tr>';
      return;
    }
    if (!results.length) {
      body.innerHTML = `<tr><td colspan="2" class="sdia-empty-row">No packages found for “${escapeHtml(needle.trim())}”.</td></tr>`;
      return;
    }

    body.innerHTML = results.map(({ row, index }) => `
      <tr class="sdia-package-edit-row" data-sdia-package-index="${index}" tabindex="0" role="button" aria-label="Edit ${escapeHtml(row.displayName || row.technicalName)}">
        <td><span class="sdia-package-display-name" title="${escapeHtml(row.displayName || row.technicalName || '')}">${escapeHtml(row.displayName || row.technicalName || '—')}</span></td>
        <td><span class="sdia-package-description-cell" title="${escapeHtml(row.description || '')}">${escapeHtml(row.description || '—')}</span></td>
      </tr>`).join('');
  }

  async function loadPackageEditList() {
    if (!state.overlay || activeProductProfile().id !== 'ci') return;
    const body = state.overlay.querySelector('#sdia-package-edit-body');
    const status = state.overlay.querySelector('#sdia-package-edit-status');
    const refresh = state.overlay.querySelector('#sdia-refresh-package-edit-list');
    const search = state.overlay.querySelector('#sdia-package-edit-search');
    if (body) body.innerHTML = '<tr><td colspan="2" class="sdia-empty-row">Reading packages from SAP Cloud Integration…</td></tr>';
    if (status) status.textContent = 'Loading package inventory from SAP Cloud Integration…';
    if (refresh) { refresh.disabled = true; refresh.textContent = 'Reading Tenant…'; }
    try {
      const result = await bridgeRequest('LIST_PACKAGES', {}, 30000);
      const rows = (result.results || []).map((item) => ({
        technicalName: String(item.TechnicalName || item.Id || item.ID || item.Name || '').trim(),
        displayName: String(item.DisplayName || item.Name || item.TechnicalName || '').trim(),
        description: String(item.ShortText || item.Description || '').trim(),
        version: String(item.Version || '').trim(),
        vendor: String(item.Vendor || '').trim()
      })).filter((item) => item.technicalName || item.displayName);
      rows.sort((a, b) => normalizeText(a.displayName || a.technicalName).localeCompare(normalizeText(b.displayName || b.technicalName)));
      state.packageEditRows = rows;
      renderPackageEditList(search?.value || '');
      if (status) status.textContent = `${rows.length} packages loaded from the SAP tenant.`;
    } catch (error) {
      state.packageEditRows = [];
      if (body) body.innerHTML = `<tr><td colspan="2" class="sdia-empty-row">${escapeHtml(error.message)}</td></tr>`;
      if (status) status.textContent = error.message;
      const filterStatus = state.overlay.querySelector('#sdia-package-edit-filter-status');
      if (filterStatus) filterStatus.textContent = 'Package search unavailable.';
      showToast(`Package list failed · ${error.message}`, 8000);
    } finally {
      if (refresh) { refresh.disabled = false; refresh.textContent = 'Refresh Package List'; }
    }
  }

  function packageMapDivisionLabel(id) {
    const token = normalizeToken(id);
    const division = (state.catalog.divisions || []).find((item) => normalizeToken(item.id) === token);
    return division?.name || String(id || '').toUpperCase();
  }

  function packageMapDomainMatch(tokens = []) {
    const domains = state.catalog.domains || [];
    const domainIndex = tokens.findIndex((token) => domains.some((domain) => taxonomyMatches(domain, token)));
    const domain = domainIndex >= 0 ? domains.find((item) => taxonomyMatches(item, tokens[domainIndex])) : null;
    return { domainIndex, domain };
  }

  function packageMapScopeHints(rows = []) {
    const companies = new Set();
    const divisions = new Set();
    const knownDivisions = new Set((state.catalog.divisions || []).map((item) => normalizeToken(item.id)).filter(Boolean));
    const configuredCompany = normalizeToken(state.settings.defaultCompanyCode);
    const configuredDivision = normalizeToken(state.settings.defaultDivisionCode);
    if (configuredCompany) companies.add(configuredCompany);
    if (configuredDivision) divisions.add(configuredDivision);
    knownDivisions.forEach((id) => divisions.add(id));

    rows.forEach((row) => {
      const tokens = String(row?.technicalName || '').split('.').map(normalizeToken).filter(Boolean);
      const { domainIndex } = packageMapDomainMatch(tokens);
      if (domainIndex === 2) {
        if (tokens[0]) companies.add(tokens[0]);
        if (tokens[1]) divisions.add(tokens[1]);
      }
    });
    return { companies, divisions };
  }

  function classifyPackageForMap(row, scopeHints = { companies:new Set(), divisions:new Set() }) {
    const technicalName = String(row?.technicalName || '').trim();
    const tokens = technicalName.split('.').map(normalizeToken).filter(Boolean);
    const { domainIndex, domain } = packageMapDomainMatch(tokens);
    if (domainIndex < 0 || !domain) {
      return { mapped:false, governed:false, classification:'unclassified', reason:'Domain not recognized in the current catalog.', row };
    }

    const prefix = tokens.slice(0, domainIndex);
    let company = '';
    let division = '';
    let scopeIssue = '';
    if (prefix.length >= 2) {
      company = prefix[prefix.length - 2] || '';
      division = prefix[prefix.length - 1] || '';
      if (prefix.length > 2) scopeIssue = 'Additional scope segments exist before the Domain; only the nearest Company / Division pair is represented.';
    } else if (prefix.length === 1) {
      const token = prefix[0];
      const isDivision = scopeHints.divisions.has(token);
      const isCompany = scopeHints.companies.has(token);
      if (isDivision && !isCompany) division = token;
      else if (isCompany && !isDivision) company = token;
      else if (isDivision && isCompany) {
        division = token;
        scopeIssue = 'The single scope prefix is known as both Company and Division; it is represented as Division for this tenant view.';
      } else {
        scopeIssue = 'A scope prefix exists before the Domain but cannot be identified deterministically as Company or Division; the architecture starts at Domain.';
      }
    }

    const subdomainToken = tokens[domainIndex + 1] || '';
    const subdomain = findSubdomain(domain, subdomainToken);
    const suffix = tokens[tokens.length - 1] || '';
    const suffixIssue = suffix === 'integrations' ? '' : (suffix === 'i' ? 'Legacy .i suffix.' : 'Package suffix is not .integrations.');
    const subdomainIssue = subdomain ? '' : (subdomainToken && subdomainToken !== 'integrations' ? `Subdomain “${subdomainToken}” is not recognized under ${domain.name || domain.id}.` : `No governed Subdomain is present under ${domain.name || domain.id}.`);
    const issues = [scopeIssue, subdomainIssue, suffixIssue].filter(Boolean);
    const classification = suffixIssue ? 'legacy' : (subdomainIssue || scopeIssue ? 'partial' : 'governed');

    return {
      mapped:true,
      governed:classification === 'governed',
      classification,
      reason:issues.join(' '),
      row,
      company: company ? { id:company, label:company.toUpperCase() } : null,
      division: division ? { id:division, label:packageMapDivisionLabel(division) } : null,
      domain: { id:canonicalCode(domain), label:canonicalCode(domain).toUpperCase(), detail:domain.name || domain.id },
      subdomain: subdomain ? { id:canonicalCode(subdomain), label:canonicalCode(subdomain).toUpperCase(), detail:subdomain.name || subdomain.id } : null
    };
  }

  function packageMapInventory() {
    const rows = state.packageMapRows || [];
    const scopeHints = packageMapScopeHints(rows);
    return rows.map((row) => classifyPackageForMap(row, scopeHints));
  }

  function getPackageGovernanceOverview() {
    const rows = state.packageMapRows || [];
    if (!rows.length) return { loaded:false, total:0, governed:0, unclassified:0, domains:[] };
    const inventory = packageMapInventory();
    const classified = inventory.filter((item) => item.mapped);
    const governed = inventory.filter((item) => item.governed);
    const domainMap = new Map();
    classified.forEach((item) => {
      const key = item.domain?.id || '';
      if (!key) return;
      const current = domainMap.get(key) || { code:(item.domain?.label || key.toUpperCase()), name:item.domain?.detail || key, packages:0 };
      current.packages += 1;
      domainMap.set(key, current);
    });
    const domains = [...domainMap.values()].sort((a,b) => b.packages - a.packages || normalizeText(a.code).localeCompare(normalizeText(b.code)));
    return { loaded:true, total:inventory.length, governed:governed.length, unclassified:inventory.length - governed.length, classified:classified.length, domains };
  }

  function packageMapMatches(item, query) {
    const needle = normalizeText(query);
    if (!needle) return true;
    const row = item.row || {};
    const values = [
      row.displayName, row.technicalName, row.description,
      item.company?.id, item.company?.label,
      item.division?.id, item.division?.label,
      item.domain?.id, item.domain?.label, item.domain?.detail,
      item.subdomain?.id, item.subdomain?.label, item.subdomain?.detail,
      item.reason
    ].map(normalizeText).filter(Boolean);
    return values.some((value) => value.includes(needle));
  }

  function newPackageMapNode(type, id, label, detail = '') {
    return { type, id, label, detail, children:new Map(), packages:[], count:0 };
  }

  function addPackageMapNode(parent, descriptor) {
    const key = `${descriptor.type}:${descriptor.id}`;
    if (!parent.children.has(key)) parent.children.set(key, newPackageMapNode(descriptor.type, descriptor.id, descriptor.label, descriptor.detail || ''));
    return parent.children.get(key);
  }

  function buildPackageMapTree(items) {
    const root = newPackageMapNode('root', 'root', 'root');
    items.forEach((item) => {
      let current = root;
      const path = [];
      if (item.company) path.push({ type:'company', ...item.company });
      if (item.division) path.push({ type:'division', ...item.division });
      if (item.domain) path.push({ type:'domain', ...item.domain });
      if (item.subdomain) path.push({ type:'subdomain', ...item.subdomain });
      path.forEach((descriptor) => { current = addPackageMapNode(current, descriptor); });
      current.packages.push(item.row);
    });

    function count(node) {
      let total = node.packages.length;
      node.children.forEach((child) => { total += count(child); });
      node.count = total;
      return total;
    }
    count(root);
    return root;
  }

  function packageMapNodeTypeLabel(type) {
    return { company:'Company', division:'Division', domain:'Domain', subdomain:'Subdomain' }[type] || type;
  }

  function packageMapInlineIflowsMarkup(row) {
    const selected = Number(state.packageMapSelectedIndex) === Number(row._mapIndex);
    if (!selected) return '';
    const items = state.packageMapArtifacts || [];
    const loading = Boolean(state.packageMapArtifactsLoading);
    if (loading) {
      return `<div class="sdia-package-map-iflow-children"><div class="sdia-package-map-inline-loading"><i></i><b>Reading Integration Flows from SAP Cloud Integration…</b></div></div>`;
    }
    if (!items.length) {
      return `<div class="sdia-package-map-iflow-children"><div class="sdia-package-map-no-iflows"><i aria-hidden="true">×</i><b>No Integration Flows in this Package</b></div></div>`;
    }
    return `<div class="sdia-package-map-iflow-children">${items.map((item, index) => {
      const title = item.name || 'Integration Flow';
      return `<button type="button" class="sdia-package-map-inline-iflow" style="--sdia-iflow-index:${index}" data-sdia-map-iflow-index="${index}" title="Open ${escapeHtml(title)} in SAP Cloud Integration" aria-label="Open Integration Flow ${escapeHtml(title)}"><i>${icon('packages')}</i><span><em>IFlow</em><b>${escapeHtml(title)}</b></span></button>`;
    }).join('')}</div>`;
  }

  function renderPackageMapNode(node, depth = 0, expandAll = false) {
    const children = [...node.children.values()].sort((a, b) => {
      const order = { company:0, division:1, domain:2, subdomain:3 };
      return (order[a.type] ?? 9) - (order[b.type] ?? 9) || normalizeText(a.label).localeCompare(normalizeText(b.label));
    });
    const packageRows = [...node.packages].sort((a,b) => normalizeText(a.displayName || a.technicalName).localeCompare(normalizeText(b.displayName || b.technicalName)));
    const open = expandAll || ['company','division','domain','subdomain'].includes(node.type);
    return `
      <details class="sdia-package-map-node sdia-package-map-node-${escapeHtml(node.type)}" ${open ? 'open' : ''}>
        <summary><span class="sdia-package-map-node-type">${escapeHtml(packageMapNodeTypeLabel(node.type))}</span><b>${escapeHtml(node.label)}</b>${node.detail ? `<small>${escapeHtml(node.detail)}</small>` : ''}</summary>
        <div class="sdia-package-map-node-children">
          ${children.map((child) => renderPackageMapNode(child, depth + 1, expandAll)).join('')}
          ${packageRows.map((row) => {
            const selected = Number(state.packageMapSelectedIndex) === Number(row._mapIndex);
            const packageName = row.technicalName || row.displayName || 'Unnamed package';
            return `<div class="sdia-package-map-package-entry${selected ? ' is-selected' : ''}">
              <div class="sdia-package-map-package-row">
                <button type="button" class="sdia-package-map-package${selected ? ' is-selected' : ''}" data-sdia-map-package-index="${row._mapIndex}" title="${escapeHtml(packageName)}">
                  <i>${icon('packages')}</i><span><b><em>Package:</em> ${escapeHtml(packageName)}</b></span>
                </button>
              </div>
              ${packageMapInlineIflowsMarkup(row)}
            </div>`;
          }).join('')}
        </div>
      </details>`;
  }

  function packageMapArchitectureElement() {
    return document.getElementById('sdia-package-map-architecture');
  }

  function packageMapTreeElement() {
    return document.getElementById('sdia-package-map-tree');
  }

  function syncPackageMapExpandedPortal() {
    const architecture = packageMapArchitectureElement();
    if (!architecture) return;

    if (state.packageMapExpanded) {
      if (!state.packageMapExpandPortal?.isConnected) {
        const placeholder = document.createComment('sdia-package-map-architecture-placeholder');
        architecture.parentNode?.insertBefore(placeholder, architecture);
        const portal = document.createElement('div');
        portal.className = 'sdia-package-map-expand-overlay';
        portal.setAttribute('role', 'dialog');
        portal.setAttribute('aria-modal', 'true');
        portal.setAttribute('aria-label', 'Expanded Package Architecture');
        document.body.appendChild(portal);
        portal.appendChild(architecture);
        state.packageMapArchitecturePlaceholder = placeholder;
        state.packageMapExpandPortal = portal;
        document.body.classList.add('sdia-package-map-expanded');
      }
    } else if (state.packageMapExpandPortal) {
      const placeholder = state.packageMapArchitecturePlaceholder;
      if (placeholder?.parentNode) placeholder.parentNode.insertBefore(architecture, placeholder);
      placeholder?.remove?.();
      state.packageMapExpandPortal.remove?.();
      state.packageMapExpandPortal = null;
      state.packageMapArchitecturePlaceholder = null;
      document.body.classList.remove('sdia-package-map-expanded');
    }

    architecture.classList.toggle('is-expanded', Boolean(state.packageMapExpanded));
    architecture.querySelector('[data-sdia-map-expand]')?.classList.toggle('sdia-hidden', Boolean(state.packageMapExpanded));
    architecture.querySelector('[data-sdia-map-close]')?.classList.toggle('sdia-hidden', !state.packageMapExpanded);
  }

  function renderPackageGovernanceMap(query = '') {
    if (!state.overlay) return;
    const inventory = packageMapInventory();
    const classifiedAll = inventory.filter((item) => item.mapped);
    const classified = classifiedAll.filter((item) => packageMapMatches(item, query));
    const tree = packageMapTreeElement();
    const summary = state.overlay.querySelector('#sdia-package-map-summary');
    const filterStatus = state.overlay.querySelector('#sdia-package-map-filter-status');
    const clear = state.overlay.querySelector('#sdia-package-map-search-clear');
    const needle = String(query || '').trim();
    const domainsUsed = new Set(classifiedAll.map((item) => item.domain?.id).filter(Boolean)).size;

    if (clear) clear.classList.toggle('is-visible', Boolean(needle));
    syncPackageMapExpandedPortal();
    if (filterStatus) filterStatus.textContent = needle ? `${classified.length} of ${classifiedAll.length} mapped packages shown` : '';
    if (summary) summary.innerHTML = `
      <div class="sdia-package-map-stat sdia-package-map-stat-total"><span>Total Packages</span><b>${inventory.length}</b></div>
      <div class="sdia-package-map-stat sdia-package-map-stat-classified"><span><i aria-hidden="true">✓</i> Classified</span><b>${classifiedAll.length}</b></div>
      <div class="sdia-package-map-stat sdia-package-map-stat-domains"><span>Domains in Use</span><b>${domainsUsed}</b></div>`;

    if (!tree) return;
    if (!classified.length) {
      tree.innerHTML = `<div class="sdia-package-map-empty">${needle ? `No mapped packages match “${escapeHtml(needle)}”.` : 'No package Domain could be recognized from the current inventory. Run Package Governance Assessment to review unclassified packages.'}</div>`;
      return;
    }
    const root = buildPackageMapTree(classified);
    const rootOrder = { company:0, division:1, domain:2, subdomain:3 };
    tree.innerHTML = [...root.children.values()]
      .sort((a,b) => (rootOrder[a.type] ?? 9) - (rootOrder[b.type] ?? 9) || normalizeText(a.label).localeCompare(normalizeText(b.label)))
      .map((node) => renderPackageMapNode(node, 0, Boolean(needle))).join('');
  }

  async function loadPackageGovernanceMap() {
    if (!state.overlay || activeProductProfile().id !== 'ci') return;
    const status = state.overlay.querySelector('#sdia-package-map-status');
    const refresh = state.overlay.querySelector('#sdia-refresh-package-map');
    const search = state.overlay.querySelector('#sdia-package-map-search');
    const tree = packageMapTreeElement();
    if (status) status.textContent = 'Reading real package inventory from SAP Cloud Integration…';
    if (refresh) { refresh.disabled = true; refresh.textContent = 'Reading Tenant…'; }
    if (tree) tree.innerHTML = '<div class="sdia-package-map-empty">Building package architecture…</div>';
    try {
      const result = await bridgeRequest('LIST_PACKAGES', {}, 30000);
      const rows = (result.results || []).map((item, index) => ({
        packageId: String(item.Id || item.ID || item.id || '').trim(),
        technicalName: String(item.TechnicalName || item.Id || item.ID || item.Name || '').trim(),
        displayName: String(item.DisplayName || item.Name || item.TechnicalName || item.Id || item.ID || '').trim(),
        description: String(item.ShortText || item.Description || '').trim(),
        version: String(item.Version || '').trim(),
        vendor: String(item.Vendor || '').trim(),
        _mapIndex:index
      })).filter((item) => item.technicalName || item.displayName);
      rows.sort((a,b) => normalizeText(a.displayName || a.technicalName).localeCompare(normalizeText(b.displayName || b.technicalName)));
      rows.forEach((row, index) => { row._mapIndex = index; });
      state.packageMapRows = rows;
      state.packageMapSelectedIndex = null;
      state.packageMapArtifacts = [];
      state.packageMapArtifactsLoading = false;
      state.packageMapExpanded = false;
      state.packageEditRows = rows.map(({ _mapIndex, ...row }) => ({ ...row }));
      renderPackageGovernanceMap(search?.value || '');
      if (status) status.textContent = '';
    } catch (error) {
      state.packageMapRows = [];
      if (tree) tree.innerHTML = `<div class="sdia-package-map-empty">${escapeHtml(error.message)}</div>`;
      if (status) status.textContent = error.message;
      showToast(`Governance map failed · ${error.message}`, 8000);
    } finally {
      if (refresh) { refresh.disabled = false; refresh.textContent = 'Refresh Governance Map'; }
    }
  }

  function packageArtifactRows(result = {}) {
    // Native workspace.svc /Artifacts returns every artifact in the Package.
    // Only Type=IFlow belongs in the Package Architecture iFlow branch.
    return (result.results || [])
      .filter((item) => String(item.Type || item.type || '').trim().toUpperCase() === 'IFLOW')
      .map((item) => ({
        id: String(item.reg_id || item.Id || item.ID || item.id || '').trim(),
        name: String(item.Name || '').trim(),
        displayName: String(item.DisplayName || '').trim(),
        version: String(item.Version || item.version || '').trim(),
        description: String(item.Description || item.ShortText || item.description || '').trim()
      }))
      .filter((item) => item.name);
  }

  function exportPackageArchitecturePdf() {
    const architecture = packageMapArchitectureElement();
    if (!architecture) { showToast('Package Architecture is not available for export.', 5000); return; }
    const originalTitle = document.title;
    let cleaned = false;
    const cleanup = () => {
      if (cleaned) return;
      cleaned = true;
      document.body.classList.remove('sdia-print-package-map');
      document.title = originalTitle;
    };
    document.body.classList.add('sdia-print-package-map');
    document.title = 'SDIA - Package Architecture';
    window.addEventListener('afterprint', cleanup, { once:true });
    requestAnimationFrame(() => {
      try { window.print(); }
      finally { setTimeout(cleanup, 1200); }
    });
  }

  async function loadPackageArtifactsForMap(row) {
    if (!row?.technicalName) return;
    state.packageMapArtifactsLoading = true;
    state.packageMapArtifacts = [];
    renderPackageGovernanceMap(state.overlay?.querySelector('#sdia-package-map-search')?.value || '');
    try {
      const result = await bridgeRequest('LIST_PACKAGE_ARTIFACTS', { PackageId: row.packageId, TechnicalName: row.technicalName, DisplayName: row.displayName }, 30000);
      state.packageMapArtifacts = packageArtifactRows(result);
    } catch (error) {
      state.packageMapArtifacts = [];
      if (!/\bHTTP 404\b/i.test(String(error?.message || error || ''))) {
        showToast(`Package iFlow inventory failed · ${error.message}`, 8000);
      }
    } finally {
      state.packageMapArtifactsLoading = false;
      if (state.packageMapRows?.[Number(state.packageMapSelectedIndex)]?.technicalName === row.technicalName) {
        renderPackageGovernanceMap(state.overlay?.querySelector('#sdia-package-map-search')?.value || '');
      }
    }
  }

  function openPackageFromGovernanceMap(index) {
    const numericIndex = Number(index);
    const row = state.packageMapRows?.[numericIndex];
    if (!row) return;
    const samePackage = Number(state.packageMapSelectedIndex) === numericIndex;
    state.packageMapSelectedIndex = numericIndex;
    state.selectedPackage = { ...row };
    if (samePackage && !state.packageMapArtifactsLoading && state.packageMapArtifacts.length) {
      renderPackageGovernanceMap(state.overlay?.querySelector('#sdia-package-map-search')?.value || '');
      return;
    }
    void loadPackageArtifactsForMap(row);
  }

  async function openIflowFromGovernanceMap(index) {
    const packageRow = state.packageMapRows?.[Number(state.packageMapSelectedIndex)];
    const iflow = state.packageMapArtifacts?.[Number(index)];
    if (!packageRow?.technicalName || !iflow?.name) return;

    const button = state.overlay?.querySelector(`[data-sdia-map-iflow-index="${Number(index)}"]`);
    if (button) {
      button.disabled = true;
      button.classList.add('is-opening');
    }
    try {
      // Keep the Governance Map in the foreground while SAP navigates behind it.
      // The Control Center disappears only after the native iFlow route is ready.
      await bridgeRequest('OPEN_IFLOW_FROM_MAP', {
        TechnicalName: packageRow.technicalName,
        IFlowName: iflow.name
      }, 30000);
      closeControlCenter();
    } catch (error) {
      showToast(`Integration Flow could not be opened · ${error.message}`, 7000);
      if (button?.isConnected) {
        button.disabled = false;
        button.classList.remove('is-opening');
      }
    }
  }

  function bindPackageMap() {
    if (!state.overlay) return;
    const search = state.overlay.querySelector('#sdia-package-map-search');
    const clear = state.overlay.querySelector('#sdia-package-map-search-clear');
    const architecture = packageMapArchitectureElement();

    search?.addEventListener('input', () => renderPackageGovernanceMap(search.value));
    clear?.addEventListener('click', () => {
      if (!search) return;
      search.value = '';
      search.focus();
      renderPackageGovernanceMap('');
    });

    architecture?.addEventListener('click', (event) => {
      const target = event.target instanceof Element ? event.target : null;
      if (target?.closest('[data-sdia-map-expand]')) {
        state.packageMapExpanded = true;
        renderPackageGovernanceMap(search?.value || '');
        return;
      }
      if (target?.closest('[data-sdia-map-close]')) {
        state.packageMapExpanded = false;
        renderPackageGovernanceMap(search?.value || '');
        return;
      }
      if (target?.closest('[data-sdia-map-export]')) {
        exportPackageArchitecturePdf();
        return;
      }
      const iflowButton = target?.closest('[data-sdia-map-iflow-index]');
      if (iflowButton) {
        void openIflowFromGovernanceMap(iflowButton.dataset.sdiaMapIflowIndex);
        return;
      }
      const packageButton = target?.closest('[data-sdia-map-package-index]');
      if (packageButton) openPackageFromGovernanceMap(packageButton.dataset.sdiaMapPackageIndex);
    });

  }

  function populatePackageEditForm() {
    if (!state.overlay || !state.selectedPackage) return;
    const pkg = state.selectedPackage;
    const technical = state.overlay.querySelector('#sdia-edit-technical-name');
    const display = state.overlay.querySelector('#sdia-edit-display-name');
    const description = state.overlay.querySelector('#sdia-edit-short-description');
    const version = state.overlay.querySelector('#sdia-edit-version');
    const vendor = state.overlay.querySelector('#sdia-edit-vendor');
    if (technical) technical.value = pkg.technicalName || '';
    if (display) display.value = pkg.displayName || pkg.technicalName || '';
    if (description) description.value = clampText(pkg.description || '', SHORT_DESCRIPTION_MAX);
    if (version) version.value = pkg.version || '1.0.0';
    if (vendor) vendor.value = pkg.vendor || '';
    updatePackageEditDescriptionCounter();
    setFieldError(display, 'sdia-edit-display-name-error', '');
    setPackageEditProgress('idle');
    setPackageEditBusy(false);
    const status = state.overlay.querySelector('#sdia-package-edit-action-status');
    if (status) { status.className = 'sdia-create-status'; status.textContent = 'Review the metadata and prepare the native SAP Header.'; }
  }

  function updatePackageEditDescriptionCounter() {
    if (!state.overlay) return;
    const description = state.overlay.querySelector('#sdia-edit-short-description');
    const counter = state.overlay.querySelector('#sdia-edit-description-counter');
    if (!description || !counter) return;
    if (description.value.length > SHORT_DESCRIPTION_MAX) description.value = description.value.slice(0, SHORT_DESCRIPTION_MAX);
    counter.textContent = `${description.value.length} / ${SHORT_DESCRIPTION_MAX}`;
    counter.classList.toggle('warning', description.value.length >= 230 && description.value.length < SHORT_DESCRIPTION_MAX);
    counter.classList.toggle('limit', description.value.length >= SHORT_DESCRIPTION_MAX);
  }

  function packageEditDisplayNameDuplicate(displayName) {
    const pkg = state.selectedPackage;
    if (!pkg) return null;
    const normalizedTechnical = normalizeText(pkg.technicalName);
    const normalizedDisplay = normalizeText(displayName);
    if (!normalizedDisplay) return null;
    return (state.packageEditRows || []).find((row) =>
      normalizeText(row.technicalName) !== normalizedTechnical &&
      normalizeText(row.displayName) &&
      normalizeText(row.displayName) === normalizedDisplay
    ) || null;
  }

  function validatePackageEditFields() {
    if (!state.overlay || !state.selectedPackage) return;
    const display = state.overlay.querySelector('#sdia-edit-display-name');
    const value = display?.value.trim() || '';
    let message = '';
    if (!value) message = 'Display Name is required.';
    else if (packageEditDisplayNameDuplicate(value)) message = `A package with Display Name “${value}” already exists. Choose a different name.`;
    setFieldError(display, 'sdia-edit-display-name-error', message);
  }

  function setPackageEditBusy(busy, label = 'Open Package Header in SAP Cloud Integration') {
    if (!state.overlay) return;
    const button = state.overlay.querySelector('#sdia-prepare-package-edit');
    const text = state.overlay.querySelector('#sdia-prepare-package-edit-label');
    if (!button || !text) return;
    button.disabled = Boolean(busy);
    button.classList.toggle('is-busy', Boolean(busy));
    text.textContent = label;
  }

  function setPackageEditProgress(phase = 'idle') {
    if (!state.overlay) return;
    const root = state.overlay.querySelector('#sdia-package-edit-progress');
    if (!root) return;

    if (phase === 'error') {
      // Preserve the last real stage so the green line stops exactly where SAP failed.
      root.classList.add('is-visible', 'is-error');
      return;
    }

    const phaseMap = {
      idle: { active: -1, completeThrough: -1, progress: 0 },
      'locating-package': { active: 0, completeThrough: -1, progress: 0 },
      'opening-package': { active: 0, completeThrough: -1, progress: 14 },
      'package-opened': { active: 1, completeThrough: 0, progress: 33 },
      'locating-edit': { active: 1, completeThrough: 0, progress: 42 },
      'opening-header': { active: 2, completeThrough: 1, progress: 66 },
      'edit-enabled': { active: 2, completeThrough: 1, progress: 74 },
      'filling-fields': { active: 3, completeThrough: 2, progress: 88 },
      success: { active: -1, completeThrough: 3, progress: 100 }
    };
    const cfg = phaseMap[phase] || phaseMap.idle;
    root.classList.toggle('is-visible', phase !== 'idle');
    root.classList.remove('is-error');
    root.classList.toggle('is-success', phase === 'success');
    root.style.setProperty('--sdia-edit-progress', `${cfg.progress}%`);
    root.querySelectorAll('[data-edit-step]').forEach((step, index) => {
      step.classList.toggle('is-complete', index <= cfg.completeThrough);
      step.classList.toggle('is-active', index === cfg.active);
    });
  }

  function selectPackageForEdit(index) {
    const pkg = state.packageEditRows?.[Number(index)];
    if (!pkg) return;
    state.selectedPackage = { ...pkg };
    switchModule('package-edit-form');
    populatePackageEditForm();
  }

  function bindPackageEditForm() {
    if (!state.overlay) return;
    const body = state.overlay.querySelector('#sdia-package-edit-body');
    if (body && !body.dataset.sdiaBound) {
      body.dataset.sdiaBound = '1';
      const activate = (event) => {
        const row = event.target instanceof Element ? event.target.closest('[data-sdia-package-index]') : null;
        if (!row) return;
        if (event.type === 'keydown' && !['Enter',' '].includes(event.key)) return;
        if (event.type === 'keydown') event.preventDefault();
        selectPackageForEdit(row.dataset.sdiaPackageIndex);
      };
      body.addEventListener('click', activate);
      body.addEventListener('keydown', activate);
    }
    const search = state.overlay.querySelector('#sdia-package-edit-search');
    const clearSearch = state.overlay.querySelector('#sdia-package-edit-search-clear');
    if (search && !search.dataset.sdiaBound) {
      search.dataset.sdiaBound = '1';
      search.addEventListener('input', () => renderPackageEditList(search.value));
    }
    if (clearSearch && !clearSearch.dataset.sdiaBound) {
      clearSearch.dataset.sdiaBound = '1';
      clearSearch.addEventListener('click', () => {
        if (search) { search.value = ''; search.focus(); }
        renderPackageEditList('');
      });
    }
    const description = state.overlay.querySelector('#sdia-edit-short-description');
    if (description && !description.dataset.sdiaBound) {
      description.dataset.sdiaBound = '1';
      description.addEventListener('input', updatePackageEditDescriptionCounter);
    }
    const displayName = state.overlay.querySelector('#sdia-edit-display-name');
    if (displayName && !displayName.dataset.sdiaBound) {
      displayName.dataset.sdiaBound = '1';
      displayName.addEventListener('input', validatePackageEditFields);
    }
    bindEnterToPrimaryAction(['sdia-edit-display-name', 'sdia-edit-version', 'sdia-edit-vendor'], 'sdia-prepare-package-edit');
  }

  async function preparePackageEditInSap() {
    if (!state.overlay || state.packageEditBusy || !state.selectedPackage) return;
    const pkg = state.selectedPackage;
    const displayName = state.overlay.querySelector('#sdia-edit-display-name')?.value.trim() || '';
    const shortText = clampText(state.overlay.querySelector('#sdia-edit-short-description')?.value || '', SHORT_DESCRIPTION_MAX);
    const version = state.overlay.querySelector('#sdia-edit-version')?.value.trim() || pkg.version || '1.0.0';
    const vendor = state.overlay.querySelector('#sdia-edit-vendor')?.value.trim() || '';
    const status = state.overlay.querySelector('#sdia-package-edit-action-status');

    if (!pkg.technicalName) { showToast('Technical Name is required to open the native package Header.', 6500); return; }
    if (!displayName) {
      setFieldError(state.overlay.querySelector('#sdia-edit-display-name'), 'sdia-edit-display-name-error', 'Display Name is required.');
      showToast('Display Name is required.', 5200);
      return;
    }

    const duplicate = packageEditDisplayNameDuplicate(displayName);
    if (duplicate) {
      setFieldError(state.overlay.querySelector('#sdia-edit-display-name'), 'sdia-edit-display-name-error', `A package with Display Name “${displayName}” already exists. Choose a different name.`);
      showToast(`Package name already exists · ${displayName}`, 7200);
      if (status) {
        status.className = 'sdia-create-status error';
        status.textContent = `A package with Display Name “${displayName}” already exists. Choose a different name.`;
      }
      return;
    }

    const currentDisplay = pkg.displayName || pkg.technicalName || '';
    const currentDescription = clampText(pkg.description || '', SHORT_DESCRIPTION_MAX);
    const currentVersion = pkg.version || '1.0.0';
    const currentVendor = pkg.vendor || '';
    const hasChanges =
      normalizeText(displayName) !== normalizeText(currentDisplay) ||
      normalizeText(shortText) !== normalizeText(currentDescription) ||
      normalizeText(version) !== normalizeText(currentVersion) ||
      normalizeText(vendor) !== normalizeText(currentVendor);

    if (!hasChanges) {
      showToast('No changes detected · update at least one package value.', 6500);
      if (status) {
        status.className = 'sdia-create-status';
        status.textContent = 'No changes detected. Update at least one editable package value before opening SAP Cloud Integration.';
      }
      return;
    }

    const existing = readPackageEditTransaction();
    if (existing && Date.now() - Number(existing.createdAt || 0) <= PACKAGE_EDIT_TTL) {
      showToast(`Another package edit is already in progress · ${existing.payload.TechnicalName}`, 6500);
      return;
    }
    clearPackageEditTransaction();

    const now = Date.now();
    const tx = writePackageEditTransaction({
      id: `pkg-edit-${now}-${Math.random().toString(36).slice(2, 8)}`,
      createdAt: now,
      updatedAt: now,
      stageStartedAt: now,
      stage: 'open-package',
      attempts: {},
      selectedPackage: { ...pkg },
      payload: { TechnicalName: pkg.technicalName, DisplayName: displayName, ShortText: shortText, Version: version, Vendor: vendor }
    });
    state.packageEditBusy = true;
    syncPendingPackageEditUi(tx);
    void resumePendingPackageEdit();
  }

  async function runPackageAssessment() {
    if (activeProductProfile().id !== 'ci') {
      showToast(`${activeProductProfile().modelCode} assessment adapter is not connected in this demo.`, 5200);
      return;
    }
    const button = state.overlay.querySelector('#sdia-run-assessment');
    const status = state.overlay.querySelector('#sdia-assessment-status');
    button.disabled = true;
    button.textContent = 'Reading Tenant…';
    status.textContent = 'Loading package inventory from SAP Cloud Integration…';
    try {
      const result = await bridgeRequest('LIST_PACKAGES', {}, 30000);
      const rows = (result.results || []).map((item) => {
        const name = item.TechnicalName || item.DisplayName || item.Name || '';
        const description = item.ShortText || item.Description || '';
        return { name, description, ...evaluatePackageName(name, description) };
      }).filter((item) => item.name);
      const counts = rows.reduce((acc, row) => {
        acc.total += 1;
        if (row.status === 'Compliant') acc.compliant += 1;
        else if (row.status === 'Review') acc.review += 1;
        else acc.ungoverned += 1;
        return acc;
      }, { total: 0, compliant: 0, review: 0, ungoverned: 0 });
      state.lastAssessment = { rows, counts, at: new Date() };
      renderAssessment();
      status.textContent = `Assessment completed · ${counts.total} packages evaluated.`;
      showToast(`Package assessment completed · ${counts.compliant} compliant · ${counts.review + counts.ungoverned} require attention`, 6500);
    } catch (error) {
      status.textContent = error.message;
      showToast(`Package assessment failed · ${error.message}`, 8000);
    } finally {
      button.disabled = false;
      button.textContent = 'Run Package Assessment';
    }
  }

  function renderAssessment() {
    const assessment = state.lastAssessment;
    if (!assessment) return;
    const summary = state.overlay.querySelector('#sdia-assessment-summary');
    summary.classList.remove('sdia-hidden');
    summary.innerHTML = `
      <div><span>Total Packages</span><b>${assessment.counts.total}</b></div>
      <div><span>Compliant</span><b>${assessment.counts.compliant}</b></div>
      <div><span>Needs Review</span><b>${assessment.counts.review}</b></div>
      <div><span>Ungoverned</span><b>${assessment.counts.ungoverned}</b></div>`;
    const body = state.overlay.querySelector('#sdia-assessment-body');
    body.innerHTML = assessment.rows.length ? assessment.rows.map((row) => `
      <tr>
        <td><code>${escapeHtml(row.name)}</code></td>
        <td>${escapeHtml(row.scope)}</td>
        <td><span class="sdia-table-status ${normalizeToken(row.status)}">${escapeHtml(row.status)}</span></td>
        <td>${escapeHtml(row.finding)}</td>
      </tr>`).join('') : '<tr><td colspan="4" class="sdia-empty-row">No packages returned by the tenant.</td></tr>';
    updateAssessmentContext();
  }

  function updateAssessmentContext() {
    // Assessment owns its own real-data summary. The executive Overview no longer
    // duplicates assessment metrics in Tenant Context.
  }


  function handleAction(action) {
    if (action === 'create-package' && activeProductProfile().id === 'ci' && designContext().type !== 'contentpackage') { switchModule('package-create'); return true; }
    if (action === 'assess-packages') { switchModule('assessment'); return true; }
    if (action === 'edit-package-governance') { switchModule('package-edit-list'); loadPackageEditList(); return true; }
    if (action === 'refresh-package-map') { loadPackageGovernanceMap(); return true; }
    if (action === 'refresh-package-edit-list') { loadPackageEditList(); return true; }
    if (action === 'prepare-package-edit') { preparePackageEditInSap(); return true; }
    if (action === 'back-packages') { switchModule('packages', { push:false }); return true; }
    return false;
  }
  SDIA.CloudIntegration = SDIA.CloudIntegration || {};
  SDIA.CloudIntegration.Package = Object.freeze({ packagesMarkup, packageMapMarkup, packageEditListMarkup, packageEditFormMarkup, packageCreateMarkup, bindPackageBuilder, bindPackageEditForm, bindPackageMap, populateCatalogControls, populateSubdomains, resetBuilderFromSettings, updatePackagePreview, preparePackageInSap, loadPackageEditList, loadPackageGovernanceMap, renderPackageGovernanceMap, getPackageGovernanceOverview, populatePackageEditForm, preparePackageEditInSap, resumePendingPackageEdit, runPackageAssessment, updateAssessmentContext, handleAction });
})();
