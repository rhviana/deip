/* SDIA Cloud Integration — Create Package transition splash. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { runtimeUrl } = SDIA.Core;
  SDIA.NavigationExperience.register('create-package', {
    eyebrow:'CLOUD INTEGRATION · ODCP',
    title:'Preparing Create Package',
    subtitle:'SDIA prepares the governed package boundary while SAP Cloud Integration loads behind the Control Plane.',
    sceneMarkup:() => `<div class="sdia-package-splash-scene"><span class="sdia-package-splash-token"><img src="${runtimeUrl('src/modules/cloud-integration/package/splash/assets/package.png')}" alt=""></span><span class="sdia-package-splash-box"><i></i><b></b></span><span class="sdia-package-splash-shield"><img src="${runtimeUrl('src/shared/brand/assets/icon128.png')}" alt=""></span></div>`
  });
})();
