/* SDIA Governance v1.0.0 — Cloud Integration Package Artifacts naming governance only.
 * SDIA does not create iFlows, mappings, scripts, adapters or other native artefacts.
 * Governance here is limited to naming, semantic continuity and assessment guidance.
 */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const { state, escapeHtml, icon } = SDIA.Core;
  const designContext = (...args) => SDIA.RouteContext.designContext(...args);
  const switchModule = (...args) => SDIA.Workspace.switchModule(...args);

  const PACKAGE_ARTEFACT_TYPES = Object.freeze([
    { id:'integration-flow', label:'Integration Flow', icon:'packages', semantic:'Business integration process' },
    { id:'value-mapping', label:'Value Mapping', icon:'keyvalue', semantic:'Translation table' },
    { id:'message-mapping', label:'Message Mapping', icon:'policy', semantic:'Message transformation' },
    { id:'script-collection', label:'Script Collection', icon:'policy', semantic:'Reusable script logic' },
    { id:'integration-adapter', label:'Integration Adapter', icon:'eventmesh', semantic:'Adapter identity' },
    { id:'api', label:'API', icon:'proxy', semantic:'API contract' },
    { id:'function-libraries', label:'Function Libraries', icon:'catalog', semantic:'Reusable mapping function' },
    { id:'data-type', label:'Data Type', icon:'catalog', semantic:'Canonical data structure' },
    { id:'service-interface', label:'Service Interface', icon:'proxy', semantic:'Service contract' },
    { id:'message-type', label:'Message Type', icon:'packages', semantic:'Message contract' }
  ]);

  function artefactButtonMarkup(artefact) {
    return `<button type="button" data-sdia-action="review-package-artefact-naming" data-sdia-artefact="${artefact.id}">
      <i>${icon(artefact.icon)}</i><div><b>${escapeHtml(artefact.label)} Naming</b><p>Review ${escapeHtml(artefact.semantic.toLowerCase())} identity inside the active Domain Package boundary.</p><span>Open naming guidance →</span></div>
    </button>`;
  }

  function packageWorkspaceMarkup() {
    return `<section class="sdia-module sdia-hidden" data-sdia-view="package-workspace">
      ${SDIA.PackageArtifactsControlPlaneVisual.markup()}
      <div class="sdia-active-package-banner"><div><span>ACTIVE DOMAIN PACKAGE</span><b id="sdia-active-package-name">—</b><small>Boundary detected from <code>/shell/design/contentpackage/&lt;package&gt;</code>.</small></div></div>
      <div class="sdia-choice-grid sdia-capability-choice-grid">
        <button type="button" data-sdia-action="assess-package-iflows"><i>${icon('assessment')}</i><div><b>Assess Package Artefact Naming</b><p>Review iFlow and reusable-resource naming continuity against the active Domain Package boundary.</p><span>Open naming assessment →</span></div></button>
        ${PACKAGE_ARTEFACT_TYPES.map(artefactButtonMarkup).join('')}
      </div>
      <div class="sdia-package-scope-grid">
        <div><span>SDIA responsibility</span><b>Semantic identity & naming</b><p>Domain and Subdomain remain the primary governance keys.</p></div>
        <div><span>SAP responsibility</span><b>Native artefact lifecycle</b><p>Create, edit, deploy and save remain native SAP/user operations.</p></div>
        <div><span>Current exception</span><b>DDCR only</b><p>DDCR may generate a JavaScript policy for manual import plus endpoint-destination KVM key definitions.</p></div>
      </div>
      <div class="sdia-scope-banner"><b>Naming-governance boundary enforced</b><span>SDIA governs names and semantic continuity. It does not provision native Cloud Integration artefacts.</span></div>
    </section>`;
  }

  function openPackageArtefactAssessment() {
    state.activeArtefactType = 'package-artifacts';
    const packageName = designContext().packageId || 'Active package';
    state.capabilityReturnModule = 'package-workspace';
    state.overlay.querySelector('#sdia-capability-action-code').textContent = 'ODCP · PACKAGE ARTEFACT NAMING';
    state.overlay.querySelector('#sdia-capability-action-eyebrow').textContent = 'ACTIVE PACKAGE GOVERNANCE';
    state.overlay.querySelector('#sdia-capability-action-title').textContent = 'Assess Artefact Naming in This Package';
    state.overlay.querySelector('#sdia-capability-action-description').textContent = `Assess naming and semantic continuity for Cloud Integration artefacts inside ${packageName}.`;
    state.overlay.querySelector('#sdia-capability-action-product').textContent = 'SAP Cloud Integration';
    state.overlay.querySelector('#sdia-capability-action-model').textContent = 'ODCP — Orchestration Domain-Centric Pattern';
    state.overlay.querySelector('#sdia-capability-action-inputs').textContent = 'Active Domain Package, iFlow names, mapping/resource names and semantic purpose';
    state.overlay.querySelector('#sdia-capability-action-note').textContent = 'Read-only naming governance. SDIA does not create or save native Cloud Integration artefacts.';
    switchModule('capability-action');
  }

  function openNamingGuidance(artefactId) {
    state.activeArtefactType = artefactId || 'integration-flow';
    const artefact = PACKAGE_ARTEFACT_TYPES.find((item) => item.id === artefactId) || PACKAGE_ARTEFACT_TYPES[0];
    state.capabilityReturnModule = 'package-workspace';
    SDIA.Workspace.openCapabilityAction(
      `${artefact.label} Naming Governance`,
      'Active Domain Package, Artefact Type, Business Purpose and Governed Name',
      `SDIA provides naming guidance only for ${artefact.label}. Native artefact creation, edit and Save remain entirely in SAP.`
    );
  }

  function handleAction(action, event=null) {
    if (action === 'assess-package-iflows') { openPackageArtefactAssessment(); return true; }
    if (action === 'review-package-artefact-naming') {
      openNamingGuidance(event?.target?.closest('[data-sdia-artefact]')?.dataset.sdiaArtefact || 'integration-flow');
      return true;
    }
    return false;
  }

  SDIA.CloudIntegration = SDIA.CloudIntegration || {};
  SDIA.CloudIntegration.Iflow = Object.freeze({ PACKAGE_ARTEFACT_TYPES, packageWorkspaceMarkup, handleAction });
})();
