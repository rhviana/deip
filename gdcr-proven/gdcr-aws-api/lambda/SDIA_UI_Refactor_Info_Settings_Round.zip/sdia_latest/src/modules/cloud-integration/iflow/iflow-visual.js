/* SDIA — iFlow Control Plane visual configuration. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const CONFIG = Object.freeze({
    scope:'iflow', type:'iflow',
    eyebrow:'IFLOW LEVEL',
    title:'Orchestrate with Domain Intelligence',
    accent:'Domain Intelligence',
    description:'Design and govern iFlows aligned with domain boundaries, orchestration patterns, reusable resources and semantic naming rules.',
    assetDir:'src/modules/cloud-integration/iflow/assets/control-plane',
    footerTitle:'SDIA — iFlow Control Plane',
    footerMeta:'Patterns · Reusability · Consistency · Quality'
  });
  SDIA.VisualExperience.register(CONFIG.scope, CONFIG);
  SDIA.IflowControlPlaneVisual = Object.freeze({ markup:()=>SDIA.ControlPlaneVisual.markup(CONFIG), config:CONFIG });
})();
