/* SDIA — Package Control Plane visual configuration. */
(() => {
  'use strict';
  const SDIA = globalThis.SDIA = globalThis.SDIA || {};
  const CONFIG = Object.freeze({
    scope:'package', type:'package',
    eyebrow:'PACKAGE LEVEL',
    title:'Govern with Domain Identity',
    accent:'Domain Identity',
    description:'Define, standardize and govern packages using domain-driven semantic identity and deterministic naming boundaries.',
    assetDir:'src/modules/cloud-integration/package/assets/control-plane',
    footerTitle:'SDIA — Package Control Plane',
    footerMeta:'Domain boundary · Naming convention · Governance · Compliance'
  });
  SDIA.VisualExperience.register(CONFIG.scope, CONFIG);
  SDIA.PackageControlPlaneVisual = Object.freeze({ markup:()=>SDIA.ControlPlaneVisual.markup(CONFIG), config:CONFIG });
})();
