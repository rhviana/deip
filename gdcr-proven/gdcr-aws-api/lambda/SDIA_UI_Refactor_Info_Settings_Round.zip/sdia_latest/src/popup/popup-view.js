const STATUS_STATES = ['neutral', 'ok', 'warn', 'error'];
const ROUTE_STATES = ['detecting', 'detected', 'attention', 'error'];

export function bindUi() {
  return {
    enabled: document.getElementById('enabled'),
    openHome: document.getElementById('open-home'),
    showLauncher: document.getElementById('show-launcher'),
    status: document.getElementById('status'),
    version: document.getElementById('version'),
    capability: document.getElementById('capability'),
    governanceModel: document.getElementById('governance-model'),
    routeContext: document.querySelector('.route-context'),
    subaccountName: document.getElementById('subaccount-name'),
    tenantId: document.getElementById('tenant-id'),
    activeUser: document.getElementById('active-user'),
    activeUserEmail: document.getElementById('active-user-email'),
    activationChip: document.getElementById('activation-chip')
  };
}

export function applyTheme(value) {
  const theme = ['white', 'blue', 'cream'].includes(String(value || '').toLowerCase()) ? String(value).toLowerCase() : 'white';
  document.body.dataset.theme = theme;
}

export function setStatus(ui, message, state = 'neutral') {
  ui.status.textContent = message;
  ui.status.dataset.state = STATUS_STATES.includes(state) ? state : 'neutral';
}

export function setRouteState(ui, state) {
  ui.routeContext.dataset.state = ROUTE_STATES.includes(state) ? state : 'detecting';
}

export function setSwitch(ui, enabled) {
  ui.enabled.checked = Boolean(enabled);
  ui.enabled.setAttribute('aria-checked', String(Boolean(enabled)));
  ui.activationChip.dataset.state = enabled ? 'active' : 'inactive';
  ui.activationChip.textContent = enabled ? 'Active' : 'Inactive';
}

export function setIdentity(ui, tenant, user, fallbackHost = '') {
  ui.subaccountName.textContent = tenant?.subaccount || fallbackHost || 'Unknown subaccount';
  ui.tenantId.textContent = tenant?.tenantId || 'Unavailable';
  ui.activeUser.textContent = user?.fullName || user?.userId || 'User unavailable';
  ui.activeUserEmail.textContent = user?.email || 'No active user identity returned.';
}

export function setLoading(control, loading, controlsEnabled) {
  control.classList.toggle('is-loading', loading);
  control.setAttribute('aria-busy', String(loading));
  control.disabled = loading || !controlsEnabled;
}
