import { sendToContent } from './popup-data.js';
import { bindUi, applyTheme, setStatus, setRouteState, setSwitch, setIdentity, setLoading } from './popup-view.js';

const ui = bindUi();
ui.version.textContent = `v${chrome.runtime.getManifest().version}`;

let controlsEnabled = false;
function setControls(enabled) {
  controlsEnabled = Boolean(enabled);
  [ui.openHome, ui.showLauncher].forEach((control) => {
    if (!control.classList.contains('is-loading')) control.disabled = !controlsEnabled;
  });
}

async function refresh() {
  setRouteState(ui, 'detecting');
  ui.capability.textContent = 'Detecting Integration Suite capability…';
  ui.governanceModel.textContent = 'SDIA route detector';
  try {
    const result = await sendToContent({ type: 'sdia-get-status' });
    const enabled = Boolean(result.enabled);
    applyTheme(result.settings?.appearance);
    setIdentity(ui, result.tenant, result.user, result.host);
    setSwitch(ui, enabled);
    setControls(enabled);
    ui.capability.textContent = result.capability || 'SAP BTP Integration Suite';
    ui.governanceModel.textContent = `${result.modelCode || 'SDIA'} governance context`;
    if (result.likelySap) {
      setRouteState(ui, 'detected');
      setStatus(ui, `${result.modelCode || 'SDIA'} route detected on ${result.host}.`, 'ok');
    } else {
      setRouteState(ui, 'attention');
      setStatus(ui, `Current host: ${result.host}. Open a supported Integration Suite capability.`, 'warn');
    }
  } catch (error) {
    setSwitch(ui, false);
    applyTheme('white');
    setIdentity(ui, null, null, 'No supported tenant detected');
    setControls(false);
    setRouteState(ui, 'error');
    ui.capability.textContent = 'No supported capability detected';
    ui.governanceModel.textContent = '/shell/home · /shell/design · /shell/configure · /shell/configureeventmesh';
    setStatus(ui, error.message || 'Open or reload a supported SAP BTP Integration Suite page.', 'error');
  }
}

ui.enabled.addEventListener('change', async () => {
  const requested = ui.enabled.checked;
  ui.enabled.disabled = true;
  try {
    const result = await sendToContent({ type: 'sdia-set-enabled', enabled: requested });
    const enabled = Boolean(result.enabled);
    applyTheme(result.settings?.appearance);
    setIdentity(ui, result.tenant, result.user, result.host);
    setSwitch(ui, enabled);
    setControls(enabled);
    if (enabled) {
      setRouteState(ui, 'detected');
      setStatus(ui, 'Enabled on this governance route.', 'ok');
    } else {
      setRouteState(ui, 'attention');
      setStatus(ui, 'SDIA button is hidden until a supported governance route is active.', 'warn');
    }
  } catch (error) {
    setSwitch(ui, !requested);
    setStatus(ui, error.message, 'error');
  } finally {
    ui.enabled.disabled = false;
  }
});

ui.openHome.addEventListener('click', async () => {
  setLoading(ui.openHome, true, controlsEnabled);
  try {
    await sendToContent({ type: 'sdia-open-workspace' });
    window.close();
  } catch (error) {
    setStatus(ui, error.message, 'error');
    setLoading(ui.openHome, false, controlsEnabled);
  }
});

ui.showLauncher.addEventListener('click', async () => {
  setLoading(ui.showLauncher, true, controlsEnabled);
  try {
    await sendToContent({ type: 'sdia-show-launcher' });
    setStatus(ui, 'SDIA button restored.', 'ok');
  } catch (error) {
    setStatus(ui, error.message, 'error');
  } finally {
    setLoading(ui.showLauncher, false, controlsEnabled);
  }
});

refresh();
