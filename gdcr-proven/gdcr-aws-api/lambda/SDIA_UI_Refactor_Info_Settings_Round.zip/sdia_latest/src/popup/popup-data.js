export async function currentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

export function friendlyError(error) {
  const message = error && error.message ? error.message : String(error);
  if (/Receiving end does not exist|Could not establish connection/i.test(message)) {
    return 'SDIA is not running on this page. Open or reload a supported SAP Integration Suite page.';
  }
  if (/No active tab/i.test(message)) {
    return 'No active tab available. Focus a tab and try again.';
  }
  return message;
}

export async function sendToContent(message) {
  const tab = await currentTab();
  if (!tab?.id) throw new Error('No active tab.');
  try {
    return await chrome.tabs.sendMessage(tab.id, message);
  } catch (error) {
    throw new Error(friendlyError(error));
  }
}
