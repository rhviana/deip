/* SDIA Governance for SAP BTP Integration Suite v1.0.0 — bootstrap/orchestrator only. */
(() => {
  'use strict';
  if (globalThis.__SDIA_GOVERNANCE_V020_CONTROL_CENTER__) return;
  globalThis.__SDIA_GOVERNANCE_V020_CONTROL_CENTER__ = true;
  const SDIA = globalThis.SDIA;
  const { state, loadState, saveSettings, normalizeText } = SDIA.Core;
  const Route = SDIA.RouteContext;
  const Router = SDIA.WorkspaceRouter;

  function resolveEnabled() {
    const routeSupported = Route.isSupportedGovernanceRoute();
    const explicit = state.settings.enabledHosts?.[location.hostname];
    if (typeof explicit === 'boolean') return explicit && routeSupported;
    return Boolean(state.settings.autoDetectSap && routeSupported);
  }

  function mount() {
    if (!state.enabled) return;
    SDIA.Launcher.mount({ onOpen: () => SDIA.Workspace.openControlCenter() });
    SDIA.Launcher.setVisible(Boolean(state.settings.launcherVisible));
    SDIA.Launcher.syncGeometry();
    SDIA.Workspace.applyProductContext();
  }

  function bindNativeCreateAwareness() {
    document.addEventListener('click', (event) => {
      if (Route.activeProductProfile().id !== 'ci') return;
      const context = Route.designContext();
      if (context.type !== 'design') return;
      const button = event.target instanceof Element ? event.target.closest('button,[role="button"],.sapMBtn') : null;
      if (!button || button.closest(`#${SDIA.Core.constants.ROOT_ID}, #${SDIA.Core.constants.OVERLAY_ID}`)) return;
      const text = normalizeText(`${button.innerText || button.textContent || ''} ${button.getAttribute('aria-label') || ''} ${button.title || ''}`);
      if (text !== 'create' && text !== 'create package') return;
      state.pendingPackageName = '';
      setTimeout(() => { if (Route.designContext().type === 'package-create') SDIA.Workspace.openControlCenter('package-create'); }, 450);
    }, true);
  }

  function monitorRoute() {
    // Adaptive route polling: the same URL-change detection mechanism as before,
    // but the cadence is conditional — fast (300ms) only while the extension is
    // enabled for the current context, with backoff to 1000ms on unsupported
    // routes or when the extension is disabled for this host. Polling is fully
    // paused while the document is hidden and resumed on visibilitychange.
    const ACTIVE_INTERVAL = 300;
    const BACKOFF_INTERVAL = 1000;
    let last = `${location.pathname}${location.search}${location.hash}`;
    let lastContextKey = SDIA.Navigation.currentContextKey();
    let timer = null;
    let activeInterval = 0;

    function onRouteChanged() {
      const current = `${location.pathname}${location.search}${location.hash}`;

      // Persist the UI under the context that is being left, before the SPA route
      // changes which session bucket would otherwise receive the draft.
      if (state.overlay) SDIA.Navigation.persistControlCenterState('route-before-change', { contextKey:lastContextKey });
      last = current;
      const context = Route.designContext();
      const newContextKey = SDIA.Navigation.currentContextKey();

      if (state.pendingPackageName && context.type === 'contentpackage' && normalizeText(context.packageId) === normalizeText(state.pendingPackageName)) {
        SDIA.Workspace.showToast(`Package saved successfully · ${state.pendingPackageName}`, 6500); state.pendingPackageName = '';
      }
      state.enabled = resolveEnabled();
      if (!state.enabled) { SDIA.Launcher.setVisible(false); SDIA.Workspace.closeControlCenter(); lastContextKey = newContextKey; return; }
      if (!state.mounted) mount();
      SDIA.Launcher.setVisible(Boolean(state.settings.launcherVisible)); SDIA.Launcher.syncGeometry(); SDIA.Workspace.applyProductContext();

      const overlayOpen = Boolean(state.overlay && !state.overlay.classList.contains('sdia-hidden'));
      const keepActiveForm = Router.isFormModule() && overlayOpen;
      if (keepActiveForm) {
        SDIA.Workspace.refreshContextPanel();
        SDIA.Navigation.updateWorkspaceChrome();
        void SDIA.CloudIntegration?.Package?.resumePendingPackageEdit?.();
        lastContextKey = newContextKey;
        return;
      }

      if (overlayOpen) {
        const allowed = Router.allowedModulesForProduct();
        const snapshot = SDIA.Navigation.readPersistedControlCenterState(newContextKey);
        const restoreWorkspace = state.settings.restoreLastWorkspaceInSession !== false;
        const target = restoreWorkspace && snapshot?.activeModule && allowed.includes(snapshot.activeModule) ? snapshot.activeModule : (state.settings.startNewContextInOverview === false && allowed.includes(state.activeModule) ? state.activeModule : 'overview');
        SDIA.Workspace.switchModule(target, { push:false, silentPersist:true });
        if (snapshot && state.settings.preserveDraftSession !== false) SDIA.Navigation.restoreControlCenterFields(snapshot);
        SDIA.Navigation.persistControlCenterState('route-context-ready', { contextKey:newContextKey, open:true });
      } else {
        state.activeModule = 'overview';
        state.internalHistory = [];
      }
      SDIA.Workspace.refreshContextPanel();
      void SDIA.CloudIntegration?.Package?.resumePendingPackageEdit?.();
      lastContextKey = newContextKey;
    }

    function tick() {
      const current = `${location.pathname}${location.search}${location.hash}`;
      if (current !== last) onRouteChanged();
      // Reschedule if the enabled/disabled state changed the desired cadence.
      const desired = state.enabled ? ACTIVE_INTERVAL : BACKOFF_INTERVAL;
      if (desired !== activeInterval) start();
    }

    function stop() {
      if (timer !== null) { clearInterval(timer); timer = null; }
      activeInterval = 0;
    }

    function start() {
      stop();
      if (document.hidden) return; // paused while the tab is hidden
      activeInterval = state.enabled ? ACTIVE_INTERVAL : BACKOFF_INTERVAL;
      timer = setInterval(tick, activeInterval);
    }

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) stop();
      else start();
    });
    start();
  }


  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    (async () => {
      if (message?.type === 'sdia-get-status') {
        const profile = Route.activeProductProfile();
        let tenant = null;
        let user = null;
        try { tenant = await SDIA.TenantContext?.get?.(); } catch (_) {}
        try { user = await SDIA.UserContext?.get?.(); } catch (_) {}
        sendResponse({ enabled:state.enabled, likelySap:Route.isLikelySapCi(), host:location.hostname, settings:state.settings, product:profile.id, capability:profile.capability, modelCode:profile.modelCode, tenant, user }); return;
      }
      if (message?.type === 'sdia-set-enabled') {
        const requested = Boolean(message.enabled); state.settings.enabledHosts[location.hostname] = requested; state.enabled = requested && Route.isSupportedGovernanceRoute(); await saveSettings();
        if (state.enabled) mount(); else { SDIA.Launcher.destroy(); state.overlay?.remove(); state.overlay = null; }
        let tenant = null;
        let user = null;
        try { tenant = await SDIA.TenantContext?.get?.(); } catch (_) {}
        try { user = await SDIA.UserContext?.get?.(); } catch (_) {}
        sendResponse({ ok:true, enabled:state.enabled, supportedRoute:Route.isSupportedGovernanceRoute(), host:location.hostname, settings:state.settings, tenant, user }); return;
      }
      if (message?.type === 'sdia-show-launcher') {
        state.settings.launcherVisible = true;
        if (!Route.isSupportedGovernanceRoute()) { await saveSettings(); sendResponse({ ok:false, error:'Unsupported SDIA Governance route.' }); return; }
        if (!state.enabled) { state.enabled = true; state.settings.enabledHosts[location.hostname] = true; await saveSettings(); mount(); }
        SDIA.Launcher.setVisible(true); SDIA.Launcher.syncGeometry(); await saveSettings(); sendResponse({ ok:true }); return;
      }
      if (message?.type === 'sdia-open-workspace') { await SDIA.Workspace.openControlCenter(); sendResponse({ ok:true }); return; }
      sendResponse({ ok:false });
    })(); return true;
  });

  async function init() {
    await loadState();
    state.enabled = resolveEnabled(); if (state.enabled) mount();
    try {
      const snapshot = SDIA.Navigation.readPersistedControlCenterState();
      if (snapshot?.open && Route.isSupportedGovernanceRoute()) {
        const allowed = Router.allowedModulesForProduct();
        const restoredModule = snapshot.activeModule && allowed.includes(snapshot.activeModule) ? snapshot.activeModule : 'overview';
        setTimeout(() => SDIA.Workspace.openControlCenter(restoredModule, { restoreSnapshot:snapshot }), 500);
      }
    } catch (_) {}
    window.addEventListener('beforeunload', () => SDIA.Navigation.persistControlCenterState('beforeunload'));
    bindNativeCreateAwareness(); monitorRoute();
    setTimeout(() => { void SDIA.CloudIntegration?.Package?.resumePendingPackageEdit?.(); }, 450);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once:true }); else init();
})();
