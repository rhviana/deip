# SDIA Governance Extension — Code Ownership Map

This extension follows the same ownership principle as SDIA itself: every artefact belongs to a defined semantic/technical boundary.

## Shared transversal services

- `src/shared/brand/` — SDIA product identity assets only.
- `src/shared/icons/` — generic reusable UI icons only.
- `src/shared/vendors/` — reusable vendor logos only.
- `src/shared/control-plane-experience/` — Control Plane color rotation and visual state.
- `src/shared/control-plane-visual/` — shared Control Plane visual renderer.
- `src/shared/navigation-experience/` — optional navigation splash lifecycle only.

Shared code must not contain Package, APIM, Event Mesh, Security Materials or Keystore business rules.

## Cloud Integration

- `src/modules/cloud-integration/package/` — Package governance, visual and Package splash.
- `src/modules/cloud-integration/artifacts/` — Package Artefacts governance, visual and Artefacts splash.
- `src/modules/cloud-integration/iflow/` — iFlow visual/governance concerns.

## API Management

- `src/modules/api-management/apim/` — APIM governance, visual and APIM splash.

## Event

- `src/modules/event-mesh/eventmesh/` — Event Mesh/AEM governance, visual and transition splash.

## Security

- `src/modules/security/security-materials/` — Security Materials/Credentials visual and transition splash.
- `src/modules/security/keystore/` — Certificates/Keystore visual and transition splash.
- `src/modules/security/shared/` — security-only shared governance logic.

## UI shell

- `src/ui/home/` — SDIA Home only.
- `src/ui/launcher/` — floating launcher only.
- `src/ui/navigation/` — Control Center menu/navigation only.
- `src/ui/workspace-shell/` — shared shell layout only.
- `src/ui/control-plane-home/` — local SDIA HOME action only; never changes the SAP URL.
- `src/ui/capability-action/` — generic capability-action surface only.

## Context

- `src/context/tenant-context.js` — tenant/subaccount resolver.
- `src/context/user-context.js` — active SAP user resolver.

## Rules

1. New domain-specific JS/CSS/assets go inside the owning domain folder.
2. Assets are stored beside the module that owns them.
3. Shared folders are allowed only for genuinely transversal concerns.
4. `workspace.js` remains an orchestrator; business logic belongs to modules.
5. Removed UI or behavior must have its dead JS/CSS/assets removed as part of the same change.
6. Backend licensing, trial and plan enforcement are intentionally out of scope until the UI/control-plane baseline is complete.
