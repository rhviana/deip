/*
 * SDIA Governance v0.2.0 - SAP page-world bridge
 * Uses SAPUI5 controls in the page context to open the native package creation
 * route and fill the native Header form. It never saves autonomously; the user always owns the native SAP Save action.
 */
(() => {
  'use strict';

  if (window.__SDIA_GOVERNANCE_PAGE_BRIDGE_V020__) return;
  window.__SDIA_GOVERNANCE_PAGE_BRIDGE_V020__ = true;

  const SOURCE_IN = 'SDIA_GOVERNANCE_EXTENSION';
  const SOURCE_OUT = 'SDIA_GOVERNANCE_PAGE';

  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  /*
   * Bridge hardening (session nonce + strict payload validation).
   *
   * The content script (ISOLATED world) generates a random per-session nonce and
   * delivers it here exactly once per session via an SDIA_SESSION handshake message.
   * Only the FIRST nonce received is accepted; later attempts to overwrite it are
   * ignored. Every request must carry that nonce and a payload that matches the
   * per-type allowlist below (fields, scalar types and maximum lengths); anything
   * else is dropped before reaching the SAP automation handlers.
   *
   * Residual risk, documented deliberately: this script runs in the page's MAIN
   * world, which is inherently observable by the host SAP page. A page script that
   * actively listens to window message traffic can read the nonce and forge valid
   * envelopes. The nonce raises the bar against casual/opportunistic scripts that
   * inject bridge commands WITHOUT observing the bus; it does not defend against
   * the host page itself. The strict payload validation additionally constrains
   * what any forged message can make the bridge do (no new fields, bounded sizes).
   * host_permissions remain restricted to SAP domains (manifest.json).
   */
  let sessionNonce = null;
  const targetOrigin = location.origin;

  // Allowlist of accepted request types -> { field: maxLength }. Only scalar
  // string/number values are accepted; everything else is stripped.
  const PAYLOAD_SCHEMAS = Object.freeze({
    PREPARE_PACKAGE: Object.freeze({ Category:120, SupportedPlatforms:120, TechnicalName:200, DisplayName:200, ShortText:600, Description:2048, Version:40, Vendor:160, Products:400 }),
    OPEN_PACKAGE_FOR_EDIT: Object.freeze({ TechnicalName:200, technicalName:200, DisplayName:200, ShortText:600, Description:2048, Version:40, Vendor:160 }),
    ENABLE_PACKAGE_EDIT: Object.freeze({ TechnicalName:200, technicalName:200, DisplayName:200, ShortText:600, Description:2048, Version:40, Vendor:160 }),
    APPLY_PACKAGE_EDIT_VALUES: Object.freeze({ TechnicalName:200, technicalName:200, DisplayName:200, ShortText:600, Description:2048, Version:40, Vendor:160 }),
    PREPARE_ARTEFACT: Object.freeze({ nativeLabel:120, artefactLabel:120, displayName:200, name:200, technicalName:200, shortDescription:600, description:2048 }),
    NAVIGATE_EXECUTION_CONTEXT: Object.freeze({ route:200, Route:200, targetProduct:40 }),
    OPEN_IFLOW_FROM_MAP: Object.freeze({ TechnicalName:200, technicalName:200, IFlowName:200, iflowName:200, Name:200 }),
    LIST_PACKAGE_ARTIFACTS: Object.freeze({ PackageId:200, packageId:200, TechnicalName:200, technicalName:200, DisplayName:200 }),
    LIST_APIM_INVENTORY: Object.freeze({}),
    LIST_PACKAGES: Object.freeze({})
  });

  function sanitizePayload(type, payload) {
    const schema = PAYLOAD_SCHEMAS[type];
    if (!schema || !payload || typeof payload !== 'object' || Array.isArray(payload)) return {};
    const clean = {};
    for (const [field, maxLength] of Object.entries(schema)) {
      const value = payload[field];
      if (typeof value === 'string') clean[field] = value.slice(0, maxLength);
      else if (typeof value === 'number' && Number.isFinite(value)) clean[field] = String(value).slice(0, maxLength);
    }
    return clean;
  }

  function isValidRequestId(requestId) {
    return typeof requestId === 'string' && requestId.length > 0 && requestId.length <= 100;
  }

  function requestSessionNonce() {
    window.postMessage({ source: SOURCE_OUT, type: 'SDIA_SESSION_HELLO' }, targetOrigin);
  }

  // Handshake: announce ourselves (the ISOLATED-world client loads later, at
  // document_idle) and accept the first session nonce it delivers.
  window.addEventListener('message', (event) => {
    if (event.source !== window || event.origin !== targetOrigin) return;
    const message = event.data;
    if (!message || message.source !== SOURCE_IN || message.type !== 'SDIA_SESSION') return;
    if (sessionNonce) return; // first nonce wins; never overwritten within the session
    if (typeof message.nonce === 'string' && message.nonce.length >= 16 && message.nonce.length <= 128) {
      sessionNonce = message.nonce;
    }
  });
  requestSessionNonce();

  const SHORT_DESCRIPTION_MAX = 255;
  const COMPLIANCE_EXPECTATION_KEY = 'sdia:package-compliance-expectation:v0.2.0';
  const COMPLIANCE_EXPECTATION_TTL = 20 * 60 * 1000;
  let complianceExpectation = null;
  let complianceSaveBypassOnce = false;

  function clampShortDescription(value) {
    return String(value || '').replace(/\s+/g, ' ').trim().slice(0, SHORT_DESCRIPTION_MAX);
  }

  function normalize(value) {
    return String(value || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[\r\n\t]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function post(type, requestId, payload = {}) {
    // Responses echo the session nonce so the ISOLATED-world client can reject
    // results/progress forged by page scripts that never saw the handshake.
    window.postMessage({ source: SOURCE_OUT, type, requestId, nonce: sessionNonce, ...payload }, targetOrigin);
  }

  async function waitFor(predicate, timeout = 15000, interval = 120, label = 'condition') {
    const startedAt = Date.now();
    let lastError = null;
    while (Date.now() - startedAt < timeout) {
      try {
        const value = predicate();
        if (value) return value;
      } catch (error) {
        lastError = error;
      }
      await delay(interval);
    }
    const suffix = lastError ? ` (${lastError.message || lastError})` : '';
    throw new Error(`Timed out waiting for ${label}${suffix}`);
  }

  function routeText() {
    return `${location.pathname || ''}${location.search || ''}${location.hash || ''}`;
  }

  function isDesignRoute() {
    return /\/shell\/design\/?(?:[?#]|$)/i.test(routeText()) &&
      !/\/shell\/design\/(?:package|contentpackage)\b/i.test(routeText());
  }

  function isPackageCreateRoute() {
    const route = routeText();
    return /\/shell\/design\/package\b/i.test(route) && /(?:[?&#]|\b)create=true\b/i.test(route);
  }

  function allControls() {
    const controls = new Set();
    const sap = window.sap;
    const addRegistry = (registry) => {
      if (!registry || typeof registry !== 'object') return;
      Object.values(registry).forEach((control) => control && controls.add(control));
    };
    try { addRegistry(sap?.ui?.core?.Element?.registry?.all?.()); } catch (_) {}
    try { addRegistry(sap?.ui?.core?.Control?.registry?.all?.()); } catch (_) {}
    try { addRegistry(sap?.ui?.getCore?.()?.mElements); } catch (_) {}
    return [...controls];
  }

  function metadataName(control) {
    try { return control?.getMetadata?.()?.getName?.() || ''; }
    catch (_) { return ''; }
  }

  function controlDom(control) {
    try { return control?.getDomRef?.() || null; }
    catch (_) { return null; }
  }

  function domVisible(element) {
    if (!(element instanceof Element) || !element.isConnected) return false;
    const style = getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function controlVisible(control) {
    const dom = controlDom(control);
    if (!domVisible(dom)) return false;
    try { if (typeof control.getVisible === 'function' && !control.getVisible()) return false; } catch (_) {}
    try { if (typeof control.getEnabled === 'function' && !control.getEnabled()) return false; } catch (_) {}
    return true;
  }

  function controlText(control) {
    const values = [];
    const getters = ['getText', 'getTitle', 'getValue', 'getName', 'getTooltip_AsString'];
    for (const getter of getters) {
      try {
        const value = control?.[getter]?.();
        if (typeof value === 'string') values.push(value);
      } catch (_) {}
    }
    const dom = controlDom(control);
    if (dom) values.push(dom.innerText || dom.textContent || '', dom.getAttribute('aria-label') || '', dom.title || '');
    return normalize(values.join(' '));
  }

  function contextText(control) {
    const values = [controlText(control)];
    let current = control;
    for (let depth = 0; current && depth < 5; depth += 1) {
      try {
        const parent = current.getParent?.();
        if (!parent || parent === current) break;
        current = parent;
        values.push(controlText(current));
      } catch (_) { break; }
    }
    const dom = controlDom(control);
    if (dom) {
      const region = dom.closest('header,main,section,[role="region"],.sapMBar,.sapMPage');
      if (region) values.push((region.innerText || '').slice(0, 1500));
    }
    return normalize(values.join(' '));
  }

  const CREATE_LABELS = new Set(['create', 'create package']);

  function controlCreateSignals(control) {
    const values = [];
    const getters = ['getText', 'getTitle', 'getTooltip_AsString'];
    for (const getter of getters) {
      try {
        const value = control?.[getter]?.();
        if (typeof value === 'string') values.push(value);
      } catch (_) {}
    }
    const dom = controlDom(control);
    if (dom) {
      values.push(
        dom.innerText || dom.textContent || '',
        dom.getAttribute('aria-label') || '',
        dom.getAttribute('title') || ''
      );
    }
    return [...new Set(values.map(normalize).filter(Boolean))];
  }

  function domCreateSignals(element) {
    return [...new Set([
      element.innerText || element.textContent || '',
      element.getAttribute('aria-label') || '',
      element.getAttribute('title') || ''
    ].map(normalize).filter(Boolean))];
  }

  function hasExactCreateSignal(signals) {
    return signals.some((value) => CREATE_LABELS.has(value));
  }

  function findCreateButtonControl() {
    const candidates = allControls()
      .filter((control) => /Button$/i.test(metadataName(control)) || typeof control?.firePress === 'function')
      .filter(controlVisible)
      .map((control) => {
        const signals = controlCreateSignals(control);
        if (!hasExactCreateSignal(signals)) return null;
        const text = signals.find((value) => CREATE_LABELS.has(value)) || signals[0] || '';
        const context = contextText(control);
        const id = control.getId?.() || '';
        let score = text === 'create package' ? 220 : 200;
        if (/design|integration packages/.test(context)) score += 30;
        if (/customtypesystems|custom-type-system/i.test(id)) score -= 220;
        if (typeof control.firePress === 'function') score += 20;
        return { control, score, text, id, signals };
      })
      .filter((item) => item && item.score >= 180)
      .sort((a, b) => b.score - a.score);
    return candidates[0] || null;
  }

  function findCreateButtonDom() {
    const candidates = [...document.querySelectorAll('button,[role="button"],a,.sapMBtn')]
      .filter((element) => domVisible(element))
      .map((element) => {
        const signals = domCreateSignals(element);
        if (!hasExactCreateSignal(signals)) return null;
        const text = signals.find((value) => CREATE_LABELS.has(value)) || signals[0] || '';
        const context = normalize((element.closest('header,main,section,.sapMPage')?.innerText || '').slice(0, 1200));
        let score = text === 'create package' ? 210 : 190;
        if (/integration packages|design/.test(context)) score += 25;
        if (signals.some((value) => /custom type systems|integration flow|copy|import|delete|save|cancel/.test(value))) score -= 220;
        return { element, score, text, signals };
      })
      .filter((item) => item && item.score >= 180)
      .sort((a, b) => b.score - a.score);
    return candidates[0] || null;
  }

  function createLikeDiagnostics() {
    const ui5 = allControls()
      .filter(controlVisible)
      .map((control) => ({
        id: control.getId?.() || '',
        text: controlText(control),
        name: metadataName(control)
      }))
      .filter((item) => /\bcreate\b/.test(item.text))
      .slice(0, 8);
    const dom = [...document.querySelectorAll('button,[role="button"],a,.sapMBtn')]
      .filter(domVisible)
      .map((element) => ({ text: normalize(`${element.innerText || element.textContent || ''} ${element.getAttribute('aria-label') || ''} ${element.title || ''}`) }))
      .filter((item) => /\bcreate\b/.test(item.text))
      .slice(0, 8);
    return { ui5, dom };
  }

  function fireControlPress(control) {
    if (!control) return false;
    try {
      control.firePress?.({});
      return true;
    } catch (_) {}
    const dom = controlDom(control);
    if (dom) return clickDom(dom);
    return false;
  }

  function clickDom(element) {
    if (!element) return false;
    const target = element.matches('button,a,[role="button"]')
      ? element
      : element.querySelector('button,a,[role="button"]') || element;
    try { target.scrollIntoView({ block: 'center', inline: 'center' }); } catch (_) {}
    try { target.focus({ preventScroll: true }); } catch (_) {}
    const eventInit = { bubbles: true, cancelable: true, composed: true, view: window, button: 0, buttons: 1 };
    for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
      try {
        const Ctor = type.startsWith('pointer') && window.PointerEvent ? PointerEvent : MouseEvent;
        target.dispatchEvent(new Ctor(type, eventInit));
      } catch (_) {}
    }
    return true;
  }

  async function openNativeCreateRoute(requestId) {
    if (isPackageCreateRoute()) return { method: 'already-open' };
    if (!isDesignRoute()) throw new Error('Open Integrations and APIs (/shell/design) before creating a package.');

    await waitFor(() => window.sap?.ui?.getCore?.(), 12000, 150, 'SAPUI5 core');

    let ui5Candidate = null;
    try {
      ui5Candidate = await waitFor(findCreateButtonControl, 8000, 150, 'exact native SAP Create Package action');
    } catch (_) {}
    if (ui5Candidate) {
      post('PREPARE_PACKAGE_PROGRESS', requestId, { phase: 'opening-route', detail: `SAPUI5 ${ui5Candidate.id || ui5Candidate.text}` });
      fireControlPress(ui5Candidate.control);
      try {
        await waitFor(isPackageCreateRoute, 6000, 100, 'native SAP package creation route');
        return { method: 'sapui5-firePress', controlId: ui5Candidate.id };
      } catch (_) {}
    }

    let domCandidate = null;
    try {
      domCandidate = await waitFor(findCreateButtonDom, 3000, 150, 'exact native DOM Create Package action');
    } catch (_) {}
    if (domCandidate) {
      post('PREPARE_PACKAGE_PROGRESS', requestId, { phase: 'opening-route', detail: 'native DOM Create control' });
      clickDom(domCandidate.element);
      try {
        await waitFor(isPackageCreateRoute, 6000, 100, 'native SAP package creation route');
        return { method: 'native-dom-click', label: domCandidate.text };
      } catch (_) {}
    }

    const diagnostics = {
      route: routeText(),
      ui5Candidate: ui5Candidate ? { id: ui5Candidate.id, text: ui5Candidate.text, score: ui5Candidate.score } : null,
      domCandidate: domCandidate ? { text: domCandidate.text, score: domCandidate.score } : null,
      createLike: createLikeDiagnostics()
    };
    throw new Error(`SAP Create action did not open the native package Header. Diagnostics: ${JSON.stringify(diagnostics)}`);
  }


  function routePackageId() {
    const match = routeText().match(/\/shell\/design\/contentpackage\/([^/?#]+)/i);
    if (!match) return '';
    try { return decodeURIComponent(match[1]); } catch (_) { return match[1]; }
  }

  function samePackageId(left, right) {
    return normalize(left) === normalize(right);
  }

  function isTargetPackageRoute(technicalName) {
    return Boolean(technicalName) && samePackageId(routePackageId(), technicalName);
  }

  function isTargetPackageHeaderRoute(technicalName) {
    return isTargetPackageRoute(technicalName) && /(?:[?&#]|\b)section=HEADER\b/i.test(routeText());
  }


  const EDIT_LABELS = new Set(['edit']);

  function exactSignals(control) {
    const values = [];
    const getters = ['getText', 'getTitle', 'getTooltip_AsString'];
    for (const getter of getters) {
      try {
        const value = control?.[getter]?.();
        if (typeof value === 'string') values.push(value);
      } catch (_) {}
    }
    const dom = controlDom(control);
    if (dom) values.push(dom.innerText || dom.textContent || '', dom.getAttribute('aria-label') || '', dom.getAttribute('title') || '');
    return [...new Set(values.map(normalize).filter(Boolean))];
  }

  function findExactActionControl(labels, contextPattern = null) {
    const candidates = allControls()
      .filter((control) => (/Button$|Link$|Tab$|Item$/i.test(metadataName(control)) || typeof control?.firePress === 'function'))
      .filter(controlVisible)
      .map((control) => {
        const signals = exactSignals(control);
        const exact = signals.find((value) => labels.has(value));
        if (!exact) return null;
        const context = contextText(control);
        let score = 220;
        if (contextPattern && contextPattern.test(context)) score += 30;
        if (typeof control.firePress === 'function') score += 20;
        return { control, score, text: exact, id: control.getId?.() || '' };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score);
    return candidates[0] || null;
  }

  function findExactActionDom(labels, contextPattern = null) {
    const candidates = [...document.querySelectorAll('button,[role="button"],a,[role="tab"],.sapMBtn')]
      .filter((element) => domVisible(element))
      .filter((element) => !element.closest('#sdia-control-center,#sdia-governance-root'))
      .map((element) => {
        const signals = domCreateSignals(element);
        const exact = signals.find((value) => labels.has(value));
        if (!exact) return null;
        const context = normalize((element.closest('header,main,section,.sapMPage')?.innerText || '').slice(0, 1600));
        let score = 210;
        if (contextPattern && contextPattern.test(context)) score += 25;
        return { element, score, text: exact };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score);
    return candidates[0] || null;
  }


  function labels() {
    return allControls().filter((control) => /Label$/i.test(metadataName(control)) && controlVisible(control));
  }

  function exactLabelScore(text, intent) {
    const clean = normalize(text).replace(/^\*+/, '').replace(/:$/, '').trim();
    const patterns = {
      displayName: ['name', 'package name', 'display name'],
      technicalName: ['technical name', 'technicalname'],
      shortText: ['short description', 'short text', 'shorttext'],
      version: ['version'],
      vendor: ['vendor']
    };
    const expected = patterns[intent] || [];
    if (expected.includes(clean)) return 100;
    if (expected.some((item) => clean.includes(item))) return 55;
    return 0;
  }

  function controlByLabel(intent) {
    const core = window.sap?.ui?.getCore?.();
    const ranked = labels().map((label) => {
      const text = label.getText?.() || controlText(label);
      const score = exactLabelScore(text, intent);
      let target = null;
      try {
        const labelFor = label.getLabelFor?.();
        if (labelFor) target = core?.byId?.(labelFor) || null;
      } catch (_) {}
      if (!target) {
        const dom = controlDom(label);
        if (dom) {
          const htmlFor = dom.getAttribute('for');
          if (htmlFor) {
            const input = document.getElementById(htmlFor);
            if (input) target = input;
          }
        }
      }
      return { label, target, score, text };
    }).filter((item) => item.score > 0 && item.target).sort((a, b) => b.score - a.score);
    return ranked[0] || null;
  }

  function domFieldByLabel(intent) {
    const selectors = ['label', '.sapMLabel', '[role="label"]'];
    const nodes = [...document.querySelectorAll(selectors.join(','))].filter(domVisible);
    const ranked = nodes.map((label) => {
      const text = label.innerText || label.textContent || '';
      const score = exactLabelScore(text, intent);
      let input = null;
      const htmlFor = label.getAttribute('for');
      if (htmlFor) input = document.getElementById(htmlFor);
      if (!input) {
        const row = label.closest('div,tr,li,section');
        input = row?.querySelector('input,textarea') || null;
      }
      return { label, input, score, text };
    }).filter((item) => item.score > 0 && item.input && domVisible(item.input)).sort((a, b) => b.score - a.score);
    return ranked[0] || null;
  }

  function resolveField(intent) {
    return controlByLabel(intent) || domFieldByLabel(intent);
  }

  function setNativeDomValue(input, value) {
    const descriptor = Object.getOwnPropertyDescriptor(input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype, 'value');
    descriptor?.set?.call(input, String(value));
    input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
    input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
    input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, composed: true, key: 'Unidentified' }));
  }

  function setField(resolved, value) {
    if (!resolved || value === undefined || value === null) return false;
    const target = resolved.target || resolved.input;
    if (!target) return false;
    if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
      setNativeDomValue(target, value);
      return true;
    }
    try { target.setValue?.(String(value)); } catch (_) {}
    try { target.fireLiveChange?.({ value: String(value), newValue: String(value) }); } catch (_) {}
    try { target.fireChange?.({ value: String(value), newValue: String(value) }); } catch (_) {}
    try { target.setProperty?.('value', String(value), true); } catch (_) {}
    try {
      const dom = target.getFocusDomRef?.() || target.getDomRef?.();
      if (dom instanceof HTMLInputElement || dom instanceof HTMLTextAreaElement) setNativeDomValue(dom, value);
    } catch (_) {}
    try { window.sap?.ui?.getCore?.().applyChanges?.(); } catch (_) {}
    return true;
  }

  function readField(resolved) {
    const target = resolved?.target || resolved?.input;
    if (!target) return '';
    if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return target.value || '';
    try { return target.getValue?.() || ''; } catch (_) { return ''; }
  }

  function findNativePackageForm() {
    if (!isPackageCreateRoute()) return null;
    const displayName = resolveField('displayName');
    const technicalName = resolveField('technicalName');
    const shortText = resolveField('shortText');
    const version = resolveField('version');
    const vendor = resolveField('vendor');
    if (!displayName || !shortText) return null;
    return { displayName, technicalName, shortText, version, vendor };
  }

  async function fillNativePackageForm(payload, requestId) {
    const form = await waitFor(findNativePackageForm, 20000, 140, 'native SAP package Header fields');
    post('PREPARE_PACKAGE_PROGRESS', requestId, { phase: 'filling-fields', detail: 'Name and governed description' });

    setField(form.displayName, payload.DisplayName || payload.TechnicalName);
    await delay(450);

    // The native page normally derives Technical Name from Name. We still set the
    // UI5 property when the control is available, even if the HTML input is read-only.
    if (form.technicalName) setField(form.technicalName, payload.TechnicalName);
    const governedShortText = clampShortDescription(payload.ShortText || payload.Description || payload.TechnicalName);
    setField(form.shortText, governedShortText);
    if (form.version) setField(form.version, payload.Version || '1.0.0');
    if (form.vendor && payload.Vendor) setField(form.vendor, payload.Vendor);

    await delay(650);

    // Re-apply after SAP's Name liveChange has finished recalculating the technical name.
    if (normalize(readField(form.displayName)) !== normalize(payload.DisplayName || payload.TechnicalName)) {
      setField(form.displayName, payload.DisplayName || payload.TechnicalName);
    }
    if (form.technicalName && normalize(readField(form.technicalName)) !== normalize(payload.TechnicalName)) {
      setField(form.technicalName, payload.TechnicalName);
    }
    if (normalize(readField(form.shortText)) !== normalize(governedShortText)) {
      setField(form.shortText, governedShortText);
    }

    return {
      route: routeText(),
      values: {
        displayName: readField(form.displayName),
        technicalName: readField(form.technicalName),
        shortTextLength: readField(form.shortText).length,
        version: readField(form.version),
        vendor: readField(form.vendor)
      }
    };
  }




  function fieldEditable(resolved) {
    const target = resolved?.target || resolved?.input;
    if (!target) return false;
    if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return !target.disabled && !target.readOnly;
    try { if (typeof target.getEnabled === 'function' && !target.getEnabled()) return false; } catch (_) {}
    try { if (typeof target.getEditable === 'function' && !target.getEditable()) return false; } catch (_) {}
    return true;
  }

  function findNativePackageEditForm(technicalName) {
    if (!isTargetPackageHeaderRoute(technicalName)) return null;
    const displayName = resolveField('displayName');
    const technicalNameField = resolveField('technicalName');
    const shortText = resolveField('shortText');
    const version = resolveField('version');
    const vendor = resolveField('vendor');
    if (!displayName || !shortText || !fieldEditable(displayName) || !fieldEditable(shortText)) return null;
    return { displayName, technicalName: technicalNameField, shortText, version, vendor };
  }


  async function fillNativePackageEditForm(form, payload, requestId) {
    post('APPLY_PACKAGE_EDIT_VALUES_PROGRESS', requestId, { phase: 'filling-fields', detail: 'Display Name, Short Description, Version and Vendor' });
    const displayName = payload.DisplayName || payload.TechnicalName;
    const governedShortText = clampShortDescription(payload.ShortText || payload.Description || '');
    setField(form.displayName, displayName);
    setField(form.shortText, governedShortText);
    if (form.version) setField(form.version, payload.Version || '1.0.0');
    if (form.vendor) setField(form.vendor, payload.Vendor || '');
    await delay(650);
    if (normalize(readField(form.displayName)) !== normalize(displayName)) setField(form.displayName, displayName);
    if (normalize(readField(form.shortText)) !== normalize(governedShortText)) setField(form.shortText, governedShortText);
    if (form.version && normalize(readField(form.version)) !== normalize(payload.Version || '1.0.0')) setField(form.version, payload.Version || '1.0.0');
    if (form.vendor && normalize(readField(form.vendor)) !== normalize(payload.Vendor || '')) setField(form.vendor, payload.Vendor || '');
    return {
      route: routeText(),
      values: {
        displayName: readField(form.displayName),
        technicalName: readField(form.technicalName),
        shortTextLength: readField(form.shortText).length,
        version: readField(form.version),
        vendor: readField(form.vendor)
      }
    };
  }

  function packageRouteFragment(technicalName) {
    return `/shell/design/contentpackage/${encodeURIComponent(String(technicalName || '').trim())}`;
  }

  function controlHref(control) {
    try {
      const value = control?.getHref?.();
      if (typeof value === 'string' && value) return value;
    } catch (_) {}
    try {
      const value = control?.getProperty?.('href');
      if (typeof value === 'string' && value) return value;
    } catch (_) {}
    const dom = controlDom(control);
    return dom?.getAttribute?.('href') || dom?.closest?.('a[href]')?.getAttribute?.('href') || '';
  }


  const EXECUTION_ROUTE_CONFIG = Object.freeze({
    '/shell/design': Object.freeze({
      product:'ci',
      labels:['integrations and apis','cloud integration','design'],
      ready:(route) => /\/shell\/design\/?(?:[?#]|$)/i.test(route) && !/\/shell\/design\/(?:package|contentpackage)\b/i.test(route)
    }),
    '/shell/configure': Object.freeze({
      product:'apim',
      labels:['api management','configure'],
      ready:(route) => /\/shell\/configure\/?(?:[?#]|$)/i.test(route) && !/\/shell\/configureeventmesh\b/i.test(route)
    }),
    '/shell/configureeventmesh': Object.freeze({
      product:'eventmesh',
      labels:['event mesh','advanced event mesh','event mesh / aem'],
      ready:(route) => /\/shell\/configureeventmesh\/?(?:[?#]|$)/i.test(route)
    }),
    '/shell/monitoring/SecurityMaterials': Object.freeze({
      product:'security',
      labels:['security materials','security material','security'],
      ready:(route) => /\/shell\/monitoring\/SecurityMaterials\/?(?:[?#]|$)/i.test(route)
    }),
    '/shell/monitoring/Keystore': Object.freeze({
      product:'security',
      labels:['keystore','certificate','certificates'],
      ready:(route) => /\/shell\/monitoring\/Keystore\/?(?:[?#]|$)/i.test(route)
    })
  });

  function normalizedExecutionRoute(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    try {
      const url = new URL(raw, location.origin);
      const path = url.pathname.replace(/\/+$/, '') || '/';
      return EXECUTION_ROUTE_CONFIG[path] ? path : '';
    } catch (_) {
      const path = raw.split(/[?#]/)[0].replace(/\/+$/, '');
      return EXECUTION_ROUTE_CONFIG[path] ? path : '';
    }
  }

  function executionRouteReady(targetRoute) {
    const config = EXECUTION_ROUTE_CONFIG[targetRoute];
    return Boolean(config?.ready?.(routeText()));
  }

  function executionRouteHrefMatch(href, targetRoute) {
    if (!href) return false;
    let decoded = href;
    try { decoded = decodeURIComponent(href); } catch (_) {}
    return href.includes(targetRoute) || decoded.includes(targetRoute);
  }

  function executionSurfaceFingerprint() {
    const candidates = [...document.querySelectorAll('main,[role="main"],.sapUshellShellContent,.sapMPage,.sapUiView')]
      .filter(domVisible)
      .filter((element) => !element.closest('#sdia-control-center,#sdia-governance-root,#sdia-compliance-warning'))
      .map((element) => ({ element, area:Math.max(1, element.getBoundingClientRect().width * element.getBoundingClientRect().height) }))
      .sort((a,b) => b.area - a.area);
    const root = candidates[0]?.element || document.body;
    const text = normalize((root?.innerText || root?.textContent || '').slice(0, 5000));
    const nodes = root?.querySelectorAll?.('a,button,[role="button"],[role="link"],.sapMList,.sapMTable')?.length || 0;
    return `${text}|${nodes}`;
  }

  function nativeSapBusyVisible() {
    return [...document.querySelectorAll('.sapUiLocalBusyIndicator,.sapMBusyIndicator,.sapUiBlockLayer,.sapMDialogBlockLayerInit,[aria-busy="true"]')]
      .filter((element) => !element.closest('#sdia-control-center,#sdia-governance-root,#sdia-compliance-warning'))
      .some(domVisible);
  }

  async function waitForExecutionContextReady(targetRoute, beforeFingerprint, timeout = 7000) {
    const startedAt = Date.now();
    await waitFor(() => {
      if (!executionRouteReady(targetRoute)) return false;
      const changed = executionSurfaceFingerprint() !== beforeFingerprint;
      const settled = !nativeSapBusyVisible();
      // Some SAP routes update the shell surface without replacing the main root.
      // After a short grace period, a settled matching route is sufficient.
      return settled && (changed || Date.now() - startedAt >= 850);
    }, timeout, 90, `execution context ${targetRoute}`);
    await delay(90);
  }

  async function softNavigateExecutionRoute(targetRoute, beforeFingerprint, requestId) {
    const absolute = new URL(targetRoute, location.origin).toString();
    post('NAVIGATE_EXECUTION_CONTEXT_PROGRESS', requestId, { phase:'opening-native-route', detail:`soft route ${targetRoute}` });

    try {
      history.pushState({ sdia:true, targetRoute }, '', absolute);
      window.dispatchEvent(new PopStateEvent('popstate', { state:history.state }));
      window.dispatchEvent(new Event('hashchange'));
      document.dispatchEvent(new CustomEvent('sdia:native-route-request', { detail:{ route:targetRoute } }));
      await waitForExecutionContextReady(targetRoute, beforeFingerprint, 3200);
      return { method:'history-pushstate' };
    } catch (_) {}

    throw new Error(`The SAP shell did not confirm ${targetRoute}. SDIA kept the current page open and did not force a reload.`);
  }

  function findExecutionRouteControl(targetRoute) {
    const config = EXECUTION_ROUTE_CONFIG[targetRoute];
    if (!config) return null;
    const candidates = allControls().filter(controlVisible).map((control) => {
      const href = controlHref(control);
      const text = controlText(control);
      const signals = exactSignals(control);
      let score = 0;
      if (executionRouteHrefMatch(href, targetRoute)) score += 420;
      for (const label of config.labels) {
        if (signals.includes(label)) score += 260;
        else if (text === label) score += 240;
        else if (text.includes(label)) score += 90;
      }
      if (typeof control?.firePress === 'function') score += 45;
      if (href) score += 20;
      if (/SideNavigation|NavigationListItem|Link$|Button$/i.test(metadataName(control))) score += 25;
      return score >= 220 ? { control, score, href, text, id:control.getId?.() || '' } : null;
    }).filter(Boolean).sort((a,b) => b.score - a.score);
    return candidates[0] || null;
  }

  function findExecutionRouteDom(targetRoute) {
    const config = EXECUTION_ROUTE_CONFIG[targetRoute];
    if (!config) return null;
    const candidates = [...document.querySelectorAll('a[href],[role="link"],button,[role="button"],.sapTntNavLIItem,.sapMBtn')]
      .filter(domVisible)
      .filter((element) => !element.closest('#sdia-control-center,#sdia-governance-root,#sdia-compliance-warning'))
      .map((element) => {
        const href = element.getAttribute('href') || element.closest('a[href]')?.getAttribute('href') || '';
        const text = normalize([element.innerText || element.textContent || '', element.getAttribute('aria-label') || '', element.getAttribute('title') || ''].join(' '));
        let score = 0;
        if (executionRouteHrefMatch(href, targetRoute)) score += 430;
        for (const label of config.labels) {
          if (text === label) score += 250;
          else if (text.includes(label)) score += 85;
        }
        if (element.matches('a[href],[role="link"]')) score += 30;
        return score >= 210 ? { element, score, href, text } : null;
      })
      .filter(Boolean)
      .sort((a,b) => b.score - a.score);
    return candidates[0] || null;
  }

  async function navigateExecutionContext(payload = {}, requestId) {
    const targetRoute = normalizedExecutionRoute(payload.route || payload.Route || '');
    if (!targetRoute) throw new Error('Unsupported SDIA execution route.');
    if (executionRouteReady(targetRoute)) return { route:routeText(), targetRoute, method:'already-open' };

    const beforeFingerprint = executionSurfaceFingerprint();
    post('NAVIGATE_EXECUTION_CONTEXT_PROGRESS', requestId, { phase:'locating-native-route', detail:targetRoute });

    // FAST PATH 1 — exact rendered SAP link/button. This avoids spending several
    // seconds probing the full UI5 control tree when the shell already exposes
    // the target execution context in the DOM.
    const dom = findExecutionRouteDom(targetRoute);
    if (dom) {
      post('NAVIGATE_EXECUTION_CONTEXT_PROGRESS', requestId, { phase:'opening-native-route', detail:dom.text || targetRoute });
      clickDom(dom.element);
      try {
        await waitForExecutionContextReady(targetRoute, beforeFingerprint, 7000);
        return { route:routeText(), targetRoute, method:'native-dom-navigation' };
      } catch (_) {}
    }

    // FAST PATH 2 — SAPUI5 native press. Do not wait ten seconds for the core;
    // the Integration Suite shell normally has it ready already. A short grace
    // period covers slower tenants without making every click feel delayed.
    let ui5 = null;
    if (window.sap?.ui?.getCore?.()) ui5 = findExecutionRouteControl(targetRoute);
    else {
      try {
        await waitFor(() => window.sap?.ui?.getCore?.(), 1200, 90, 'SAPUI5 core');
        ui5 = findExecutionRouteControl(targetRoute);
      } catch (_) {}
    }
    if (ui5) {
      post('NAVIGATE_EXECUTION_CONTEXT_PROGRESS', requestId, { phase:'opening-native-route', detail:ui5.text || ui5.id || targetRoute });
      fireControlPress(ui5.control);
      try {
        await waitForExecutionContextReady(targetRoute, beforeFingerprint, 7000);
        return { route:routeText(), targetRoute, method:'sapui5-native-navigation', controlId:ui5.id || '' };
      } catch (_) {}
    }

    // FAST PATH 3 — SPA history route. This stays in the current document so the
    // SDIA form remains in front until the SAP target surface is confirmed ready.
    const soft = await softNavigateExecutionRoute(targetRoute, beforeFingerprint, requestId);
    return { route:routeText(), targetRoute, method:soft?.method || 'soft-route' };
  }

  function findPackageNavigationDom(technicalName) {
    const normalizedName = normalize(technicalName);
    const routeFragment = packageRouteFragment(technicalName);
    const candidates = [...document.querySelectorAll('a[href],[role="link"],button,[role="button"],tr,.sapMLIB')]
      .filter((element) => !element.closest('#sdia-control-center,#sdia-governance-root'))
      .map((element) => {
        const href = element.getAttribute?.('href') || element.closest?.('a[href]')?.getAttribute?.('href') || '';
        let decodedHref = href;
        try { decodedHref = decodeURIComponent(href); } catch (_) {}
        const text = normalize((element.innerText || element.textContent || '').trim());
        let score = 0;
        if (href.includes(routeFragment) || decodedHref.includes(`/shell/design/contentpackage/${technicalName}`)) score += 360;
        if (text === normalizedName) score += 280;
        else if (text.includes(normalizedName)) score += 120;
        if (/integration packages|content package|package/i.test(normalize((element.closest('main,section,.sapMPage')?.innerText || '').slice(0, 1200)))) score += 25;
        if (element.matches('a[href],[role="link"]')) score += 35;
        return { element, href, text, score };
      })
      .filter((item) => item.score >= 180)
      .sort((a,b) => b.score - a.score);
    return candidates[0] || null;
  }

  function findPackageNavigationControl(technicalName) {
    const normalizedName = normalize(technicalName);
    const routeFragment = packageRouteFragment(technicalName);
    const candidates = [];
    for (const source of allControls()) {
      const sourceSignals = exactSignals(source);
      const sourceText = normalize(controlText(source));
      const sourceMatch = sourceSignals.includes(normalizedName) || sourceText === normalizedName;
      let current = source;
      let depth = 0;
      while (current && depth < 5) {
        const href = controlHref(current);
        let decodedHref = href;
        try { decodedHref = decodeURIComponent(href); } catch (_) {}
        let score = 0;
        if (href.includes(routeFragment) || decodedHref.includes(`/shell/design/contentpackage/${technicalName}`)) score += 360;
        if (sourceMatch) score += 260 - depth * 20;
        const currentDom = controlDom(current);
        const pressable = typeof current?.firePress === 'function' || Boolean(href) || Boolean(currentDom?.matches?.('a,button,[role="button"],[role="link"]'));
        if (typeof current?.firePress === 'function') score += 45;
        if (href) score += 25;
        if (pressable && score >= 220 && controlVisible(current)) candidates.push({ control:current, score, href, id:current.getId?.() || '', text:sourceText });
        try { current = current.getParent?.() || null; } catch (_) { current = null; }
        depth += 1;
      }
    }
    candidates.sort((a,b) => b.score - a.score);
    return candidates[0] || null;
  }

  async function openPackageForEditStep(payload, requestId) {
    const technicalName = payload.TechnicalName || payload.technicalName || '';
    if (!technicalName) throw new Error('Technical Name is required to open the native package.');
    if (isTargetPackageRoute(technicalName)) return { alreadyOpen: true, route: routeText(), technicalName };
    if (!isDesignRoute()) throw new Error(`Open Integrations and APIs before editing ${technicalName}.`);

    await waitFor(() => window.sap?.ui?.getCore?.(), 10000, 150, 'SAPUI5 core');

    // Prefer SAPUI5 firePress: this follows the same in-app navigation model used by
    // the native package list and keeps the SDIA document/overlay alive.
    const ui5Candidate = findPackageNavigationControl(technicalName);
    if (ui5Candidate) {
      post('OPEN_PACKAGE_FOR_EDIT_PROGRESS', requestId, { phase: 'opening-package', detail: `SAPUI5 package row ${technicalName}` });
      fireControlPress(ui5Candidate.control);
      try {
        await waitFor(() => isTargetPackageRoute(technicalName), 8000, 120, `native package route ${technicalName}`);
        return { method:'sapui5-package-navigation', controlId:ui5Candidate.id, technicalName, route:routeText() };
      } catch (_) {}
    }

    const domCandidate = findPackageNavigationDom(technicalName);
    if (domCandidate) {
      post('OPEN_PACKAGE_FOR_EDIT_PROGRESS', requestId, { phase: 'opening-package', detail: `native package link ${technicalName}` });
      clickDom(domCandidate.element);
      try {
        await waitFor(() => isTargetPackageRoute(technicalName), 8000, 120, `native package route ${technicalName}`);
        return { method:'native-dom-package-navigation', technicalName, route:routeText() };
      } catch (_) {}
    }

    throw new Error(`SAP package ${technicalName} was not opened through the native package list. Refresh the SAP package list and try again.`);
  }

  async function enablePackageEditStep(payload, requestId) {
    const technicalName = payload.TechnicalName || payload.technicalName || '';
    if (!technicalName) throw new Error('Technical Name is required to enable native package Edit.');
    if (!isTargetPackageRoute(technicalName)) throw new Error(`The selected package ${technicalName} is not the active SAP package.`);

    const alreadyEditable = findNativePackageEditForm(technicalName);
    if (alreadyEditable) return { alreadyEditable: true, route: routeText(), technicalName };

    await waitFor(() => window.sap?.ui?.getCore?.(), 10000, 150, 'SAPUI5 core');
    let editControl = null;
    try { editControl = await waitFor(() => findExactActionControl(EDIT_LABELS, /package|header|short description|vendor|version|integration/i), 6500, 120, 'exact native SAP Edit action'); } catch (_) {}
    if (editControl) {
      post('ENABLE_PACKAGE_EDIT_PROGRESS', requestId, { phase: 'locating-edit', detail: editControl.id || editControl.text || 'Edit' });
      setTimeout(() => fireControlPress(editControl.control), 80);
      return { scheduled: true, method: 'sapui5-edit', controlId: editControl.id || '', route: routeText(), technicalName };
    }

    const editDom = findExactActionDom(EDIT_LABELS, /package|header|short description|vendor|version|integration/i);
    if (!editDom) throw new Error('The exact native SAP Edit action was not found for the selected package.');
    post('ENABLE_PACKAGE_EDIT_PROGRESS', requestId, { phase: 'locating-edit', detail: 'native DOM Edit' });
    setTimeout(() => clickDom(editDom.element), 80);
    return { scheduled: true, method: 'native-dom-edit', route: routeText(), technicalName };
  }

  async function applyPackageEditValuesStep(payload, requestId) {
    const technicalName = payload.TechnicalName || payload.technicalName || '';
    if (!technicalName) throw new Error('Technical Name is required to apply package metadata.');
    if (!isTargetPackageRoute(technicalName)) throw new Error(`The selected package ${technicalName} is not the active SAP package.`);
    post('APPLY_PACKAGE_EDIT_VALUES_PROGRESS', requestId, { phase: 'filling-fields', detail: 'Waiting for editable native SAP Header fields' });
    const form = await waitFor(() => findNativePackageEditForm(technicalName), 16000, 140, 'editable native SAP package Header fields');
    return fillNativePackageEditForm(form, payload || {}, requestId);
  }


  function isContentPackageRoute() {
    return /\/shell\/design\/contentpackage\/[^/?#]+/i.test(routeText());
  }

  function findAddButtonControl() {
    const candidates = allControls()
      .filter((control) => /Button$/i.test(metadataName(control)) || typeof control?.firePress === 'function')
      .filter(controlVisible)
      .map((control) => {
        const text = controlText(control);
        const context = contextText(control);
        let score = 0;
        if (text === 'add') score += 160;
        else if (/\badd\b/.test(text)) score += 70;
        if (/migrate|delete|action|save|cancel/.test(`${text} ${context}`)) score -= 70;
        if (/value mapping|integration flow|message mapping|script collection|data type/.test(context)) score += 25;
        if (typeof control.firePress === 'function') score += 20;
        return { control, score, text, id: control.getId?.() || '' };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score);
    return candidates[0] || null;
  }

  function findAddButtonDom() {
    const candidates = [...document.querySelectorAll('button,[role="button"],a,.sapMBtn')]
      .filter((element) => domVisible(element))
      .map((element) => {
        const text = normalize(`${element.innerText || element.textContent || ''} ${element.getAttribute('aria-label') || ''} ${element.title || ''}`);
        let score = 0;
        if (text === 'add') score += 140;
        else if (/\badd\b/.test(text)) score += 55;
        if (/migrate|delete|action|save|cancel/.test(text)) score -= 70;
        return { element, score, text };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score);
    return candidates[0] || null;
  }

  function menuItemScore(text, nativeLabel) {
    const clean = normalize(text);
    const target = normalize(nativeLabel);
    if (!clean || !target) return 0;
    if (clean === target) return 180;
    if (clean.includes(target)) return 120;
    const singularTarget = target.replace(/s$/,'');
    if (singularTarget && clean.includes(singularTarget)) return 80;
    return 0;
  }

  function findMenuItemControl(nativeLabel) {
    const candidates = allControls()
      .filter(controlVisible)
      .map((control) => {
        const text = controlText(control);
        const name = metadataName(control);
        let score = menuItemScore(text, nativeLabel);
        if (/Item|Button|List/i.test(name)) score += 15;
        return { control, score, text, id: control.getId?.() || '', name };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score);
    return candidates[0] || null;
  }

  function findMenuItemDom(nativeLabel) {
    const candidates = [...document.querySelectorAll('[role="menuitem"],li,button,[role="button"],a,.sapMSelectListItem,.sapMCLI,.sapUiMnuItm')]
      .filter(domVisible)
      .map((element) => {
        const text = normalize(`${element.innerText || element.textContent || ''} ${element.getAttribute('aria-label') || ''} ${element.title || ''}`);
        return { element, score: menuItemScore(text, nativeLabel), text };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score);
    return candidates[0] || null;
  }

  async function openNativeArtefactRoute(payload, requestId) {
    if (!isContentPackageRoute()) throw new Error('Open a content package before creating package artefacts.');
    await waitFor(() => window.sap?.ui?.getCore?.(), 12000, 150, 'SAPUI5 core');
    const addControl = findAddButtonControl();
    if (addControl) {
      post('PREPARE_ARTEFACT_PROGRESS', requestId, { phase: 'opening-menu', detail: `SAPUI5 ${addControl.id || addControl.text}` });
      fireControlPress(addControl.control);
    } else {
      const addDom = findAddButtonDom();
      if (!addDom) throw new Error('SAP Add action was not found in the active package toolbar.');
      post('PREPARE_ARTEFACT_PROGRESS', requestId, { phase: 'opening-menu', detail: 'native DOM Add control' });
      clickDom(addDom.element);
    }

    const nativeLabel = payload.nativeLabel || payload.artefactLabel || 'Integration Flow';
    const item = await waitFor(() => findMenuItemControl(nativeLabel) || findMenuItemDom(nativeLabel), 9000, 120, `${nativeLabel} Add menu item`);
    post('PREPARE_ARTEFACT_PROGRESS', requestId, { phase: 'selecting-artefact', detail: nativeLabel });
    if (item.control) fireControlPress(item.control);
    else clickDom(item.element);
    await delay(900);
    return { method: item.control ? 'sapui5-menu-item' : 'dom-menu-item', item: item.id || item.text || nativeLabel, route: routeText() };
  }

  function genericArtefactFormFields() {
    const displayName = resolveField('displayName') || resolveField('technicalName');
    const technicalName = resolveField('technicalName');
    const shortText = resolveField('shortText');
    const version = resolveField('version');
    const vendor = resolveField('vendor');
    return { displayName, technicalName, shortText, version, vendor };
  }

  async function fillNativeArtefactForm(payload, requestId) {
    post('PREPARE_ARTEFACT_PROGRESS', requestId, { phase: 'filling-fields', detail: 'Governed name and short description' });
    const form = await waitFor(() => {
      const fields = genericArtefactFormFields();
      return fields.displayName || fields.shortText || fields.technicalName ? fields : null;
    }, 18000, 150, 'native SAP artefact Header fields');
    const name = payload.displayName || payload.name || payload.technicalName;
    const description = clampShortDescription(payload.shortDescription || payload.description || name);
    if (form.displayName) setField(form.displayName, name);
    await delay(350);
    if (form.technicalName) setField(form.technicalName, payload.technicalName || name);
    if (form.shortText) setField(form.shortText, description);
    await delay(500);
    if (form.displayName && normalize(readField(form.displayName)) !== normalize(name)) setField(form.displayName, name);
    if (form.technicalName && normalize(readField(form.technicalName)) !== normalize(payload.technicalName || name)) setField(form.technicalName, payload.technicalName || name);
    if (form.shortText && normalize(readField(form.shortText)) !== normalize(description)) setField(form.shortText, description);
    return {
      route: routeText(),
      values: {
        name: form.displayName ? readField(form.displayName) : '',
        technicalName: form.technicalName ? readField(form.technicalName) : '',
        shortTextLength: form.shortText ? readField(form.shortText).length : 0
      }
    };
  }

  async function prepareArtefact(payload, requestId) {
    post('PREPARE_ARTEFACT_PROGRESS', requestId, { phase: 'locating-add', detail: 'SAP package toolbar' });
    const navigation = await openNativeArtefactRoute(payload || {}, requestId);
    post('PREPARE_ARTEFACT_PROGRESS', requestId, { phase: 'route-opened', detail: routeText() });
    let form = null;
    try {
      form = await fillNativeArtefactForm(payload || {}, requestId);
    } catch (error) {
      form = { warning: `Native artefact form opened, but governed field binding was not completed: ${error.message}`, route: routeText() };
    }
    return { navigation, form };
  }


  async function preparePackage(payload, requestId) {
    post('PREPARE_PACKAGE_PROGRESS', requestId, { phase: 'locating-create', detail: 'SAP Design page' });
    const navigation = await openNativeCreateRoute(requestId);
    post('PREPARE_PACKAGE_PROGRESS', requestId, { phase: 'route-opened', detail: routeText() });
    const form = await fillNativePackageForm(payload, requestId);
    return { navigation, form };
  }



  async function fetchAllWorkspacePages(initialUrl) {
    const all = [];
    let url = initialUrl;
    let guard = 0;
    while (url && guard < 100) {
      guard += 1;
      const response = await fetch(url, {
        method: 'GET',
        credentials: 'include',
        headers: { Accept: 'application/json' }
      });
      const data = await response.json().catch(() => null);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const results = data?.d?.results || (data?.d && !Array.isArray(data.d) ? [data.d] : []);
      if (Array.isArray(results)) all.push(...results);
      url = data?.d?.__next || data?.__next || null;
    }
    return all;
  }

  async function listPackages() {
    const url = '/odata/1.0/workspace.svc/ContentEntities.ContentPackages?$format=json';
    const results = await fetchAllWorkspacePages(url);
    const byTechnicalName = new Map();

    results.forEach((item) => {
      const technicalName = String(item?.TechnicalName || '').trim();
      if (!technicalName) return;
      const key = normalize(technicalName);
      if (!byTechnicalName.has(key)) byTechnicalName.set(key, item);
    });

    return { url, results: [...byTechnicalName.values()] };
  }


  async function readApimCollection(url) {
    try {
      const results = await fetchAllWorkspacePages(url);
      return { url, results, ok:true, error:'' };
    } catch (error) {
      return { url, results:[], ok:false, error:error?.message || String(error) };
    }
  }

  async function listApimInventory() {
    const providersUrl = '/apiportal/api/1.0/Management.svc/APIProviders?$format=json';
    const certificateStoresUrl = '/apiportal/api/1.0/Management.svc/CertificateStores?$format=json';
    const keyMapEntriesUrl = '/apiportal/api/1.0/Management.svc/KeyMapEntries?forceUpdateFromRT=true&$skip=0&$top=500&$orderby=life_cycle/changed_at%20desc&$format=json';
    const [providers, certificateStores, keyMapEntries] = await Promise.all([
      readApimCollection(providersUrl),
      readApimCollection(certificateStoresUrl),
      readApimCollection(keyMapEntriesUrl)
    ]);
    return { providers, certificateStores, keyMapEntries };
  }


  function odataResults(data) {
    if (Array.isArray(data?.d?.results)) return data.d.results;
    if (Array.isArray(data?.value)) return data.value;
    if (Array.isArray(data)) return data;
    if (data?.d && typeof data.d === 'object') return [data.d];
    return [];
  }

  async function fetchODataJson(url, options = {}) {
    const response = await fetch(url, {
      method: 'GET',
      credentials: 'include',
      headers: { Accept: 'application/json' }
    });
    const data = await response.json().catch(() => null);
    if (response.status === 404 && options.emptyOn404) {
      return { url, data, results: [], status:404, empty:true };
    }
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return { url, data, results: odataResults(data), status:response.status };
  }



  function findArtifactsTabControl() {
    const candidates = allControls()
      .filter(controlVisible)
      .map((control) => {
        const signals = exactSignals(control);
        const match = signals.find((value) => value === 'artifacts' || /^artifacts\s*\(\d+\)$/.test(value));
        if (!match) return null;
        let score = 240;
        if (/Tab$|Item$|Filter$/i.test(metadataName(control))) score += 30;
        if (typeof control?.firePress === 'function') score += 20;
        if (/overview|artifacts|documents|tags|package/.test(contextText(control))) score += 20;
        return { control, score, id:control.getId?.() || '', text:match };
      })
      .filter(Boolean)
      .sort((a,b) => b.score - a.score);
    return candidates[0] || null;
  }

  function findArtifactsTabDom() {
    const candidates = [...document.querySelectorAll('[role="tab"],button,a,.sapMITBFilter,.sapMBtn')]
      .filter(domVisible)
      .filter((element) => !element.closest('#sdia-control-center,#sdia-governance-root'))
      .map((element) => {
        const signals = domCreateSignals(element);
        const match = signals.find((value) => value === 'artifacts' || /^artifacts\s*\(\d+\)$/.test(value));
        if (!match) return null;
        return { element, score:220, text:match };
      })
      .filter(Boolean);
    return candidates[0] || null;
  }

  function iflowRouteFragment(technicalName, iflowName) {
    return `/shell/design/contentpackage/${encodeURIComponent(String(technicalName || '').trim())}/integrationflows/${encodeURIComponent(String(iflowName || '').trim())}`;
  }

  function isTargetIflowRoute(technicalName, iflowName) {
    const route = routeText();
    const target = iflowRouteFragment(technicalName, iflowName);
    if (route.includes(target)) return true;
    try { return decodeURIComponent(route).includes(`/shell/design/contentpackage/${technicalName}/integrationflows/${iflowName}`); }
    catch (_) { return false; }
  }

  function findExactIflowRouteControl(technicalName, iflowName) {
    const target = iflowRouteFragment(technicalName, iflowName);
    const decodedTarget = `/shell/design/contentpackage/${technicalName}/integrationflows/${iflowName}`;
    return allControls().filter(controlVisible).map((control) => {
      const href = controlHref(control);
      if (!href) return null;
      let decoded = href;
      try { decoded = decodeURIComponent(href); } catch (_) {}
      const match = href.includes(target) || decoded.includes(decodedTarget);
      if (!match) return null;
      let score = 400;
      if (typeof control?.firePress === 'function') score += 40;
      if (/Link$|ListItem$|ColumnListItem$/i.test(metadataName(control))) score += 20;
      return { control, score, href, id:control.getId?.() || '' };
    }).filter(Boolean).sort((a,b) => b.score - a.score)[0] || null;
  }

  function findExactIflowRouteDom(technicalName, iflowName) {
    const target = iflowRouteFragment(technicalName, iflowName);
    const decodedTarget = `/shell/design/contentpackage/${technicalName}/integrationflows/${iflowName}`;
    return [...document.querySelectorAll('a[href],[role="link"]')].filter(domVisible).filter((element) => !element.closest('#sdia-control-center,#sdia-governance-root')).map((element) => {
      const href = element.getAttribute('href') || '';
      let decoded = href;
      try { decoded = decodeURIComponent(href); } catch (_) {}
      if (!(href.includes(target) || decoded.includes(decodedTarget))) return null;
      return { element, href, score:420 };
    }).filter(Boolean).sort((a,b) => b.score - a.score)[0] || null;
  }


  function findIflowByNameControl(iflowName) {
    const expected = normalize(iflowName);
    const candidates = allControls().filter(controlVisible).map((control) => {
      const text = controlText(control);
      const context = contextText(control);
      if (!(text === expected || text.includes(expected))) return null;
      let score = text === expected ? 300 : 190;
      if (/artifacts|integration flow|iflow/.test(context)) score += 55;
      if (typeof control?.firePress === 'function') score += 45;
      if (/Link$|ListItem$|ColumnListItem$|ObjectIdentifier$/i.test(metadataName(control))) score += 25;
      return score >= 240 ? { control, score, id:control.getId?.() || '', text } : null;
    }).filter(Boolean).sort((a,b) => b.score - a.score);
    return candidates[0] || null;
  }

  function findIflowByNameDom(iflowName) {
    const expected = normalize(iflowName);
    const candidates = [...document.querySelectorAll('a,[role="link"],button,[role="button"],tr,[role="row"],.sapMLIB')]
      .filter(domVisible)
      .filter((element) => !element.closest('#sdia-control-center,#sdia-governance-root'))
      .map((element) => {
        const text = normalize((element.innerText || element.textContent || '').trim());
        if (!(text === expected || text.includes(expected))) return null;
        let score = text === expected ? 300 : 190;
        const context = normalize((element.closest('main,section,.sapMPage')?.innerText || '').slice(0, 1600));
        if (/artifacts|integration flow|iflow/.test(context)) score += 45;
        if (element.matches('a,[role="link"]')) score += 30;
        return score >= 230 ? { element, score, text } : null;
      })
      .filter(Boolean)
      .sort((a,b) => b.score - a.score);
    return candidates[0] || null;
  }

  async function openIflowFromGovernanceMap(payload = {}, requestId) {
    const technicalName = String(payload.TechnicalName || payload.technicalName || '').trim();
    const iflowName = String(payload.IFlowName || payload.iflowName || payload.Name || '').trim();
    if (!technicalName || !iflowName) throw new Error('Package Technical Name and Integration Flow Name are required.');
    if (isTargetIflowRoute(technicalName, iflowName)) return { technicalName, iflowName, route:routeText(), method:'already-open' };

    await waitFor(() => window.sap?.ui?.getCore?.(), 10000, 150, 'SAPUI5 core');

    // Prefer the exact native iFlow link. Never promote a parent package row when
    // the requested Integration Flow has its own route.
    let exactControl = findExactIflowRouteControl(technicalName, iflowName);
    let exactDom = exactControl ? null : findExactIflowRouteDom(technicalName, iflowName);

    if (!exactControl && !exactDom && !isTargetPackageRoute(technicalName)) {
      if (!isDesignRoute()) throw new Error(`Open Integrations and APIs before opening ${iflowName}.`);
      const packageControl = findPackageNavigationControl(technicalName);
      if (packageControl) fireControlPress(packageControl.control);
      else {
        const packageDom = findPackageNavigationDom(technicalName);
        if (!packageDom) throw new Error(`SAP package ${technicalName} was not found in the native package list.`);
        clickDom(packageDom.element);
      }
      await waitFor(() => isTargetPackageRoute(technicalName), 9000, 120, `native package route ${technicalName}`);
    }

    if (!exactControl && !exactDom) {
      let tab = null;
      try { tab = await waitFor(findArtifactsTabControl, 5000, 120, 'native SAP Artifacts tab'); } catch (_) {}
      if (tab) fireControlPress(tab.control);
      else {
        const tabDom = findArtifactsTabDom();
        if (tabDom) clickDom(tabDom.element);
      }
      await delay(180);
      try { exactControl = await waitFor(() => findExactIflowRouteControl(technicalName, iflowName), 6500, 120, `exact Integration Flow route ${iflowName}`); } catch (_) {}
      if (!exactControl) exactDom = findExactIflowRouteDom(technicalName, iflowName);
    }

    if (exactControl || exactDom) {
      if (exactControl) fireControlPress(exactControl.control);
      else clickDom(exactDom.element);
      try { await waitFor(() => isTargetIflowRoute(technicalName, iflowName), 7000, 120, `Integration Flow route ${iflowName}`); } catch (_) {}
      return { technicalName, iflowName, route:routeText(), method:exactControl ? 'sapui5-exact-iflow-route' : 'native-exact-iflow-route' };
    }

    // Final fallback stays inside the native SAP application: locate the rendered
    // Integration Flow row by its exact Name and press it. SDIA never forces a
    // browser-level location.assign/reload for artefact navigation.
    const byNameControl = findIflowByNameControl(iflowName);
    const byNameDom = byNameControl ? null : findIflowByNameDom(iflowName);
    if (byNameControl || byNameDom) {
      if (byNameControl) fireControlPress(byNameControl.control);
      else clickDom(byNameDom.element);
      await waitFor(() => isTargetIflowRoute(technicalName, iflowName), 9000, 120, `Integration Flow route ${iflowName}`);
      return { technicalName, iflowName, route:routeText(), method:byNameControl ? 'sapui5-iflow-name-navigation' : 'native-iflow-name-navigation' };
    }

    throw new Error(`The native SAP Integration Flow ${iflowName} was not found in package ${technicalName}. SDIA did not force a page reload.`);
  }

  async function listPackageArtifacts(payload = {}) {
    const technicalName = String(payload.TechnicalName || payload.technicalName || payload.PackageId || payload.packageId || '').trim();
    if (!technicalName) throw new Error('Package Technical Name is required to read Integration Flows.');

    // This is the endpoint used by the native SAP Cloud Integration package
    // Artifacts tab. It returns every artifact in the package, including Type=IFlow.
    const escaped = technicalName.replace(/'/g, "''");
    const encoded = encodeURIComponent(escaped);
    const url = `/odata/1.0/workspace.svc/ContentEntities.ContentPackages('${encoded}')/Artifacts?$format=json`;
    const result = await fetchODataJson(url, { emptyOn404:true });
    return { url, technicalName, packageId: technicalName, results: result.results, empty: Boolean(result.empty) };
  }

  function loadComplianceExpectation() {
    try {
      const parsed = JSON.parse(sessionStorage.getItem(COMPLIANCE_EXPECTATION_KEY) || 'null');
      if (!parsed?.createdAt || Date.now() - parsed.createdAt > COMPLIANCE_EXPECTATION_TTL) return null;
      return parsed;
    } catch (_) { return null; }
  }

  function rememberComplianceExpectation(payload = {}, mode = 'create') {
    const technicalName = String(payload.TechnicalName || '').trim();
    if (!technicalName) return;
    complianceExpectation = {
      mode,
      createdAt: Date.now(),
      technicalName,
      displayName: String(payload.DisplayName || technicalName).trim(),
      shortText: clampShortDescription(payload.ShortText || payload.Description || ''),
      version: String(payload.Version || '1.0.0').trim(),
      vendor: String(payload.Vendor || '').trim()
    };
    try { sessionStorage.setItem(COMPLIANCE_EXPECTATION_KEY, JSON.stringify(complianceExpectation)); } catch (_) {}
  }

  function clearComplianceExpectation() {
    complianceExpectation = null;
    try { sessionStorage.removeItem(COMPLIANCE_EXPECTATION_KEY); } catch (_) {}
  }

  function complianceExpectationForRoute() {
    const expectation = complianceExpectation || (complianceExpectation = loadComplianceExpectation());
    if (!expectation) return null;
    if (Date.now() - expectation.createdAt > COMPLIANCE_EXPECTATION_TTL) { clearComplianceExpectation(); return null; }
    if (expectation.mode === 'create') return isPackageCreateRoute() ? expectation : null;
    return isTargetPackageHeaderRoute(expectation.technicalName) ? expectation : null;
  }

  function currentPackageHeaderValues() {
    const displayName = resolveField('displayName');
    const technicalName = resolveField('technicalName');
    const shortText = resolveField('shortText');
    const version = resolveField('version');
    const vendor = resolveField('vendor');
    return {
      displayName: displayName ? readField(displayName).trim() : null,
      technicalName: technicalName ? readField(technicalName).trim() : null,
      shortText: shortText ? clampShortDescription(readField(shortText)) : null,
      version: version ? readField(version).trim() : null,
      vendor: vendor ? readField(vendor).trim() : null
    };
  }

  function packageComplianceFindings(expectation, current) {
    const checks = [
      ['Technical Name', expectation.technicalName, current.technicalName],
      ['Name', expectation.displayName, current.displayName],
      ['Short Description', expectation.shortText, current.shortText],
      ['Version', expectation.version, current.version],
      ['Vendor', expectation.vendor, current.vendor]
    ];
    return checks.filter(([, expected, actual]) => actual !== null && normalize(expected) !== normalize(actual))
      .map(([field, expected, actual]) => ({ field, expected: String(expected || '—'), actual: String(actual || '—') }));
  }

  function complianceDialog(findings) {
    return new Promise((resolve) => {
      document.getElementById('sdia-compliance-warning')?.remove();
      const root = document.createElement('div');
      root.id = 'sdia-compliance-warning';
      root.className = 'sdia-compliance-warning-backdrop';
      const card = document.createElement('section');
      card.className = 'sdia-compliance-warning-card';
      card.setAttribute('role', 'alertdialog');
      card.setAttribute('aria-modal', 'true');
      const head = document.createElement('header');
      head.innerHTML = '<span class="sdia-compliance-alert-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 3 2.7 20h18.6L12 3Zm0 4.2 5.7 10.4H6.3L12 7.2Zm-1 3.2v4.2h2v-4.2h-2Zm0 5.5v2h2v-2h-2Z"/></svg></span><div><b>SDIA Compliance Warning</b><p>This change is outside SDIA compliance.</p></div>';
      const list = document.createElement('div');
      list.className = 'sdia-compliance-warning-list';
      findings.slice(0, 5).forEach((finding) => {
        const row = document.createElement('div');
        const title = document.createElement('b'); title.textContent = finding.field;
        const expected = document.createElement('p'); expected.append('Expected: '); const e = document.createElement('code'); e.textContent = finding.expected; expected.appendChild(e);
        const current = document.createElement('p'); current.append('Current: '); const c = document.createElement('code'); c.textContent = finding.actual; current.appendChild(c);
        row.append(title, expected, current); list.appendChild(row);
      });
      const note = document.createElement('p'); note.className = 'sdia-compliance-warning-note'; note.textContent = 'Continue anyway? SDIA will not block your SAP Save. Non-compliant packages remain visible to governance assessment.';
      const actions = document.createElement('footer');
      const no = document.createElement('button'); no.type = 'button'; no.className = 'sdia-compliance-review'; no.textContent = 'No · Review';
      const yes = document.createElement('button'); yes.type = 'button'; yes.className = 'sdia-compliance-continue'; yes.textContent = 'Yes · Continue Anyway';
      actions.append(no, yes); card.append(head, list, note, actions); root.appendChild(card); document.body.appendChild(root);
      const finish = (value) => { root.remove(); resolve(value); };
      no.addEventListener('click', () => finish(false), { once:true });
      yes.addEventListener('click', () => finish(true), { once:true });
      root.addEventListener('keydown', (event) => { if (event.key === 'Escape') finish(false); });
      requestAnimationFrame(() => no.focus());
    });
  }

  function isNativeSaveAction(element) {
    if (!(element instanceof Element) || element.closest('#sdia-control-center,#sdia-governance-root,#sdia-compliance-warning')) return false;
    const button = element.closest('button,[role="button"],a,.sapMBtn');
    if (!button || !domVisible(button)) return false;
    return domCreateSignals(button).some((signal) => signal === 'save');
  }

  document.addEventListener('click', async (event) => {
    const target = event.target instanceof Element ? event.target.closest('button,[role="button"],a,.sapMBtn') : null;
    if (!target || !isNativeSaveAction(target)) return;
    if (complianceSaveBypassOnce) { complianceSaveBypassOnce = false; clearComplianceExpectation(); return; }
    const expectation = complianceExpectationForRoute();
    if (!expectation) return;
    const findings = packageComplianceFindings(expectation, currentPackageHeaderValues());
    if (!findings.length) { clearComplianceExpectation(); return; }

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    const continueAnyway = await complianceDialog(findings);
    if (!continueAnyway) return;
    complianceSaveBypassOnce = true;
    clickDom(target);
  }, true);

  window.addEventListener('message', async (event) => {
    if (event.source !== window) return;
    if (event.origin !== targetOrigin) return;
    const message = event.data;
    if (!message || typeof message !== 'object' || message.source !== SOURCE_IN) return;
    if (!Object.prototype.hasOwnProperty.call(PAYLOAD_SCHEMAS, message.type)) return;
    if (!isValidRequestId(message.requestId)) return;
    // Requests are only honored after the session handshake; if the nonce is not
    // established yet (or does not match), drop the message and re-announce so a
    // legitimate client can recover. See the hardening note above for the
    // documented residual risk of MAIN-world observability.
    if (!sessionNonce) { requestSessionNonce(); return; }
    if (message.nonce !== sessionNonce) return;
    const payload = sanitizePayload(message.type, message.payload);

    if (message.type === 'PREPARE_PACKAGE') {
      try {
        const result = await preparePackage(payload, message.requestId);
        rememberComplianceExpectation(payload, 'create');
        post('PREPARE_PACKAGE_RESULT', message.requestId, { ok: true, result });
      } catch (error) {
        post('PREPARE_PACKAGE_RESULT', message.requestId, {
          ok: false,
          error: error?.message || String(error),
          route: routeText()
        });
      }
      return;
    }

    if (message.type === 'OPEN_PACKAGE_FOR_EDIT') {
      try {
        const result = await openPackageForEditStep(payload, message.requestId);
        post('OPEN_PACKAGE_FOR_EDIT_RESULT', message.requestId, { ok: true, result });
      } catch (error) {
        post('OPEN_PACKAGE_FOR_EDIT_RESULT', message.requestId, { ok: false, error: error?.message || String(error), route: routeText() });
      }
      return;
    }

    if (message.type === 'ENABLE_PACKAGE_EDIT') {
      try {
        const result = await enablePackageEditStep(payload, message.requestId);
        post('ENABLE_PACKAGE_EDIT_RESULT', message.requestId, { ok: true, result });
      } catch (error) {
        post('ENABLE_PACKAGE_EDIT_RESULT', message.requestId, { ok: false, error: error?.message || String(error), route: routeText() });
      }
      return;
    }

    if (message.type === 'APPLY_PACKAGE_EDIT_VALUES') {
      try {
        const result = await applyPackageEditValuesStep(payload, message.requestId);
        rememberComplianceExpectation(payload, 'edit');
        post('APPLY_PACKAGE_EDIT_VALUES_RESULT', message.requestId, { ok: true, result });
      } catch (error) {
        post('APPLY_PACKAGE_EDIT_VALUES_RESULT', message.requestId, { ok: false, error: error?.message || String(error), route: routeText() });
      }
      return;
    }


    if (message.type === 'PREPARE_ARTEFACT') {
      try {
        const result = await prepareArtefact(payload, message.requestId);
        post('PREPARE_ARTEFACT_RESULT', message.requestId, { ok: true, result });
      } catch (error) {
        post('PREPARE_ARTEFACT_RESULT', message.requestId, {
          ok: false,
          error: error?.message || String(error),
          route: routeText()
        });
      }
      return;
    }

    if (message.type === 'NAVIGATE_EXECUTION_CONTEXT') {
      try {
        const result = await navigateExecutionContext(payload, message.requestId);
        post('NAVIGATE_EXECUTION_CONTEXT_RESULT', message.requestId, { ok: true, result });
      } catch (error) {
        post('NAVIGATE_EXECUTION_CONTEXT_RESULT', message.requestId, { ok: false, error: error?.message || String(error), route: routeText() });
      }
      return;
    }

    if (message.type === 'OPEN_IFLOW_FROM_MAP') {
      try {
        const result = await openIflowFromGovernanceMap(payload, message.requestId);
        post('OPEN_IFLOW_FROM_MAP_RESULT', message.requestId, { ok: true, result });
      } catch (error) {
        post('OPEN_IFLOW_FROM_MAP_RESULT', message.requestId, { ok: false, error: error?.message || String(error), route: routeText() });
      }
      return;
    }

    if (message.type === 'LIST_PACKAGE_ARTIFACTS') {
      try {
        const result = await listPackageArtifacts(payload);
        post('LIST_PACKAGE_ARTIFACTS_RESULT', message.requestId, { ok: true, result });
      } catch (error) {
        post('LIST_PACKAGE_ARTIFACTS_RESULT', message.requestId, { ok: false, error: error?.message || String(error) });
      }
      return;
    }

    if (message.type === 'LIST_APIM_INVENTORY') {
      try {
        const result = await listApimInventory();
        post('LIST_APIM_INVENTORY_RESULT', message.requestId, { ok: true, result });
      } catch (error) {
        post('LIST_APIM_INVENTORY_RESULT', message.requestId, { ok: false, error: error?.message || String(error) });
      }
      return;
    }

    if (message.type === 'LIST_PACKAGES') {
      try {
        const result = await listPackages();
        post('LIST_PACKAGES_RESULT', message.requestId, { ok: true, result });
      } catch (error) {
        post('LIST_PACKAGES_RESULT', message.requestId, { ok: false, error: error?.message || String(error) });
      }
    }
  });
})();
