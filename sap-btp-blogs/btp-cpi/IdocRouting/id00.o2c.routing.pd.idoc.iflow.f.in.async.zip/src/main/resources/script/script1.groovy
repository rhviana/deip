
import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    //Headers
    def headers = message.getHeaders();
    def value = headers.get("Exception");
    def mLog = messageLogFactory.getMessageLog(message);
    if(mLog != null)
    {
        mLog.addAttachmentAsString("Exception:", value,"text/plain");
        
    }
    
    return message;
}